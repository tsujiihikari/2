"use strict";

// Servlet API�ڑ���́A���̃^�u�̍ŏ���1�񂾂����肷��B
// 1) �Г�Tomcat  2) �\��Tomcat �̏��� /init ���m�F���A��������URL��sessionStorage�֕ۑ�����B
const USE_SAMPLE_DATA = false;
const KRUGLE_CONTEXT_PATH = "/krugleapi";
const KRUGLE_API_PRIMARY_BASE = "http://10.205.7.19:8080/krugleapi/";
const KRUGLE_API_SECONDARY_BASE = "http://133.18.42.50:8080/krugleapi/";
const API_SESSION_STORAGE_KEY = "krugle.api.base.url";
const API_SESSION_VERSION_KEY = "krugle.api.base.version";
const API_SESSION_VERSION = "20260824_fix158_safe_source_resolution_v1";
const API_PROBE_TIMEOUT_PRIMARY_MS = 1000;
const API_PROBE_TIMEOUT_SECONDARY_MS = 1500;
const API_ACCESS_TIMEOUT_MS = 20000;
const SOURCE_FAST_TIMEOUT_MS = 15000;
const SOURCE_RESPONSE_CACHE_LIMIT = 40;
const SOURCE_RESPONSE_CACHE_MAX_AGE_MS = 10 * 60 * 1000;
// 2026-08-12 fix63: ��������100�����̑̊����x���P�B
// �ŏ���100�s���������`�悵�A�c��͏������Œǉ����ă��C���X���b�h�̒����ԃu���b�N�������B
const SEARCH_RENDER_INITIAL_ROWS = 100;
const SEARCH_RENDER_CHUNK_ROWS = 150;
const TABLE_INFO_ENDPOINT = "/table-info";
// 2026-08-21 fix157: �����^�u���Ƃ̃e�[�u�����^�u�́A��`�{�̂ł͂Ȃ����ʎq����SessionStorage�֕ێ�����B
const TABLE_INFO_TAB_SESSION_STORAGE_KEY = "krugle.session.table.info.tabs.v1";
const TABLE_INFO_TAB_SESSION_VERSION = "20260821_table_tab_refs_v1";
const TABLE_INFO_TAB_SESSION_OWNER_LIMIT = 100;
const TABLE_INFO_TAB_SESSION_PER_OWNER_LIMIT = 100;
const TABLE_HIGHLIGHT_ENDPOINT = "/table-highlight-targets";
const DIRECTORY_GROUP_ENDPOINT = "/directory-groups";
const AI_SAMPLE_ENDPOINT = "/ai-sample";
// 2026-08-25 [1]: ����R�[�h�^�v������́A�Ώ�29�t�@�C�����܂߂Ĉ�U���ׂĖ��Ή��ɌŒ肷��B
// WAR����COMMENT/SUMMARY���Y�͎c�����A���̃t���O��false�̊Ԃ̓^�u�������������A/ai-sample���Ă΂Ȃ��B
const AI_SAMPLE_TABS_ENABLED = false;
const directoryGroupOptionsCache = new Map();
let directoryGroupLoadSequence = 0;

// 2026-07-28 �C��2: �������ʃ^�u�̏����\�������B
// Servlet��Krugle�֐ڑ��ł���ꍇ�͎��������A�ڑ��ł��Ȃ��ꍇ��
// WEB-INF/classes/mock-search/KrugleSearchResult.csv ��52����Ԃ��B
const INITIAL_SEARCH_CONDITION = Object.freeze({
  keyword: "KYF1940",
  project: "NIKKO.nkCCIS",
  language: "java",
  mode: "normal"
});

// ����u���E�U�^�u���ŊJ�����T�C�g���^�u���A���ID�ł��ǂ邽�߂�SessionStorage�����B
// �\���ʒu�i���Ԗځj�ɂ͈ˑ����Ȃ��B�z�[���͌Œ�ID�A�������s��snapshotId�A�\�[�X�́u�����{���S�p�X�v��ID�ɂ���B
const TAB_NAVIGATION_STORAGE_KEY = "krugle.session.tab.navigation.state";
const TAB_NAVIGATION_VERSION_KEY = "krugle.session.tab.navigation.version";
const TAB_NAVIGATION_VERSION = "20260825_history100_compact_v13";
const TAB_NAVIGATION_CURRENT_ID_KEY = "krugle.session.tab.navigation.currentId";
const TAB_NAVIGATION_LIMIT = 300; // �y�ʂȑO�㗚���B100������\�������ĕێ�����B
// 2026-08-25 request [5]: �������s���ƂɌ�������/�������ʂ�ʃX�i�b�v�V���b�g�Ƃ���SessionStorage�֕ۑ�����B
// 1�̋���z��ł͂Ȃ� snapshotId ���Ƃ̕ʃL�[�ɂ��ABackSpace�����͏������Q�Ƃ��������B
const SEARCH_NAVIGATION_SNAPSHOT_PREFIX = "krugle.session.search.snapshot.";
const SEARCH_NAVIGATION_SNAPSHOT_INDEX_KEY = "krugle.session.search.snapshot.index.v1";
const SEARCH_NAVIGATION_SNAPSHOT_VERSION = "20260825_search_snapshot_compact_v2";
// [7] �����X�i�b�v�V���b�g�͍ő�100����ڕW�ɕێ�����B
// ������SessionStorage��origin quota���g���؂�Ȃ��悤�A���f�[�^�͖�4MiB��soft����Ƃ���B
// �i�r�Q�[�V�����{�̂ɂ�100������ێ��ł���y�ʂȌ�������fallback���c�����߁A
// �Â��������ʖ{�̂��e�ʓs���ō폜����Ă�BackSpace/Delete�̑O��ړ����͎̂���Ȃ��B
const SEARCH_NAVIGATION_SNAPSHOT_LIMIT = 100;
const SEARCH_NAVIGATION_SNAPSHOT_SOFT_BYTES = 4 * 1024 * 1024;
const SEARCH_NAVIGATION_SNAPSHOT_MIN_KEEP = 4;
const SEARCH_VISITED_PATHS_STORAGE_KEY = "krugle.session.search.visited.paths.v1";
const SEARCH_VISITED_PATHS_LIMIT = 2000;
let restoringTabNavigation = false;
let sourceOpenRequestSequence = 0;
const sourceResponseCache = new Map();
let searchRenderSequence = 0;
let currentRenderedSearchRows = [];

// 2026-08-19 fix136: ��������Download��������ʑS�̂����b�N����B
// �ʏ�Download / Copy / ���� / �\�[�X�\���ɂ͉e�������Ȃ��B
let searchResultDownloadInProgress = false;
let searchDownloadPreviousFocus = null;

// 2026-08-17 fix106: �������ʃe�[�u���̗�ʕ�����v�t�B���^�[�B
// Servlet/Krugle�̍Č����͍s�킸�A�擾�ς݌��ʂ������N���C�A���g���ōi�荞�ށB
const SEARCH_RESULT_FILTER_KEYS = Object.freeze(["fileName", "group", "directoryGroup", "path"]);
const searchResultColumnFilters = { fileName: "", group: "", directoryGroup: "", path: "" };
let activeSearchResultFilterKey = "";
let searchResultFilterSummaryBaseText = "";

// 2026-08-18 fix116: �z�[���^�\�[�X�R�[�h��ʂ̗����e�[�u��������v�t�B���^�[�B
// �񖼂�ǉ������A�����w�b�_�[�̒��ዾ����1��̒i�ɓ��͗����J���B
const HISTORY_TABLE_FILTER_KEYS = Object.freeze(["homeFile", "homeSearch", "globalFile"]);
const historyTableFilters = { homeFile: "", homeSearch: "", globalFile: "" };
let activeHistoryTableFilterKey = "";

let activeApiBase = readSessionStorage(API_SESSION_VERSION_KEY) === API_SESSION_VERSION
  ? normalizeApiBase(readSessionStorage(API_SESSION_STORAGE_KEY))
  : "";
let resolvedApiInitData = null;
let apiResolvePromise = null;

const FILE_HISTORY_STORAGE_KEY = "krugle.history.files";
const SEARCH_HISTORY_STORAGE_KEY = "krugle.history.words";
const SEARCH_HISTORY_INITIALIZED_VERSION_KEY = "krugle.history.words.initialized.version";
const SEARCH_HISTORY_INITIAL_VERSION = "20260819_initial_search_history_v2";
const FILE_HISTORY_INITIALIZED_VERSION_KEY = "krugle.history.files.initialized.version";
const FILE_HISTORY_INITIAL_VERSION = "20260820_initial_file_history_order_v3";
const FILE_HISTORY_INITIAL_SEED_MARKER = "INITIAL_FILE_STORAGE_VALUES_20260820_fixed_order_v3";
const INITIAL_FILE_STORAGE_VALUES = [
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/meigara/MeigaraIchiran.java,2026/07/01_12:30:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiApplication.java,2026/07/01_12:20:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiApplicationCommand.java,2026/07/01_12:10:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiBbApplication.java,2026/07/01_12:00:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiBbApplicationCommand.java,2026/07/01_11:50:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_ipo/sinkoku_jyokyo/KbSnkokMeisaiPoApplication.java,2026/07/01_11:40:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_po/meigara/MeigaraIchiran.java,2026/07/01_11:30:00",
  "NIKKO.nikkoEZ/ez.web.onlineSrc/jar/app_primary-src.zip/java/jp/co/nikkobeans/app/ez_po/sinkoku_jyokyo/KbSnkokMeisaiBbPOApplication.java,2026/07/01_11:20:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzNys_java.jar/jp/co/fnt/stp1/app/apptier/back/az/nys/model/KyakJkyKjnHjnSyutkTask.java,2026/07/01_12:30:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtt_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctt/model/KjoYmdSyutkTask.java,2026/07/01_12:20:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtt_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctt/model/KjoYmdUpdTask.java,2026/07/01_12:10:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjEdd_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/edd/model/KjEddHojnJohoTask.java,2026/07/01_12:00:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjEdd_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/edd/model/KjEddKabunusiYakuinTorkTask.java,2026/07/01_11:50:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzKzt_java.jar/jp/co/fnt/stp1/app/apptier/back/az/kzt/model/SaknRyuhoGKjo1K2KMainTask.java,2026/07/01_11:40:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjUhk_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/uhk/model/KjUhkDelTask.java,2026/07/01_11:30:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjUhk_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/uhk/model/KjUhkJohoSearchTask.java,2026/07/01_11:20:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApFrKjCtc_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ctc/model/KysJohoKjnSyutkTask.java,2026/07/01_11:10:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzJky_java.jar/jp/co/fnt/stp1/app/apptier/back/az/jky/model/SaknRyuhoGKjoInqTask.java,2026/07/01_11:00:00",
  "NIKKO.nkCCIS/kyak.online.jar/lib/ApBkAzJky_java.jar/jp/co/fnt/stp1/app/apptier/back/az/jky/model/SaknRyuhoGKjoTask.java,2026/07/01_10:50:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYK5470_upd.sql,2026/07/01_12:30:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF9800_Ikan.sql,2026/07/01_12:20:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF6510_INS.sql,2026/07/01_12:10:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4410_spool.sql,2026/07/01_12:00:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF3030upd_From_CC.sql,2026/07/01_11:50:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISD0607_KYK5300_02_SPOOL.sql,2026/07/01_11:40:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF3030spool_To_CC.sql,2026/07/01_11:30:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4400_BZN_spool.sql,2026/07/01_11:20:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISALTD218.sql,2026/07/01_11:10:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCIS_KYF4301_PL_SEL.sql,2026/07/01_11:00:00",
  "NIKKO.nkCCIS/kyak.batch/sql/CCISALTD078.sql,2026/07/01_10:50:00"
];
const sampleFiles = INITIAL_FILE_STORAGE_VALUES;

// 2026-08-20 fix144: ����fileStorage�^�ߋ��̉{�������̓��[�U�[�w��30���̋L�ڏ��𐳂Ƃ���B
// �����f�[�^����openedAt�͓r���Ŏ������V�����߂邽�߁A�����\�[�g�����ł͒�`���������B
// ���{�������͏]���ǂ�������~���A����seed���m�����͂��̌Œ菇�ŕ��ׂ�B
const INITIAL_FILE_STORAGE_ORDER = new Map(
  INITIAL_FILE_STORAGE_VALUES.map((value, index) => {
    const text = String(value || "");
    const commaIndex = text.lastIndexOf(",");
    const path = (commaIndex > 0 ? text.substring(0, commaIndex) : text).trim();
    return [path, index];
  })
);
const RECENT_TAB_STORE_LIMIT = 100;
const RECENT_TAB_VISIBLE_LIMIT = 25;
const RECENT_TAB_MIN_COUNT = 0;
// 2026-08-20 fix152: �z�[����2�����͏���30������J�n���A�Ȍ�͑���1�񂲂Ƃ�1�s�ǉ��B
// �ۑ��E�z�[���\���Ƃ��ő�500���B����30���Ƃ����l�͏������^�N���A����seed���������Ɏg�p����B
const HISTORY_STORAGE_LIMIT = 500;
const FILE_HISTORY_HOME_DISPLAY_LIMIT = 500;
const SEARCH_HISTORY_HOME_DISPLAY_LIMIT = 500;
// �\�[�X�E�������͏]���̕\���ʂ��ێ����A�z�[��500�����̉e�����󂯂����Ȃ��B
const FILE_HISTORY_GLOBAL_DISPLAY_LIMIT = 300;
const FILE_HISTORY_MINI_DISPLAY_LIMIT = 20;
const INITIAL_HISTORY_SAMPLE_COUNT = 30;
const HISTORY_PLACEHOLDER_VALUE = "-";
const INITIAL_RESULT_PLACEHOLDER_COUNT = 30;
let recentWindowStart = 0;
// 2026-07-31 �C��6: �w�b�_�[�����^�u��active/visited�́APath�ł͂Ȃ���ʏ�̃^�uID�Ŋ����I�ɊǗ�����B
// SessionStorage�ɂ͕ۑ����Ȃ����߁A�T�C�g���J�������Ə�����Ԃɖ߂�B
let activeRecentTabKey = "";
const volatileVisitedRecentTabIds = new Set();
let manualRecentWindowShift = false;
// 2026-08-07 �C��17: ArrowLeft/ArrowRight�̃v���r���[��Ԃ�ێ�����B
// 2026-08-07 fix29: �E/���^�u�ړ��{�^���͒ʏ�{�^�������Aclick/Enter�ő����ړ�����B
let activeRecentTabPreviewTabId = "";
let activeCodeSideNavigationPreviewOffset = 0;
let activeCodeSideNavigationHoverOffset = 0;
// 2026-08-12 fix45: �w�b�_�[���E����Ƀ}�E�X�������Ԃ�Enter��ArrowLeft/ArrowRight�Ɠ����v���r���[�ɂ���B
let activeRecentNavArrowHoverOffset = 0;


function splitHistoryStorageValue(value) {
  if (value && typeof value === "object") {
    const path = String(value.path || value.fullPath || value.filePath || value.filePathName || value.file || value.name || "").trim();
    const openedAt = value.openedAt || value.time || value.updateTime || value.dateTime || value.timestamp || "";
    const fileName = value.fileName || value.file || value.name || "";
    const project = value.project || value.projectName || value.projectValue || value.fullProject || "";
    const group = value.group || value.migrationGroup || value.ikogroup || value.ikoGroup || value.projectGroup || "";
    const directoryGroup = value.directoryGroup || value.dirGroup || value.directory || value.dir || "";
    return {
      path,
      openedAtRaw: String(openedAt || "").trim(),
      fileName: String(fileName || "").trim(),
      project: String(project || "").trim(),
      group: String(group || "").trim(),
      directoryGroup: String(directoryGroup || "").trim(),
      initialSeed: value.__initialFileHistorySeed === true || value.initialSeed === true,
      seedMarker: String(value.__initialFileHistorySeedMarker || value.seedMarker || "").trim(),
      raw: value
    };
  }

  const text = String(value || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) {
    return { path: text, openedAtRaw: "", fileName: "", project: "", group: "", directoryGroup: "", initialSeed: false, seedMarker: "", raw: text };
  }

  const commaIndex = text.lastIndexOf(",");
  if (commaIndex > 0) {
    return {
      path: text.substring(0, commaIndex).trim(),
      openedAtRaw: text.substring(commaIndex + 1).trim(),
      fileName: "",
      project: "",
      group: "",
      directoryGroup: "",
      initialSeed: false,
      seedMarker: "",
      raw: text
    };
  }

  return { path: text, openedAtRaw: "", fileName: "", project: "", group: "", directoryGroup: "", initialSeed: false, seedMarker: "", raw: text };
}

function parseHistoryOpenedAt(value, fallbackDate) {
  const raw = String(value || "").trim();
  const fallback = fallbackDate ? toSafeDate(fallbackDate) : new Date();
  if (!raw) return fallback.toISOString();

  const normalized = raw
    .replace(/_/g, "T")
    .replace(/\//g, "-")
    .replace(/\s+/g, "T");
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? fallback.toISOString() : date.toISOString();
}

function formatHistoryStorageDate(value) {
  const date = toSafeDate(value || new Date());
  const pad = number => String(number).padStart(2, "0");
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}_${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function createHistoryStorageValue(path, openedAt, meta = {}) {
  const pathEntry = splitHistoryStorageValue(path);
  const project = normalizeProjectValue(meta.project || meta.projectName || meta.projectValue || pathEntry.project || "");
  const rawGroup = meta.group || meta.migrationGroup || meta.ikogroup || meta.ikoGroup || pathEntry.group || "";
  const group = normalizeMigrationGroupName(rawGroup);
  const fullPath = buildCompleteKruglePath(pathEntry.path, project, rawGroup);
  if (!fullPath || isPlaceholderHistoryValue(fullPath)) return fullPath;

  const result = {
    path: fullPath,
    openedAt: formatHistoryStorageDate(openedAt || new Date())
  };

  const fileName = String(meta.fileName || meta.file || meta.name || pathEntry.fileName || "").trim();
  const directoryGroup = cleanDirectoryGroupName(meta.directoryGroup || meta.dirGroup || meta.directory || pathEntry.directoryGroup || "");
  const initialSeed = meta.initialSeed === true || meta.__initialFileHistorySeed === true;
  const seedMarker = String(meta.seedMarker || meta.__initialFileHistorySeedMarker || (initialSeed ? FILE_HISTORY_INITIAL_SEED_MARKER : "")).trim();

  if (fileName) result.fileName = fileName;
  if (project) result.project = project;
  if (group) result.group = group;
  if (directoryGroup) result.directoryGroup = directoryGroup;
  if (initialSeed) {
    result.__initialFileHistorySeed = true;
    result.__initialFileHistorySeedMarker = seedMarker || FILE_HISTORY_INITIAL_SEED_MARKER;
  }
  return result;
}

function getHistoryEntryPath(value) {
  const entry = splitHistoryStorageValue(value);
  return buildCompleteKruglePath(entry.path, entry.project, entry.group);
}

function getHistoryEntryOpenedAt(value, fallbackDate) {
  const entry = splitHistoryStorageValue(value);
  return parseHistoryOpenedAt(entry.openedAtRaw, fallbackDate);
}

function buildRecentTabFromHistoryValue(value, fallbackDate) {
  const path = getHistoryEntryPath(value);
  if (!path || isPlaceholderHistoryValue(path)) return null;
  return {
    path,
    openedAt: getHistoryEntryOpenedAt(value, fallbackDate)
  };
}


function readStoredArray(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) ? value : [];
  } catch (e) {
    return [];
  }
}

function createInitialFileHistorySeedValues() {
  return normalizeFileHistoryValues((Array.isArray(INITIAL_FILE_STORAGE_VALUES) ? INITIAL_FILE_STORAGE_VALUES : [])
    .map((value, index) => {
      const entry = splitHistoryStorageValue(value);
      const path = entry.path;
      if (!isValidFileHistoryPath(path)) return null;
      const openedAt = parseHistoryOpenedAt(entry.openedAtRaw, new Date(Date.now() - index * 60 * 1000));
      return createHistoryStorageValue(path, openedAt, {
        fileName: entry.fileName,
        project: entry.project,
        group: entry.group,
        directoryGroup: entry.directoryGroup,
        initialSeed: true,
        seedMarker: FILE_HISTORY_INITIAL_SEED_MARKER
      });
    })
    .filter(Boolean));
}

function isCurrentInitialFileHistorySeed(value) {
  const entry = splitHistoryStorageValue(value);
  return entry.initialSeed === true && entry.seedMarker === FILE_HISTORY_INITIAL_SEED_MARKER;
}

function isAnyInitialFileHistorySeed(value) {
  const entry = splitHistoryStorageValue(value);
  return entry.initialSeed === true || Boolean(entry.seedMarker);
}

function createInitialFileHistoryCompareSet(seedValues) {
  return new Set((Array.isArray(seedValues) ? seedValues : [])
    .map(stringifyHistoryValueForCompare)
    .filter(Boolean));
}

function initializeFileHistoryStorageIfNeeded() {
  if (USE_SAMPLE_DATA) return;
  try {
    const storedValues = readStoredArray(FILE_HISTORY_STORAGE_KEY);
    const initializedVersion = localStorage.getItem(FILE_HISTORY_INITIALIZED_VERSION_KEY) || "";

    // 2026-08-20 fix152: ����30���́u����\���v�Ɓu�N���A�v�������o�^����B
    // 500���^�p�ŌÂ�����seed������O�֗�������ɁA������30�����Ē������Ă͂����Ȃ��B
    if (initializedVersion === FILE_HISTORY_INITIAL_VERSION && storedValues.length) {
      const normalized = normalizeFileHistoryValues(storedValues);
      const before = storedValues.map(stringifyHistoryValueForCompare).join("\u0001");
      const after = normalized.map(stringifyHistoryValueForCompare).join("\u0001");
      if (before !== after) saveArray(FILE_HISTORY_STORAGE_KEY, normalized);
      return;
    }

    const seedValues = createInitialFileHistorySeedValues();
    const seedCompareSet = createInitialFileHistoryCompareSet(seedValues);
    const hasCurrentSeed = storedValues.some(isCurrentInitialFileHistorySeed);

    // INITIAL_FILE_STORAGE_VALUES �R���̋��f�[�^�������ɃN���[������B
    // �������A���݂̃}�[�J�[�t�� seed �͎c���A���[�U�[�����ۂɊJ��������t�@�C���̕ʓ��������͏����Ȃ��B
    const cleanedValues = storedValues.filter(value => {
      if (isCurrentInitialFileHistorySeed(value)) return true;
      if (isAnyInitialFileHistorySeed(value)) return false;
      return !seedCompareSet.has(stringifyHistoryValueForCompare(value));
    });

    const nextValues = hasCurrentSeed
      ? normalizeFileHistoryValues(cleanedValues)
      : normalizeFileHistoryValues(seedValues.concat(cleanedValues));

    const before = storedValues.map(stringifyHistoryValueForCompare).join("\u0001");
    const after = nextValues.map(stringifyHistoryValueForCompare).join("\u0001");
    if (before !== after || !hasCurrentSeed) {
      saveArray(FILE_HISTORY_STORAGE_KEY, nextValues);
    }
    localStorage.setItem(FILE_HISTORY_INITIALIZED_VERSION_KEY, FILE_HISTORY_INITIAL_VERSION);
  } catch (e) {
    console.warn("file history storage initialize failed", e);
  }
}

function readFileHistoryValues() {
  const fallback = createInitialFileHistorySeedValues();
  if (USE_SAMPLE_DATA) return normalizeFileHistoryValues(fallback);
  initializeFileHistoryStorageIfNeeded();
  const values = readArray(FILE_HISTORY_STORAGE_KEY, fallback);
  return seedFileHistoryStorage(FILE_HISTORY_STORAGE_KEY, values, fallback);
}

function buildSampleRecentTabs() {
  // ���ԃ^�u���A�z�[�������E�E�������Ɠ����u�t���p�X,�����v�̌��f�[�^������B
  const result = [];
  const base = new Date("2026-07-07T10:01:04");
  sampleFiles.forEach((value, index) => {
    const fallback = new Date(base.getTime() - (index * 60 * 1000));
    const item = buildRecentTabFromHistoryValue(value, fallback);
    if (item) result.push(item);
  });
  return result;
}

const sampleRecentTabs = buildSampleRecentTabs();
let sessionRecentTabs = null;

const sampleSearchWords = [
  'KYF1940 | ���ׂ� | ���ׂ�',
  '�c���Ɖ� | nkCCIS | SQL',
  '����Ɖ� | nkCCIS | JSP',
  '�R���^�N�g���� | nkCCIS | XML',
  'TableAccessor | ALL | ALL',
  'CUSTOMER_ID | nkCCIS | java',
  'Command Task Accessor | BPNet | Java',
  'MST_CUSTOMER | SMBC | SQL',
  'QueryAccessor | fast2024 | XML',
  'AccountUpdate | nikkoEZ | ALL',
  'KYF1940 | ALL | java',
  '8jjj8jjeJEjee | nkCCIS | Java',
  'TableAccessor009 | BPNet | SQL',
  'CUSTOMER_ID010 | SMBC | XML',
  'Command Task Accessor011 | fast2024 | ALL',
  'MST_CUSTOMER012 | nikkoEZ | java',
  'QueryAccessor013 | ALL | Java',
  'AccountUpdate014 | nkCCIS | SQL',
  'KYF1940015 | BPNet | XML',
  '8jjj8jjeJEjee016 | SMBC | ALL',
  'TableAccessor017 | fast2024 | java',
  'CUSTOMER_ID018 | nikkoEZ | Java',
  'Command Task Accessor019 | ALL | SQL',
  'MST_CUSTOMER020 | nkCCIS | XML',
  'QueryAccessor021 | BPNet | ALL',
  'AccountUpdate022 | SMBC | java',
  'KYF1940023 | fast2024 | Java',
  '8jjj8jjeJEjee024 | nikkoEZ | SQL',
  'TableAccessor025 | ALL | XML',
  'CUSTOMER_ID026 | nkCCIS | ALL',
];
const PREVIOUS_INITIAL_SEARCH_WORDS_V1 = Object.freeze([
  'TableAccessor | ALL | ALL',
  'CUSTOMER_ID | nkCCIS | java',
  'Command Task Accessor | BPNet | Java',
  'MST_CUSTOMER | SMBC | SQL',
  'QueryAccessor | fast2024 | XML',
  'AccountUpdate | nikkoEZ | ALL',
  'KYF1940 | ALL | java',
  '8jjj8jjeJEjee | nkCCIS | Java',
  'TableAccessor009 | BPNet | SQL',
  'CUSTOMER_ID010 | SMBC | XML',
  'Command Task Accessor011 | fast2024 | ALL',
  'MST_CUSTOMER012 | nikkoEZ | java',
  'QueryAccessor013 | ALL | Java',
  'AccountUpdate014 | nkCCIS | SQL',
  'KYF1940015 | BPNet | XML',
  '8jjj8jjeJEjee016 | SMBC | ALL',
  'TableAccessor017 | fast2024 | java',
  'CUSTOMER_ID018 | nikkoEZ | Java',
  'Command Task Accessor019 | ALL | SQL',
  'MST_CUSTOMER020 | nkCCIS | XML',
  'QueryAccessor021 | BPNet | ALL',
  'AccountUpdate022 | SMBC | java',
  'KYF1940023 | fast2024 | Java',
  '8jjj8jjeJEjee024 | nikkoEZ | SQL',
  'TableAccessor025 | ALL | XML',
  'CUSTOMER_ID026 | nkCCIS | ALL',
  'Command Task Accessor027 | BPNet | java',
  'MST_CUSTOMER028 | SMBC | Java',
  'QueryAccessor029 | fast2024 | SQL',
  'AccountUpdate030 | nikkoEZ | XML',
]);


const sampleResults = [
  { file: "KYF1940TableAccessor.java", line: 128, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1940TableAccessor.java" },
  { file: "KYF1950TableAccessor.java", line: 82, project: "NewNikko", group: "nkCCIS", path: "kayk.online/lib/KjCTMYYYYYY.jar/jp/com/xxx/xxx/xxx/KYF1950TableAccessor.java" },
  { file: "KjCustomerSearchCommand.java", line: 45, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjCommand.jar/jp/com/xxx/command/KjCustomerSearchCommand.java" },
  { file: "KjCustomerSearchTask.java", line: 211, project: "NewNikko", group: "nkCCIS", path: "business-java/lib/KjTask.jar/jp/com/xxx/task/KjCustomerSearchTask.java" },
  { file: "ORD0100QueryAccessor.java", line: 67, project: "BPNet", group: "BPNet", path: "bpnet_dbac/lib/OrderDbac.jar/jp/com/xxx/dbac/ORD0100QueryAccessor.java" },
  { file: "AccountUpdateTableAccessor.java", line: 159, project: "SMBC", group: "SMBC", path: "smbc_dbac/lib/AccountDbac.jar/jp/com/xxx/dbac/AccountUpdateTableAccessor.java" },
  { file: "customer-search.sql", line: 14, project: "fast2024", group: "fast2024", path: "fast/sql/customer/customer-search.sql" },
  { file: "application-context.xml", line: 33, project: "nikkoEZ", group: "nikkoEZ", path: "ez/config/application-context.xml" } ];

const sampleCode = `NIKKO.nkCCIS/efront.online.jar/lib/ApFrKjFtf_java.jar/jp/co/fnt/stp1/app/apptier/front/kj/ftf/model/KyakRiskKakzJohoSyutkTask.java


package jp.co.fnt.stp1.app.apptier.front.kj.ftf.model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.fnt.stp1.app.apptier.com.cm.com.exception.SoteiGaSQLException;
import jp.co.fnt.stp1.app.apptier.com.cm.com.task.Task;
import jp.co.fnt.stp1.app.apptier.com.cm.com.task.TaskResult;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.constants.KjFtfAppSymbols;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.constants.KjFtfGyomConst;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.ctrl.param.KakudukeJoho;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.ctrl.param.RiskItem;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1940TableAccessor;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1940TableRecord;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1950TableAccessor;
import jp.co.fnt.stp1.app.apptier.front.kj.ftf.model.accessor.Kyf1950TableRecord;
import jp.co.fnt.stp1.appfw.basefw.APBFWException;
import jp.co.fnt.stp1.appfw.basefw.CommandContext;
import jp.co.fnt.stp1.appfw.basefw.CommandException;
import jp.co.fnt.stp1.appfw.basefw.MsgInfo;

/**
 * <strong>�i�t�Z�o���擾�^�X�N</strong>
 * <BR>
 * @author ACC
**/

public class KyakRiskKakzJohoSyutkTask implements Task{
	public static final Map<String,String> KAKUDUKE_KBN_MAP = new HashMap<>();
	static{
		KAKUDUKE_KBN_MAP.put("EH", "00");
		KAKUDUKE_KBN_MAP.put("H", "00");
		KAKUDUKE_KBN_MAP.put("M", "01");
		KAKUDUKE_KBN_MAP.put("L-", "02");
		KAKUDUKE_KBN_MAP.put("L", "02");
	}

    /**
    *  <B>�i�t�Z�o���擾���� </B>
    * @param CommandContext                �R�}���h�R���e�L�X�g
    * @param kyakCifC                      �ڋqCIF�R�[�h
    * @param coHyjunC                     ��ЕW���R�[�h
    * @exception CommandException          �A�v���P�[�V���������o�����O�̒��ۃN���X
    * @exception APBFWException            APBFW�����o�����O�̒��ۃN���X
    **/

    public static TaskResult getKakzJoho(CommandContext context, 
            String kyakCifC, String coHyjunC) throws CommandException, APBFWException {
        // �^�X�N���U���g
        TaskResult taskResult = new TaskResult();

        // ���ʊi�[
		ArrayList<KakudukeJoho> kakudukeJohoList = new ArrayList<KakudukeJoho>();
		String expertJudgement = "";
		String total = "";
		String kakuduke = "";
		String kakudukeKbn = "";

		// DB Accessor
        Kyf1940TableAccessor kyf1940Accessor = new Kyf1940TableAccessor();
        Kyf1950TableAccessor kyf1950Accessor = new Kyf1950TableAccessor();
    	
        Kyf1940TableRecord kyf1940Record = new Kyf1940TableRecord();
        Kyf1950TableRecord kyf1950Record = new Kyf1950TableRecord();
		
        try{
        	// �i�t�Z�o���������擾����
        	kyf1940Accessor.executeQueryKyakRiskKakzJoho(
        			context.getConnectionManager().getConnection(), 
        			coHyjunC, 
        			kyakCifC, 
        			KjFtfGyomConst.RONR_MASY_K_0);
        	
        	// �i�t���ږ������擾����
        	kyf1950Accessor.executeQueryKyakRiskKakzKomkNmJoho(
        			context.getConnectionManager().getConnection(), 
        			coHyjunC, 
        			KjFtfGyomConst.RONR_MASY_K_0);
			
			if ((kyf1940Record = kyf1940Accessor.nextRecord()) != null) {
				// �ڋq���X�N�i�t���ږ����
				kyf1950Record = kyf1950Accessor.nextRecord();
				
				// �i�t���_��{����
				KakudukeJoho basicJoho = editKakudukeJoho(kyf1940Record,kyf1950Record,1,4,"��{����","10");
				kakudukeJohoList.add(basicJoho);
				
				// �i�t���_���_����
				KakudukeJoho addJoho = editKakudukeJoho(kyf1940Record,kyf1950Record,5,15,"���_����","11");
				kakudukeJohoList.add(addJoho);
				
				expertJudgement = kyf1940Record.getExpJuge();
				total = kyf1940Record.getRiskScoreGokei();
				kakuduke = kyf1940Record.getRiskKakzCnd();
				kakudukeKbn = KAKUDUKE_KBN_MAP.get(kakuduke);
				
			} else {
				// �f�[�^���݂��Ȃ��ꍇ
				taskResult.setMsgInfo(new MsgInfo("AFKJFTF112001"));
			}
        } catch(SQLException e){
            throw new SoteiGaSQLException(e.getMessage(), e);
        } catch(APBFWException e) {
            throw e;
        } finally{
        		try {
        			kyf1940Accessor.closeStatement();
        			kyf1950Accessor.closeStatement();
    			} catch( SQLException e) {
    				throw new SoteiGaSQLException(e.getMessage(), e);
    			}
        }
        // �^�X�N���ʐݒ�
		// �i�t��񃊃X�g���^�X�N�o�͂ɃZ�b�g����
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE_LIST, kakudukeJohoList);
		// ExpertJudgement���^�X�N�o�͂ɃZ�b�g����
		taskResult.addTaskResult(KjFtfAppSymbols.EXPERT_JUDGEMENT, expertJudgement);
		// ���v���^�X�N�o�͂ɃZ�b�g����
		taskResult.addTaskResult(KjFtfAppSymbols.TOTAL, total);
		// �ڋq���X�N�i�t���^�X�N�o�͂ɃZ�b�g����
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE, kakuduke);
		// �ڋq���X�N�i�t�敪���^�X�N�o�͂ɃZ�b�g����
		taskResult.addTaskResult(KjFtfAppSymbols.KAKUDUKE_KBN, kakudukeKbn);
		
		// �^�X�N���U���g
        taskResult.setEndJtai(TaskResult.OK);
        return taskResult;
    }
    
    /**
     * �i�t���쐬
     * @param kyf1940Record KYF1940����擾�������
     * @param kyf1950Record�@KYF1950����擾�������
     * @param start ���擾�J�n�ʒu
     * @param end�@���擾�I���ʒu
     * @param riskNm�@���X�N�v�f��
     * @param riskKbn�@���X�N�v�f�敪
     */
	private static KakudukeJoho editKakudukeJoho(
			Kyf1940TableRecord kyf1940Record, Kyf1950TableRecord kyf1950Record,
			int start, int end, String riskNm, String riskKbn) {
		// ���X�N�i�t�����
		KakudukeJoho joho = new KakudukeJoho();
		// ���X�N���e���X�g
		List<RiskItem> riskItems = new ArrayList<>();
		
		for(int i = start; i <= end; i++){
			RiskItem item = new RiskItem();
			if(kyf1950Record!=null){
				item.setLabel(getItemValue(kyf1950Record,"getKyakAtr"+ String.format("%02d", i)+"nm"));
			}else{
				item.setLabel("");
			}
			item.setPoint(getItemValue(kyf1940Record,"getKyakAtr"+ String.format("%02d", i)+"Pt"));
			riskItems.add(item);
		}
		
		joho.setRiskElementKbn(riskKbn);
		joho.setRiskElementNm(riskNm);
		joho.setRiskItems(riskItems);
		return joho;
	}
	
	/**
     * ���ږ��ɂ�背�R�[�h���獀�ڒl���擾
     */
    public static String getItemValue(Object ob, String getName) {
    	String rt = "";
    	try {
    		rt = (String)ob.getClass().getDeclaredMethod(getName).invoke(ob);
    	} catch (Exception e){}
    	return rt;
    }
}`;

const sampleAiCode = `// AI�ɂ�����R�[�h
// ����Accessor�́ACUSTOMER_ID��������MST_CUSTOMER����������T���v���ł��B
// SQL_SELECT�Ŏ擾���ڂ��`���APreparedStatement�Ńo�C���h�ϐ���ݒ肵�܂��B
// ResultSet��1�s����DTO�֋l�ߑւ��āA�Ăяo������List�ŕԋp���܂��B

public List<CustomerDto> selectCustomer(Connection con, String customerId) throws Exception {
    // 1. �߂�l�p�̃��X�g���쐬
    List<CustomerDto> result = new ArrayList<CustomerDto>();

    // 2. CUSTOMER_ID�������Ɍ���
    try (PreparedStatement ps = con.prepareStatement(SQL_SELECT)) {
        ps.setString(1, customerId);

        // 3. �������ʂ�DTO�֕ϊ�
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                CustomerDto dto = new CustomerDto();
                dto.setCustomerId(rs.getString("CUSTOMER_ID"));
                dto.setCustomerName(rs.getString("CUSTOMER_NAME"));
                dto.setStatus(rs.getString("STATUS"));
                result.add(dto);
            }
        }
    }
    return result;
}`;

const sampleSummaryText = `�v�����

�EMST_CUSTOMER����������TableAccessor�ł��B
�ECUSTOMER_ID�����������Ƃ���PreparedStatement�ɐݒ肵�܂��B
�E�擾����CUSTOMER_ID�ACUSTOMER_NAME�ASTATUS��CustomerDto�֋l�ߑւ��܂��B
�E�������ʂ�List<CustomerDto>�Ƃ��ĕԋp���܂��B`;

let currentView = "home";
let currentCodePath = USE_SAMPLE_DATA ? sampleFiles[1] : "";
let codeFontSize = 12;
const CODE_FONT_MIN = 9;
const CODE_FONT_MAX = 24;
const CODE_FONT_STEP = 1;
let activeCodePanel = "source";
let lastSearchParams = null;
let lastSearchMode = "normal";
let lastSearchResults = [];
let currentCodeMeta = null;
let currentSourceText = "";
let currentSourceLanguage = "java";
// 2026-08-21 fix7: [4]/[5]��WAR�֒ǉ�����AI�T���v���\���f�[�^�B
// �Ώ�29�t�@�C���i�����������MeigaraIchiran.java��2�p�X���邽��30�s�j�����A
// COMMENT_* ���u����R�[�h�v�ASUMMARY_*.md ���u�v������v�^�u�֕\������B
let currentAiSampleData = {
  available: false,
  summaryAvailable: false,
  commentAvailable: false,
  sourceFileName: "",
  summaryFileName: "",
  commentFileName: "",
  summaryMarkdown: "",
  commentSource: "",
  commentLanguage: ""
};
let aiSampleLoadSequence = 0;
// 2026-08-18 fix124: �\�[�X��őI��������������A���݃\�[�X�̈ڍs�O���[�v�Ƒg�ݍ��킹�Ēʏ팟������B
// DOM�֑I���}�[�J�[�𖄂ߍ��܂�Range��ێ����Ahighlight.js�^�R�[�h�L�[���[�h�����N�^XSS���S��DOM���󂳂Ȃ��B
let codeSelectionSearchState = null;
let codeSelectionSearchClickArmed = null;
let codeSelectionSearchSuppressImmediateClick = false;
let currentTableNames = [];
let currentTableNameSet = new Set();
let tableInfoRequestSequence = 0;
let tableInfoState = {
  status: "idle",
  tableName: "",
  candidates: [],
  selected: null,
  tableMeta: null,
  columns: [],
  unique: false,
  error: ""
};
// 2026-08-04 �T�C�g�C��6: �e�[�u������1�^�u�㏑���ł͂Ȃ��A�N���b�N���ƂɓƗ��^�u�Ƃ��ĕێ�����B
let tableInfoTabSequence = 0;
let tableInfoStates = [];
let activeTableInfoTabId = "";

// �R�[�h����Java�N���X���E�e�[�u�����́A�������펞�\������B
// ���̃t���O�͔w�i�F������؂�ւ���B������Ԃ͕K��OFF�B
let codeHighlightBackgroundEnabled = false;
// 2026-08-25 [3]: �\�[�X�R�[�h�܂�Ԃ��\���B�f�t�H���g��ON�B
let codeWrapEnabled = true;

function $(id) {
  return document.getElementById(id);
}

function cssEscapeValue(value) {
  if (window.CSS && typeof window.CSS.escape === "function") {
    return window.CSS.escape(String(value || ""));
  }
  return String(value || "").replace(/["\\]/g, "\\$&");
}

function formatDateTime(value) {
  const date = toSafeDate(value);
  const pad = value => String(value).padStart(2, "0");
  const week = ["��", "��", "��", "��", "��", "��", "�y"][date.getDay()];
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week}) ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function formatSummaryDateTimeValue(value, fallbackDate) {
  const text = String(value == null ? "" : value).trim();
  if (text && text !== "-") {
    if (/^\d{4}\/\d{2}\/\d{2}\([�����ΐ��؋��y]\)\s+\d{2}:\d{2}:\d{2}$/.test(text)) {
      return text;
    }
    return formatDateTime(text);
  }
  return fallbackDate ? formatDateTime(fallbackDate) : "-";
}


function readSessionStorage(key) {
  try {
    return String(sessionStorage.getItem(key) || "").trim();
  } catch (e) {
    return "";
  }
}

function writeSessionStorage(key, value) {
  try {
    sessionStorage.setItem(key, String(value == null ? "" : value));
  } catch (e) {
    console.warn("sessionStorage write failed", e);
  }
}

function removeSessionStorage(key) {
  try {
    sessionStorage.removeItem(key);
  } catch (e) {
    // sessionStorage�������ł���ʏ����͌p������B
  }
}

function createSearchNavigationSnapshotId() {
  const randomPart = Math.random().toString(36).slice(2, 9);
  return `${Date.now().toString(36)}-${randomPart}`;
}

function getSearchNavigationSnapshotKey(snapshotId) {
  return `${SEARCH_NAVIGATION_SNAPSHOT_PREFIX}${String(snapshotId || "").trim()}`;
}

function readSearchNavigationSnapshotIndex() {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(SEARCH_NAVIGATION_SNAPSHOT_INDEX_KEY) || "[]");
    return Array.isArray(parsed) ? parsed.map(value => String(value || "").trim()).filter(Boolean) : [];
  } catch (e) {
    return [];
  }
}

function writeSearchNavigationSnapshotIndex(values) {
  try {
    const normalized = Array.from(new Set((Array.isArray(values) ? values : [])
      .map(value => String(value || "").trim()).filter(Boolean)))
      .slice(-SEARCH_NAVIGATION_SNAPSHOT_LIMIT);
    sessionStorage.setItem(SEARCH_NAVIGATION_SNAPSHOT_INDEX_KEY, JSON.stringify(normalized));
  } catch (e) {
    console.warn("search snapshot index write failed", e);
  }
}

function removeSearchNavigationSnapshot(snapshotId) {
  try {
    sessionStorage.removeItem(getSearchNavigationSnapshotKey(snapshotId));
  } catch (e) {
    // SessionStorage�������ł���ʏ����͌p������B
  }
}

function pruneSearchNavigationSnapshots(keepSnapshotId = "") {
  const keep = String(keepSnapshotId || "").trim();
  let ids = readSearchNavigationSnapshotIndex()
    .filter(id => {
      try { return Boolean(sessionStorage.getItem(getSearchNavigationSnapshotKey(id))); }
      catch (e) { return false; }
    });
  while (ids.length > SEARCH_NAVIGATION_SNAPSHOT_LIMIT) {
    const removed = ids.shift();
    if (removed && removed !== keep) removeSearchNavigationSnapshot(removed);
  }
  let totalBytes = getTotalStoredSearchSnapshotBytes(ids);
  while (ids.length > SEARCH_NAVIGATION_SNAPSHOT_MIN_KEEP && totalBytes > SEARCH_NAVIGATION_SNAPSHOT_SOFT_BYTES) {
    const removableIndex = ids.findIndex(id => id !== keep);
    if (removableIndex < 0) break;
    const removed = ids.splice(removableIndex, 1)[0];
    totalBytes -= getStoredSearchSnapshotBytes(removed);
    removeSearchNavigationSnapshot(removed);
  }
  writeSearchNavigationSnapshotIndex(ids);
}

function clearSearchNavigationSnapshots() {
  const ids = readSearchNavigationSnapshotIndex();
  ids.forEach(removeSearchNavigationSnapshot);
  removeSessionStorage(SEARCH_NAVIGATION_SNAPSHOT_INDEX_KEY);
}

function normalizeSearchNavigationRow(row, index = 0) {
  const normalized = normalizeSearchRow(row || {}, index);
  return {
    no: String(normalized.no || index + 1),
    fileName: String(normalized.fileName || ""),
    project: String(normalized.project || ""),
    group: String(normalized.group || ""),
    directoryGroup: String(normalized.directoryGroup || ""),
    path: String(normalized.path || ""),
    language: String(normalized.language || "")
  };
}

// [7] 100������SessionStorage�։\�Ȍ���c�����߁Arow object�̌J��Ԃ�key��ۑ����Ȃ��B
// project/group/directoryGroup/language�͎��������Apath�͋���directory prefix��؂藣���B
// JSON�Ƃ��Ĉ��S�Ȃ܂܂Ȃ̂ŁA�O�����klibrary�͕s�v�œ����I�ɕ����ł���B
function createSearchSnapshotStringDictionary(values) {
  const dictionary = [];
  const indexes = new Map();
  const indexOf = value => {
    const text = String(value || "");
    if (indexes.has(text)) return indexes.get(text);
    const index = dictionary.length;
    dictionary.push(text);
    indexes.set(text, index);
    return index;
  };
  (Array.isArray(values) ? values : []).forEach(indexOf);
  return { dictionary, indexOf };
}

function findSearchSnapshotCommonPathPrefix(rows) {
  const paths = (Array.isArray(rows) ? rows : [])
    .map(row => String(row && row.path || ""))
    .filter(Boolean);
  if (paths.length < 2) return "";
  let prefix = paths[0];
  for (let i = 1; i < paths.length && prefix; i += 1) {
    const current = paths[i];
    let limit = Math.min(prefix.length, current.length);
    let j = 0;
    while (j < limit && prefix.charCodeAt(j) === current.charCodeAt(j)) j += 1;
    prefix = prefix.slice(0, j);
  }
  const slash = prefix.lastIndexOf("/");
  if (slash < 7) return "";
  return prefix.slice(0, slash + 1);
}

function packSearchNavigationRows(rows) {
  const normalizedRows = (Array.isArray(rows) ? rows : []).map(normalizeSearchNavigationRow);
  const project = createSearchSnapshotStringDictionary(normalizedRows.map(row => row.project));
  const group = createSearchSnapshotStringDictionary(normalizedRows.map(row => row.group));
  const directory = createSearchSnapshotStringDictionary(normalizedRows.map(row => row.directoryGroup));
  const language = createSearchSnapshotStringDictionary(normalizedRows.map(row => row.language));
  const pathPrefix = findSearchSnapshotCommonPathPrefix(normalizedRows);

  return {
    f: "r1",
    pp: pathPrefix,
    p: project.dictionary,
    g: group.dictionary,
    d: directory.dictionary,
    l: language.dictionary,
    r: normalizedRows.map((row, index) => {
      const defaultNo = String(index + 1);
      const defaultFileName = getRecentTabFileName(row.path || "");
      return [
        pathPrefix && row.path.startsWith(pathPrefix) ? row.path.slice(pathPrefix.length) : row.path,
        project.indexOf(row.project),
        group.indexOf(row.group),
        directory.indexOf(row.directoryGroup),
        language.indexOf(row.language),
        row.fileName && row.fileName !== defaultFileName ? row.fileName : "",
        row.no && row.no !== defaultNo ? row.no : ""
      ];
    })
  };
}

function unpackSearchNavigationRows(packed) {
  if (!packed || packed.f !== "r1" || !Array.isArray(packed.r)) return [];
  const project = Array.isArray(packed.p) ? packed.p : [];
  const group = Array.isArray(packed.g) ? packed.g : [];
  const directory = Array.isArray(packed.d) ? packed.d : [];
  const language = Array.isArray(packed.l) ? packed.l : [];
  const prefix = String(packed.pp || "");
  return packed.r.map((values, index) => {
    const row = Array.isArray(values) ? values : [];
    const path = `${prefix}${String(row[0] || "")}`;
    return normalizeSearchNavigationRow({
      no: String(row[6] || index + 1),
      fileName: String(row[5] || getRecentTabFileName(path) || ""),
      project: String(project[Number(row[1])] || ""),
      group: String(group[Number(row[2])] || ""),
      directoryGroup: String(directory[Number(row[3])] || ""),
      path,
      language: String(language[Number(row[4])] || "")
    }, index);
  });
}

function serializeSearchNavigationSnapshot(snapshot) {
  const source = snapshot || {};
  const stored = Object.assign({}, source, {
    rowsPacked: packSearchNavigationRows(source.rows),
    rowCount: Array.isArray(source.rows) ? source.rows.length : 0
  });
  delete stored.rows;
  return JSON.stringify(stored);
}

function deserializeSearchNavigationSnapshot(serialized) {
  const parsed = JSON.parse(String(serialized || "null"));
  if (!parsed || parsed.version !== SEARCH_NAVIGATION_SNAPSHOT_VERSION) return null;
  parsed.rows = parsed.rowsPacked ? unpackSearchNavigationRows(parsed.rowsPacked) : (Array.isArray(parsed.rows) ? parsed.rows : []);
  return parsed;
}

function estimateSearchSnapshotStorageBytes(serialized) {
  // sessionStorage��DOMString�BUTF-16�ň��P�[�X������2byte/code-unit�ŕێ�I�Ɍ��ς���B
  return String(serialized || "").length * 2;
}

function getStoredSearchSnapshotBytes(snapshotId) {
  try {
    const value = sessionStorage.getItem(getSearchNavigationSnapshotKey(snapshotId));
    return value ? estimateSearchSnapshotStorageBytes(value) : 0;
  } catch (e) {
    return 0;
  }
}

function getTotalStoredSearchSnapshotBytes(ids) {
  return (Array.isArray(ids) ? ids : []).reduce((total, id) => total + getStoredSearchSnapshotBytes(id), 0);
}

function createSearchNavigationFallbackParams(params) {
  const source = params || {};
  const result = {};
  ["rawKeyword", "keyword", "project", "projectText", "directoryGroup", "directoryGroupText",
   "language", "languageText", "languageForApi", "findin", "clone"].forEach(key => {
    const value = source[key];
    if (value !== undefined && value !== null && String(value) !== "") result[key] = value;
  });
  return result;
}

function captureSearchSummaryState() {
  const text = id => {
    const element = $(id);
    return element ? String(element.textContent || "") : "";
  };
  const notice = $("searchResultLimitNotice");
  return {
    // ��t�B���^�[�K�p����summaryCount���i�荞�݌����ɂȂ邽�߁A��������D��ۑ�����B
    count: String(searchResultFilterSummaryBaseText || text("summaryCount")),
    keyword: text("summaryKeyword"),
    project: text("summaryProject"),
    directoryGroup: text("summaryDirectoryGroup"),
    language: text("summaryLanguage"),
    start: text("summaryStart"),
    end: text("summaryEnd"),
    clone: text("summaryClone"),
    limitNotice: notice && !notice.hidden ? String(notice.textContent || "") : ""
  };
}

function captureSearchNavigationSnapshot(mode = lastSearchMode, params = lastSearchParams) {
  const filters = {};
  SEARCH_RESULT_FILTER_KEYS.forEach(key => { filters[key] = String(searchResultColumnFilters[key] || ""); });
  return {
    version: SEARCH_NAVIGATION_SNAPSHOT_VERSION,
    id: createSearchNavigationSnapshotId(),
    savedAt: new Date().toISOString(),
    mode: String(mode || "normal"),
    params: Object.assign({}, params || buildSearchParams(mode || "normal")),
    rows: (Array.isArray(lastSearchResults) ? lastSearchResults : []).map(normalizeSearchNavigationRow),
    filters,
    activeFilterKey: String(activeSearchResultFilterKey || ""),
    summary: captureSearchSummaryState(),
    scrollY: Math.max(0, Number(window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0))
  };
}

function saveSearchNavigationSnapshot(snapshot) {
  if (!snapshot || !snapshot.id) return "";
  const snapshotId = String(snapshot.id);
  const key = getSearchNavigationSnapshotKey(snapshotId);
  const serialized = serializeSearchNavigationSnapshot(snapshot);
  const newBytes = estimateSearchSnapshotStorageBytes(serialized);
  let ids = readSearchNavigationSnapshotIndex().filter(id => id !== snapshotId);

  // �܂��������100�����B
  while (ids.length >= SEARCH_NAVIGATION_SNAPSHOT_LIMIT) {
    const removed = ids.shift();
    if (removed) removeSearchNavigationSnapshot(removed);
  }

  // ����soft byte budget�����B�Œ�4���͉\�Ȍ���c���B
  let existingBytes = getTotalStoredSearchSnapshotBytes(ids);
  while (ids.length > SEARCH_NAVIGATION_SNAPSHOT_MIN_KEEP
      && existingBytes + newBytes > SEARCH_NAVIGATION_SNAPSHOT_SOFT_BYTES) {
    const removed = ids.shift();
    if (removed) {
      existingBytes -= getStoredSearchSnapshotBytes(removed);
      removeSearchNavigationSnapshot(removed);
    }
  }

  ids.push(snapshotId);
  try {
    sessionStorage.setItem(key, serialized);
    writeSearchNavigationSnapshotIndex(ids);
    pruneSearchNavigationSnapshots(snapshotId);
    return snapshotId;
  } catch (e) {
    // ���u���E�U��quota��soft�����菬�����ꍇ�́A�Â��������ʖ{�̂�1�����폜���čĎ��s�B
    while (ids.length > 1) {
      const removed = ids.shift();
      if (removed && removed !== snapshotId) removeSearchNavigationSnapshot(removed);
      try {
        sessionStorage.setItem(key, serialized);
        writeSearchNavigationSnapshotIndex(ids);
        return snapshotId;
      } catch (retryError) {
        // �����1���폜���čĎ��s�B
      }
    }
    console.warn("search snapshot write failed", e);
    return "";
  }
}

function readSearchNavigationSnapshot(snapshotId) {
  const id = String(snapshotId || "").trim();
  if (!id) return null;
  try {
    const serialized = sessionStorage.getItem(getSearchNavigationSnapshotKey(id)) || "";
    if (!serialized) return null;
    const parsed = deserializeSearchNavigationSnapshot(serialized);
    if (!parsed || String(parsed.id || "") !== id) return null;
    return parsed;
  } catch (e) {
    return null;
  }
}

function readVisitedSearchPathSet() {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(SEARCH_VISITED_PATHS_STORAGE_KEY) || "[]");
    return new Set((Array.isArray(parsed) ? parsed : []).map(value => getHistoryEntryPath(value)).filter(Boolean));
  } catch (e) {
    return new Set();
  }
}

function writeVisitedSearchPathSet(set) {
  try {
    const values = Array.from(set || []).filter(Boolean).slice(-SEARCH_VISITED_PATHS_LIMIT);
    sessionStorage.setItem(SEARCH_VISITED_PATHS_STORAGE_KEY, JSON.stringify(values));
  } catch (e) {
    console.warn("visited search path write failed", e);
  }
}

function isSearchResultVisited(path) {
  const normalized = getHistoryEntryPath(path || "");
  return Boolean(normalized && readVisitedSearchPathSet().has(normalized));
}

function markSearchResultVisited(path) {
  const normalized = getHistoryEntryPath(path || "");
  if (!normalized) return;
  const set = readVisitedSearchPathSet();
  set.delete(normalized);
  set.add(normalized);
  writeVisitedSearchPathSet(set);
  document.querySelectorAll('#searchView .resultTable tbody tr[data-path]').forEach(row => {
    if (getHistoryEntryPath(row.dataset.path || "") !== normalized) return;
    row.classList.add("isVisitedResult");
    row.setAttribute("data-visited", "true");
    const nameCell = row.querySelector("td:nth-child(2)");
    if (nameCell && !nameCell.querySelector(".searchResultVisitedLabel")) {
      const label = document.createElement("span");
      label.className = "searchResultVisitedLabel";
      label.textContent = "�{����";
      nameCell.appendChild(label);
    }
  });
}

function setSearchFormFromNavigationSnapshot(snapshot) {
  const params = snapshot && snapshot.params ? snapshot.params : {};
  const keywordInput = $("keywordInput");
  const groupSelect = $("groupSelect");
  const directorySelect = $("directoryGroupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  if (keywordInput) keywordInput.value = String(params.rawKeyword || "");
  setSelectValueByTextOrValue(groupSelect, params.project || params.projectText || "ALL", "ALL");
  refreshGroupCombo({ resetFilter: true });
  setSelectValueByTextOrValue(languageSelect, params.language || params.languageText || "ALL", "ALL");
  if (cloneCheck) cloneCheck.checked = String(params.clone || "YES") === "NO";

  const directoryValue = normalizeDirectoryGroupFilterValue(params.directoryGroup || "ALL");
  if (directorySelect) {
    if (directoryValue !== "ALL" && !Array.from(directorySelect.options).some(option => option.value === directoryValue)) {
      const option = document.createElement("option");
      option.value = directoryValue;
      option.textContent = params.directoryGroupText || directoryValue;
      directorySelect.appendChild(option);
    }
    directorySelect.value = Array.from(directorySelect.options).some(option => option.value === directoryValue) ? directoryValue : "ALL";
  }
  // DB��������Ď擾�ł���ꍇ�́A�\����ɐ����Ȍ�⃊�X�g�֒u������B
  loadDirectoryGroupsForSelectedMigrationGroup({ preserveValue: true });
}

function restoreSearchSummaryState(summary) {
  const source = summary || {};
  setText("summaryCount", source.count || "0");
  setText("summaryKeyword", source.keyword || "");
  setText("summaryProject", source.project || "");
  setText("summaryDirectoryGroup", source.directoryGroup || "");
  setText("summaryLanguage", source.language || "");
  setText("summaryStart", source.start || "-");
  setText("summaryEnd", source.end || "-");
  setText("summaryClone", source.clone || "");
  const notice = $("searchResultLimitNotice");
  if (notice) {
    const message = String(source.limitNotice || "");
    notice.textContent = message;
    notice.hidden = !message;
  }
}

function restoreSearchNavigationSnapshot(snapshotId, fallbackEntry = null) {
  const snapshot = readSearchNavigationSnapshot(snapshotId);
  if (!snapshot) {
    const fallbackParams = fallbackEntry && fallbackEntry.params && typeof fallbackEntry.params === "object"
      ? Object.assign({}, fallbackEntry.params)
      : null;
    const fallbackMode = String(fallbackEntry && fallbackEntry.mode || "normal");
    if (fallbackParams && hasExecutableSearchKeyword(fallbackParams.rawKeyword || fallbackParams.keyword || "")) {
      // 100�����̃i�r���͎c���B���ʖ{�̂���quota�s���ō폜���ꂽ�ꍇ�́A�ۑ��ςݏ����ōČ�������B
      setSearchFormFromNavigationSnapshot({ params: fallbackParams });
      showView("search", { recordNavigation: false });
      showCopyFeedback("�ȑO�̌������ʖ{�͕̂ۑ��e�ʏ���̂��߁A�������������ōČ������Ă��܂�");
      runSearch(false, fallbackMode, { paramsOverride: fallbackParams, recordNavigation: false });
      return true;
    }
    showView("search", { recordNavigation: false });
    showCopyFeedback("�ȑO�̌��������𕜌��ł��܂���ł���");
    return false;
  }

  sourceOpenRequestSequence += 1;
  searchRenderSequence += 1;
  lastSearchMode = String(snapshot.mode || "normal");
  lastSearchParams = Object.assign({}, snapshot.params || {});
  lastSearchResults = (Array.isArray(snapshot.rows) ? snapshot.rows : []).map(normalizeSearchRow);
  SEARCH_RESULT_FILTER_KEYS.forEach(key => { searchResultColumnFilters[key] = String(snapshot.filters && snapshot.filters[key] || ""); });
  activeSearchResultFilterKey = SEARCH_RESULT_FILTER_KEYS.includes(snapshot.activeFilterKey) ? snapshot.activeFilterKey : "";
  searchResultFilterSummaryBaseText = "";

  setSearchFormFromNavigationSnapshot(snapshot);
  showView("search", { recordNavigation: false });
  restoreSearchSummaryState(snapshot.summary);
  const renderInfo = renderSearchResultsWithColumnFilters();
  syncSearchResultColumnFilterUi();
  renderKeywordHistoryDatalist();
  window.requestAnimationFrame(() => {
    window.scrollTo(0, Math.max(0, Number(snapshot.scrollY || 0)));
  });
  return Boolean(renderInfo);
}

function recordCurrentSearchNavigationSnapshot(mode = lastSearchMode, params = lastSearchParams) {
  if (restoringTabNavigation) return "";
  const snapshot = captureSearchNavigationSnapshot(mode, params);
  // ���ʖ{�̂̕ۑ���quota�Ŏ��s���Ă��A�y�ʂȌ������������͎���Ȃ��B
  // snapshot.id���i�r�Q�ƂƂ��Ďc���A�������ɖ{�̂��Ȃ���Γ������ōČ�������B
  const storedSnapshotId = saveSearchNavigationSnapshot(snapshot);
  const snapshotId = storedSnapshotId || snapshot.id;
  recordTabNavigation({
    type: "search",
    id: `search:${snapshotId}`,
    snapshotId,
    savedAt: snapshot.savedAt,
    mode: snapshot.mode,
    keyword: snapshot.params && snapshot.params.rawKeyword || "",
    params: createSearchNavigationFallbackParams(snapshot.params),
    snapshotStored: Boolean(storedSnapshotId)
  });
  return snapshotId;
}

function normalizeTabNavigationEntry(value) {
  if (!value || typeof value !== "object") return null;

  const type = String(value.type || "").trim();
  if (type === "view") {
    const view = String(value.view || "").trim();
    if (view !== "home" && view !== "search") return null;
    return {
      id: `view:${view}`,
      type: "view",
      view
    };
  }

  if (type === "search") {
    const snapshotId = String(value.snapshotId || "").trim();
    if (!snapshotId) return null;
    return {
      id: `search:${snapshotId}`,
      type: "search",
      snapshotId,
      savedAt: String(value.savedAt || ""),
      mode: String(value.mode || "normal"),
      keyword: String(value.keyword || ""),
      params: createSearchNavigationFallbackParams(value.params || {}),
      snapshotStored: value.snapshotStored !== false
    };
  }

  if (type === "recent") {
    const path = getHistoryEntryPath(value.path || value.fullPath || value.filePath || "");
    if (!path) return null;

    const openedTime = new Date(value.openedAt || "");
    if (Number.isNaN(openedTime.getTime())) return null;
    const openedAt = openedTime.toISOString();
    const item = { path, openedAt };

    const entry = {
      id: `recent:${recentTabKey(item)}`,
      type: "recent",
      path,
      openedAt
    };

    ["fileName", "project", "group", "directoryGroup", "href", "sourceUrl", "language"].forEach(key => {
      const text = String(value[key] == null ? "" : value[key]).trim();
      if (text) entry[key] = text;
    });
    return entry;
  }

  return null;
}

function createViewTabNavigationEntry(viewName) {
  return normalizeTabNavigationEntry({ type: "view", view: viewName });
}

function createRecentTabNavigationEntry(item, meta = {}) {
  return normalizeTabNavigationEntry(Object.assign({}, meta || {}, {
    type: "recent",
    path: item && item.path,
    openedAt: item && item.openedAt
  }));
}

function readTabNavigationState() {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(TAB_NAVIGATION_STORAGE_KEY) || "{}");
    const entries = Array.isArray(parsed.entries)
      ? parsed.entries.map(normalizeTabNavigationEntry).filter(Boolean).slice(-TAB_NAVIGATION_LIMIT)
      : [];
    // [6] BackSpace�ŗ���v�f���̂��̂��폜�����AcurrentIndex������O�コ����B
    // ��v11�`���ɂ�currentIndex���Ȃ����߁A���̏ꍇ�͏]���ǂ��薖�������݈ʒu�Ƃ��Ĉڍs����B
    let currentIndex = Number.isInteger(parsed.currentIndex) ? parsed.currentIndex : entries.length - 1;
    if (!entries.length) currentIndex = -1;
    else currentIndex = Math.max(0, Math.min(currentIndex, entries.length - 1));
    const currentId = currentIndex >= 0 && entries[currentIndex] ? entries[currentIndex].id : "";
    return {
      version: TAB_NAVIGATION_VERSION,
      entries,
      currentIndex,
      currentId
    };
  } catch (e) {
    return { version: TAB_NAVIGATION_VERSION, entries: [], currentIndex: -1, currentId: "" };
  }
}

function writeTabNavigationState(state) {
  try {
    const normalizedAll = (state && Array.isArray(state.entries) ? state.entries : [])
      .map(normalizeTabNavigationEntry)
      .filter(Boolean);
    let requestedIndex = Number.isInteger(state && state.currentIndex)
      ? state.currentIndex
      : normalizedAll.length - 1;
    const dropCount = Math.max(0, normalizedAll.length - TAB_NAVIGATION_LIMIT);
    const entries = dropCount ? normalizedAll.slice(dropCount) : normalizedAll;
    requestedIndex -= dropCount;
    let currentIndex = entries.length
      ? Math.max(0, Math.min(requestedIndex, entries.length - 1))
      : -1;
    const currentId = currentIndex >= 0 && entries[currentIndex] ? entries[currentIndex].id : "";
    const payload = {
      version: TAB_NAVIGATION_VERSION,
      entries,
      currentIndex,
      currentId
    };
    sessionStorage.setItem(TAB_NAVIGATION_STORAGE_KEY, JSON.stringify(payload));
    sessionStorage.setItem(TAB_NAVIGATION_CURRENT_ID_KEY, currentId);
    if (document && document.documentElement) {
      document.documentElement.dataset.activeTabId = currentId;
    }
    updateRecentTabVisitedStyles();
  } catch (e) {
    console.warn("tab navigation history write failed", e);
  }
}

function recordTabNavigation(entry) {
  if (restoringTabNavigation) return;
  const normalized = normalizeTabNavigationEntry(entry);
  if (!normalized) return;

  const state = readTabNavigationState();
  const current = state.currentIndex >= 0 ? state.entries[state.currentIndex] : null;
  if (current && current.id === normalized.id) {
    writeTabNavigationState(state);
    return;
  }

  // [6] BackSpace�ŉߋ��֖߂�����ɐV�K�J�ڂ����ꍇ�́A�u���E�UForward�Ɠ�����
  // ���݈ʒu����Ɏc���Ă����Â��u�i�ށv������j�����ĐV������������B
  const kept = state.currentIndex >= 0
    ? state.entries.slice(0, state.currentIndex + 1)
    : [];
  kept.push(normalized);
  state.entries = kept;
  state.currentIndex = kept.length - 1;
  writeTabNavigationState(state);
}

function initializeTabNavigationHistory() {
  const storedVersion = readSessionStorage(TAB_NAVIGATION_VERSION_KEY);
  if (storedVersion !== TAB_NAVIGATION_VERSION) {
    removeSessionStorage(TAB_NAVIGATION_STORAGE_KEY);
    removeSessionStorage(TAB_NAVIGATION_CURRENT_ID_KEY);
    // ��������SessionStorage�������āA��ꂽ�����������p���Ȃ��B
    removeSessionStorage("krugle.session.tab.navigation.history");
    removeSessionStorage("krugle.session.tab.navigation.version");
    clearSearchNavigationSnapshots();
    writeSessionStorage(TAB_NAVIGATION_VERSION_KEY, TAB_NAVIGATION_VERSION);
  }

  // ������ʂ̓z�[���Ȃ̂ŁA�T�C�g���J�������_����K�������֓����B
  recordTabNavigation(createViewTabNavigationEntry("home"));
}

function isBackspaceEditingTarget(target) {
  if (!target) return false;
  const element = target.nodeType === 1 ? target : target.parentElement;
  if (!element) return false;
  if (element.isContentEditable) return true;
  if (element.closest && element.closest('[contenteditable="true"], [contenteditable=""]')) return true;

  const tagName = String(element.tagName || "").toLowerCase();
  if (tagName === "textarea" || tagName === "select") {
    return !element.disabled && !element.readOnly;
  }
  if (tagName === "input") {
    const type = String(element.type || "text").toLowerCase();
    const nonTextTypes = new Set(["button", "checkbox", "color", "file", "hidden", "image", "radio", "range", "reset", "submit"]);
    return !nonTextTypes.has(type) && !element.disabled && !element.readOnly;
  }
  return false;
}

function findRecentTabForNavigation(entry) {
  const normalized = normalizeTabNavigationEntry(entry);
  if (!normalized || normalized.type !== "recent") return null;

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  const exact = tabs.find(item => `recent:${recentTabKey(item)}` === normalized.id);
  if (exact) return exact;

  // �����N���A�������߂œ���ID���������ꍇ���A�ۑ��ς݂̊��S�p�X�Ń\�[�X�𕜌�����B
  // �����p�X�̍ŐV�^�u���c���Ă���΁A���̎��݃^�u���A�N�e�B�u�ɂ���B
  return tabs.find(item => item.path === normalized.path) || {
    path: normalized.path,
    openedAt: normalized.openedAt
  };
}

function openTabNavigationEntry(entry) {
  const normalized = normalizeTabNavigationEntry(entry);
  if (!normalized) return false;

  restoringTabNavigation = true;
  try {
    if (normalized.type === "view") {
      showView(normalized.view, { recordNavigation: false });
      return true;
    }

    if (normalized.type === "search") {
      return restoreSearchNavigationSnapshot(normalized.snapshotId, normalized);
    }

    if (normalized.type === "recent") {
      const recentItem = findRecentTabForNavigation(normalized);
      const row = {
        path: normalized.path,
        fileName: normalized.fileName || "",
        project: normalized.project || "",
        group: normalized.group || "",
        directoryGroup: normalized.directoryGroup || "",
        href: normalized.href || "",
        sourceUrl: normalized.sourceUrl || "",
        language: normalized.language || ""
      };
      openCode(normalized.path, {
        addRecent: false,
        recentItem,
        row,
        recordNavigation: false
      });
      return true;
    }
  } finally {
    // openCode�͍ŏ���await���O�Ƀ^�u�\����؂�ւ��邽�߁A�����ŉ������Ă悢�B
    restoringTabNavigation = false;
  }
  return false;
}

function navigateToPreviousOpenedTab() {
  const state = readTabNavigationState();
  if (!state.entries.length || state.currentIndex <= 0) return false;

  // [6] �����͍폜����currentIndex��1�O�ֈڂ��B����ɂ��Delete�Ō��̈ʒu�֐i�߂�B
  let targetIndex = state.currentIndex - 1;
  while (targetIndex >= 0) {
    const previous = state.entries[targetIndex];
    state.currentIndex = targetIndex;
    writeTabNavigationState(state);
    if (openTabNavigationEntry(previous)) return true;
    targetIndex -= 1;
  }

  return false;
}

function navigateToNextOpenedTab() {
  const state = readTabNavigationState();
  if (!state.entries.length || state.currentIndex < 0 || state.currentIndex >= state.entries.length - 1) return false;

  // [6] Delete�^�u�ЂƂ�̃^�u�ֈڂ�v��currentIndex��1��֐i�߂�B
  let targetIndex = state.currentIndex + 1;
  while (targetIndex < state.entries.length) {
    const next = state.entries[targetIndex];
    state.currentIndex = targetIndex;
    writeTabNavigationState(state);
    if (openTabNavigationEntry(next)) return true;
    targetIndex += 1;
  }

  return false;
}

// 2026-08-19 fix132: �e�[�u�����iDDL�j�\������BackSpace�́A
// �w�b�_�[�̗�����߂����A�����\�[�X�^�u���́u�\�[�X�R�[�h�v�\���֖߂��B
function navigateBackspaceFromTableInfoToSource() {
  if (currentView !== "code" || !isTableInfoPanel(activeCodePanel)) return false;
  activeCodePanel = "source";
  renderCode();
  return true;
}

function handleBackspaceTabNavigation(event) {
  const isBackspace = event.key === "Backspace" || event.keyCode === 8;
  if (!isBackspace || event.defaultPrevented || event.isComposing || event.keyCode === 229) return;
  if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || event.repeat) return;
  if (isBackspaceEditingTarget(event.target)) return;

  // �u���E�U�́u�O�̃y�[�W�֖߂�v���~�߂�B
  event.preventDefault();
  event.stopPropagation();

  // �e�[�u�����iKYC0010����DDL�j�\���������́A����w�b�_�[�^�u�̃\�[�X�R�[�h�֖߂�B
  // ���̌o�H�ł̓T�C�g���^�u����������Ȃ����߁A����BackSpace�Œʏ�ǂ����O�̃w�b�_�[�^�u�֖߂��B
  if (navigateBackspaceFromTableInfoToSource()) return;

  // �ʏ��ʂ͏]���ǂ���A�T�C�g���̃w�b�_�[�^�u������1���߂��B
  navigateToPreviousOpenedTab();
}

function handleDeleteTabNavigation(event) {
  const isDelete = event.key === "Delete" || event.key === "Del" || event.keyCode === 46;
  if (!isDelete || event.defaultPrevented || event.isComposing || event.keyCode === 229) return;
  if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || event.repeat) return;
  // ���͗��ł�Delete�{���̕����폜��D�悵�A�T�C�g��Forward�֒D��Ȃ��B
  if (isBackspaceEditingTarget(event.target)) return;

  event.preventDefault();
  event.stopPropagation();
  navigateToNextOpenedTab();
}

// 2026-08-12 fix59 + 2026-08-25 [6]: �E���c�{�^����BackSpace/Delete�̑O�㗚���֓��ꂷ��B
let activeCodeBackTabButtonHover = false;
let activeCodeForwardTabButtonHover = false;

function activatePreviousOpenedTabButton(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  navigateToPreviousOpenedTab();
}

function activateNextOpenedTabButton(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  navigateToNextOpenedTab();
}

function bindCodeBackTabButton() {
  const backButton = $("codeBackTabBtn");
  const forwardButton = $("codeForwardTabBtn");

  const bindOne = (button, activate, setHover) => {
    if (!button) return;
    button.addEventListener("click", activate);
    button.addEventListener("keydown", event => {
      if (event.key !== "Enter" && event.key !== " ") return;
      activate(event);
    });
    const syncHover = active => {
      setHover(Boolean(active));
      button.classList.toggle("isCopyDownloadHover", Boolean(active));
    };
    button.addEventListener("mouseenter", () => syncHover(true));
    button.addEventListener("mouseleave", () => syncHover(false));
    button.addEventListener("pointerenter", () => syncHover(true));
    button.addEventListener("pointerleave", () => syncHover(false));
    button.addEventListener("focus", () => syncHover(true));
    button.addEventListener("blur", () => syncHover(false));
  };

  bindOne(backButton, activatePreviousOpenedTabButton, active => { activeCodeBackTabButtonHover = active; });
  bindOne(forwardButton, activateNextOpenedTabButton, active => { activeCodeForwardTabButtonHover = active; });
}

function normalizeApiBase(base) {
  const value = String(base || "").trim();
  if (!value) return "";
  return value.endsWith("/") ? value : `${value}/`;
}

function apiPathForBase(base, path) {
  const cleanPath = String(path || "").replace(/^\/+/, "");
  const normalizedBase = normalizeApiBase(base);
  if (/^https?:\/\//i.test(normalizedBase)) {
    return new URL(cleanPath, normalizedBase).toString();
  }
  if (normalizedBase) return `${normalizedBase.replace(/\/$/, "")}/${cleanPath}`;
  return `${KRUGLE_CONTEXT_PATH}/${cleanPath}`;
}

function apiPath(path) {
  return apiPathForBase(activeApiBase || KRUGLE_API_PRIMARY_BASE, path);
}

function formBody(params) {
  const body = new URLSearchParams();
  Object.keys(params || {}).forEach(key => {
    const value = params[key];
    if (value !== undefined && value !== null) body.append(key, String(value));
  });
  return body;
}

function buildQueryString(params) {
  return formBody(params).toString();
}

function appendQuery(url, params) {
  const query = buildQueryString(params);
  if (!query) return url;
  return url + (url.indexOf("?") >= 0 ? "&" : "?") + query;
}

function createApiError(message, properties = {}) {
  const error = new Error(message);
  Object.keys(properties).forEach(key => {
    error[key] = properties[key];
  });
  return error;
}

function shouldUseJsonpTransport(options = {}) {
  if (options.transport === "fetch") return false;
  if (options.transport === "jsonp") return true;
  // file://���J���ł͒ʏ�fetch��CORS��������JSONP���g���B
  // Servlet����callback���������邽�߁AOrigin:null��PNA������󂯂Ȃ��B
  return window.location.protocol === "file:";
}

async function fetchJsonViaCors(base, path, params = {}, options = {}) {
  const method = String(options.method || "POST").toUpperCase();
  let url = apiPathForBase(base, path);
  const requestOptions = {
    method,
    headers: { "Accept": "application/json" },
    cache: "no-store",
    mode: "cors",
    credentials: "omit",
    redirect: "follow"
  };

  if (method === "GET") {
    url = appendQuery(url, params);
  } else {
    requestOptions.headers["Content-Type"] = "application/x-www-form-urlencoded;charset=UTF-8";
    requestOptions.body = formBody(params);
  }

  let timeoutId = null;
  let controller = null;
  const timeoutMs = Number(options.timeoutMs || 0);
  if (timeoutMs > 0 && typeof AbortController !== "undefined") {
    controller = new AbortController();
    requestOptions.signal = controller.signal;
    timeoutId = window.setTimeout(() => controller.abort(), timeoutMs);
  }

  let response;
  try {
    response = await fetch(url, requestOptions);
  } catch (e) {
    const timedOut = Boolean(e && e.name === "AbortError");
    const detail = timedOut ? `�^�C���A�E�g(${timeoutMs}ms)` : String((e && e.message) || e || "Failed to fetch");
    throw createApiError(`�ʐM���s: ${detail}\nURL: ${url}`, {
      apiUnavailable: true,
      timedOut,
      url,
      cause: e
    });
  } finally {
    if (timeoutId !== null) window.clearTimeout(timeoutId);
  }

  const text = await response.text();
  let data = {};
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (e) {
      throw createApiError(`JSON��͎��s HTTP ${response.status}: ${text.substring(0, 300)}\nURL: ${url}`, {
        apiUnavailable: true,
        status: response.status,
        url,
        cause: e
      });
    }
  }

  if (!response.ok) {
    const message = data && data.error ? data.error : `HTTP ${response.status}`;
    throw createApiError(`${message}\nURL: ${url}`, {
      apiUnavailable: response.status === 404 || response.status >= 500,
      status: response.status,
      url,
      responseData: data
    });
  }
  return data;
}

function fetchJsonViaJsonp(base, path, params = {}, options = {}) {
  return new Promise((resolve, reject) => {
    const timeoutMs = Math.max(1, Number(options.timeoutMs || API_ACCESS_TIMEOUT_MS));
    const callbackName = `__krugleJsonp_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const query = Object.assign({}, params, {
      callback: callbackName,
      _: Date.now()
    });
    const url = appendQuery(apiPathForBase(base, path), query);
    const script = document.createElement("script");
    let settled = false;
    let timerId = null;

    const cleanup = () => {
      if (timerId !== null) window.clearTimeout(timerId);
      try { delete window[callbackName]; } catch (e) { window[callbackName] = undefined; }
      if (script.parentNode) script.parentNode.removeChild(script);
    };
    const finish = (handler, value) => {
      if (settled) return;
      settled = true;
      cleanup();
      handler(value);
    };

    window[callbackName] = data => finish(resolve, data || {});
    script.async = true;
    script.src = url;
    script.onerror = () => finish(reject, createApiError(`JSONP�ʐM���s\nURL: ${url}`, {
      apiUnavailable: true,
      url
    }));
    timerId = window.setTimeout(() => finish(reject, createApiError(`�^�C���A�E�g(${timeoutMs}ms)\nURL: ${url}`, {
      apiUnavailable: true,
      timedOut: true,
      url
    })), timeoutMs);
    document.head.appendChild(script);
  });
}

async function fetchJsonAtBase(base, path, params = {}, options = {}) {
  if (shouldUseJsonpTransport(options)) {
    // JSONP��script GET�����𗘗p���邽�߁APOST�w��ł�GET�N�G���ֈ��S�ɕϊ�����B
    return fetchJsonViaJsonp(base, path, params, options);
  }
  return fetchJsonViaCors(base, path, params, options);
}

function isMixedContentCandidate(base) {
  return window.location.protocol === "https:" && /^http:\/\//i.test(normalizeApiBase(base));
}

function clearApiBaseSelection() {
  activeApiBase = "";
  resolvedApiInitData = null;
  apiResolvePromise = null;
  removeSessionStorage(API_SESSION_STORAGE_KEY);
  removeSessionStorage(API_SESSION_VERSION_KEY);
  // ���ł��ۑ��������s�t���O���폜����B
  removeSessionStorage("krugle.api.base.resolved");
  removeSessionStorage("krugle.api.base.error");
}

function saveApiBaseSelection(base) {
  activeApiBase = normalizeApiBase(base);
  writeSessionStorage(API_SESSION_STORAGE_KEY, activeApiBase);
  writeSessionStorage(API_SESSION_VERSION_KEY, API_SESSION_VERSION);
  removeSessionStorage("krugle.api.base.resolved");
  removeSessionStorage("krugle.api.base.error");
}

function validateProbeResponse(data, base) {
  if (!data || data.ok !== true) {
    throw createApiError(`�a�ʊm�F�̉����`�����s���ł��B\nURL: ${apiPathForBase(base, "/init")}`, {
      apiUnavailable: true
    });
  }
}

function validateInitResponse(data, base) {
  if (!data || !Array.isArray(data.projects)) {
    throw createApiError(`Servlet /init �̉����`�����s���ł��B\nURL: ${apiPathForBase(base, "/init")}`, {
      apiUnavailable: true
    });
  }
}

async function resolveApiBaseOnce(options = {}) {
  const forceCheck = options.forceCheck === true;
  if (!forceCheck && activeApiBase) {
    return { base: normalizeApiBase(activeApiBase), initData: resolvedApiInitData, cached: true };
  }
  if (!forceCheck && apiResolvePromise) return apiResolvePromise;

  const candidates = [
    { base: KRUGLE_API_PRIMARY_BASE, timeoutMs: API_PROBE_TIMEOUT_PRIMARY_MS },
    { base: KRUGLE_API_SECONDARY_BASE, timeoutMs: API_PROBE_TIMEOUT_SECONDARY_MS }
  ].filter(candidate => !isMixedContentCandidate(candidate.base));

  const promise = (async () => {
    const errors = [];
    for (const candidate of candidates) {
      const base = normalizeApiBase(candidate.base);
      try {
        // ��1�i�K: Servlet������Z���Ԋm�F�BKrugle CGI�ɂ͐ڑ����Ȃ��B
        const probeData = await fetchJsonAtBase(base, "/init", { probe: "1" }, {
          method: "GET",
          timeoutMs: candidate.timeoutMs
        });
        validateProbeResponse(probeData, base);

        // ��2�i�K: ����Servlet�֖{�A�N�Z�X�B���̐����ゾ��SessionStorage�֕ۑ�����B
        const initData = await fetchJsonAtBase(base, "/init", {}, {
          method: "GET",
          timeoutMs: API_ACCESS_TIMEOUT_MS
        });
        validateInitResponse(initData, base);

        resolvedApiInitData = initData;
        saveApiBaseSelection(base);
        console.info(`Krugle Servlet API�ڑ�OK: ${activeApiBase}`);
        return { base: activeApiBase, initData, cached: false };
      } catch (e) {
        errors.push(`${base} -> ${String(e && e.message ? e.message : e)}`);
      }
    }

    throw createApiError(`Servlet API�֐ڑ��ł��܂���ł����B\n${errors.join("\n\n")}`, {
      apiUnavailable: true,
      candidateErrors: errors
    });
  })();

  apiResolvePromise = promise;
  promise.catch(() => {
    if (apiResolvePromise === promise) apiResolvePromise = null;
  });
  return promise;
}

async function fetchJson(path, params = {}, options = {}) {
  const resolved = await resolveApiBaseOnce();
  try {
    return await fetchJsonAtBase(resolved.base, path, params, options);
  } catch (e) {
    if (options.disableFailover === true || !e || e.apiUnavailable !== true) throw e;

    const failedBase = normalizeApiBase(resolved.base);
    clearApiBaseSelection();
    console.warn(`Servlet�ڑ�����Ĕ��肵�܂�: ${failedBase}`);
    const retryResolved = await resolveApiBaseOnce({ forceCheck: true });
    return fetchJsonAtBase(retryResolved.base, path, params, Object.assign({}, options, { disableFailover: true }));
  }
}

function buildSourceResponseCacheKey(endpoint, params = {}) {
  const stable = [
    endpoint,
    params.path || "",
    params.fullPath || "",
    params.filePath || "",
    params.project || "",
    params.href || "",
    params.sourceUrl || "",
    params.language || "",
    params.className || params.javaClassName || "",
    params.qualifiedClassName || params.javaQualifiedClassName || params.importQualifiedClassName || "",
    params.originPath || "",
    params.originFullPath || "",
    params.originProject || "",
    params.originGroup || "",
    params.originDirectoryGroup || "",
    params.originPackage || ""
  ];
  return stable.map(value => String(value == null ? "" : value)).join("");
}

function cloneSourceResponseData(data) {
  if (!data || typeof data !== "object") return data;
  try {
    return JSON.parse(JSON.stringify(data));
  } catch (e) {
    return Object.assign({}, data);
  }
}

function readSourceResponseCache(cacheKey) {
  if (!cacheKey || !sourceResponseCache.has(cacheKey)) return null;
  const entry = sourceResponseCache.get(cacheKey);
  if (!entry || Date.now() - entry.loadedAt > SOURCE_RESPONSE_CACHE_MAX_AGE_MS) {
    sourceResponseCache.delete(cacheKey);
    return null;
  }
  // Map�͑}������ێ����邽�߁A�ǂݏo�������ڂ𖖔��։񂵂ĊȈ�LRU�ɂ���B
  sourceResponseCache.delete(cacheKey);
  sourceResponseCache.set(cacheKey, entry);
  return cloneSourceResponseData(entry.data);
}

function writeSourceResponseCache(cacheKey, data) {
  if (!cacheKey || !data || typeof data !== "object") return;
  sourceResponseCache.set(cacheKey, {
    loadedAt: Date.now(),
    data: cloneSourceResponseData(data)
  });
  while (sourceResponseCache.size > SOURCE_RESPONSE_CACHE_LIMIT) {
    const firstKey = sourceResponseCache.keys().next().value;
    if (firstKey === undefined) break;
    sourceResponseCache.delete(firstKey);
  }
}

async function fetchSourceJsonFast(endpoint, params = {}) {
  const preferredBase = normalizeApiBase(activeApiBase || KRUGLE_API_PRIMARY_BASE);
  if (!preferredBase || isMixedContentCandidate(preferredBase)) {
    return fetchJson(endpoint, params, { method: "GET", timeoutMs: SOURCE_FAST_TIMEOUT_MS });
  }

  try {
    const data = await fetchJsonAtBase(preferredBase, endpoint, params, {
      method: "GET",
      timeoutMs: SOURCE_FAST_TIMEOUT_MS
    });
    if (!activeApiBase) saveApiBaseSelection(preferredBase);
    return data;
  } catch (e) {
    if (!e || e.apiUnavailable !== true) throw e;
    if (activeApiBase && normalizeApiBase(activeApiBase) === preferredBase) {
      clearApiBaseSelection();
    }
    console.warn(`�\�[�X�擾�̒��ڐڑ��Ɏ��s��������Servlet�ڑ�����Ĕ��肵�܂�: ${preferredBase}`, e);
    const retryResolved = await resolveApiBaseOnce({ forceCheck: true });
    return fetchJsonAtBase(retryResolved.base, endpoint, params, {
      method: "GET",
      timeoutMs: SOURCE_FAST_TIMEOUT_MS
    });
  }
}

function submitDownload(path, params = {}) {
  const form = document.createElement("form");
  form.method = "POST";
  form.action = apiPath(path);
  form.style.display = "none";
  form.target = "_self";

  Object.keys(params || {}).forEach(key => {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = key;
    input.value = params[key] == null ? "" : String(params[key]);
    form.appendChild(input);
  });

  document.body.appendChild(form);
  form.submit();
  window.setTimeout(() => form.remove(), 1000);
}

function optionText(selectElement) {
  if (!selectElement) return "";
  const option = selectElement.options[selectElement.selectedIndex];
  return option ? option.textContent.trim() : "";
}

function normalizeKeywordForMode(rawKeyword, mode) {
  const keyword = String(rawKeyword || "").trim();

  // �ʏ팟���ł͓��͒l����؉��H���Ȃ��B
  if (mode !== "fuzzy" || !keyword) return keyword;

  // �B�������̏ꍇ�����A���݂��Ȃ����� * ��₤�B
  // ���ɓ��͂���Ă���擪�E������ * �͂��̂܂ܑ��d����B
  const leadingWildcard = keyword.startsWith("*") ? "" : "*";
  const trailingWildcard = keyword.endsWith("*") ? "" : "*";
  return `${leadingWildcard}${keyword}${trailingWildcard}`;
}

function hasExecutableSearchKeyword(rawKeyword) {
  // 2026-08-12 fix47:
  // �󕶎��A���p/�S�p�X�y�[�X�����A�^�u�����A*�����A���p�L�������̌����ł�
  // Servlet / Krugle API ��REST�Ăяo�����Ȃ��B
  const text = String(rawKeyword || "");
  if (!text.replace(/[\s\u3000]+/g, "")) return false;

  // �p�����E�S�p�p�����E�Ђ炪�ȁE�J�^�J�i�E�����̂����ꂩ���܂ޏꍇ���������\�Ƃ���B
  // �L�������̓��́i��: *, ***, --, /, @@@�j�͖��������ɂ���B
  return /[0-9A-Za-z\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\u3040-\u309F\u30A0-\u30FF\u3400-\u9FFF]/.test(text);
}

const KRUGLE_LANGUAGE_VALUE_ALIASES = Object.freeze({
  "java": "java",
  "sql": "sql",
  "xml": "xml",
  "jsp": "jsp",
  "shell": "shell",
  "shell script": "shell",
  "javascript": "javascript",
  "html": "html",
  "c#": "csharp",
  "csharp": "csharp",
  "c++": "cpp",
  "cpp": "cpp",
  "visual basic": "vb",
  "vb": "vb",
  "vb.net": "vb.net",
  "asp.net": "asp.net",
  "objective c": "objectivec",
  "common lisp": "lisp",
  "lex/flex": "lex",
  "pascal/delphi": "pascal",
  "s/r": "s",
  "yacc/bison": "yacc"
});

function normalizeLanguageValueForKrugle(value) {
  const raw = String(value == null ? "" : value).trim();
  if (!raw) return "ALL";
  if (raw.toUpperCase() === "ALL" || raw === "���ׂ�") return "ALL";
  const key = raw.toLowerCase();
  return KRUGLE_LANGUAGE_VALUE_ALIASES[key] || key;
}

function getLanguageDisplayTextForSearch(selectElement, languageValue) {
  const text = optionText(selectElement);
  if (text) return text;
  const normalized = normalizeLanguageValueForKrugle(languageValue);
  if (normalized === "ALL") return "���ׂ�";
  const option = selectElement
    ? Array.from(selectElement.options).find(item => normalizeLanguageValueForKrugle(item.value) === normalized)
    : null;
  return option ? String(option.textContent || "").trim() : languageValue;
}


function clearCodeSelectionSearchState(options = {}) {
  codeSelectionSearchState = null;
  codeSelectionSearchClickArmed = null;
  codeSelectionSearchSuppressImmediateClick = false;
  if (options.clearNativeSelection && window.getSelection) {
    const selection = window.getSelection();
    if (selection && typeof selection.removeAllRanges === "function") selection.removeAllRanges();
  }
}

function normalizeCodeSelectionSearchKeyword(value) {
  // Krugle��keyword�։��s�𒼐ړn���Ȃ��B�I�����������ڂ̕�����͈ێ����A�A���󔒂���1�֏�ށB
  return String(value == null ? "" : value)
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getCodeSelectionSearchCandidate() {
  if (currentView !== "code" || activeCodePanel !== "source" || !window.getSelection) return null;
  const codeBlock = $("codeBlock");
  const selection = window.getSelection();
  if (!codeBlock || !selection || selection.rangeCount < 1 || selection.isCollapsed) return null;

  const range = selection.getRangeAt(0);
  if (!range || !codeBlock.contains(range.startContainer) || !codeBlock.contains(range.endContainer)) return null;

  const keyword = normalizeCodeSelectionSearchKeyword(selection.toString());
  if (!hasExecutableSearchKeyword(keyword)) return null;

  return {
    keyword,
    range: range.cloneRange(),
    path: String(currentCodePath || "")
  };
}

function captureCodeSelectionSearchState() {
  const candidate = getCodeSelectionSearchCandidate();
  codeSelectionSearchState = candidate;
  codeSelectionSearchClickArmed = null;
  // �h���b�O�I�𒼌�Ƀu���E�U��click�𔭉΂��Ă��A������Java�N���X/�e�[�u�������N����N�������Ȃ��B
  codeSelectionSearchSuppressImmediateClick = Boolean(candidate);
  return candidate;
}

function isPointInsideStoredCodeSelection(range, clientX, clientY) {
  if (!range || typeof range.getClientRects !== "function") return false;
  const x = Number(clientX);
  const y = Number(clientY);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return false;

  const rects = Array.from(range.getClientRects ? range.getClientRects() : []);
  return rects.some(rect => x >= rect.left - 1 && x <= rect.right + 1 && y >= rect.top - 1 && y <= rect.bottom + 1);
}

function resolveCurrentSourceProjectForSearch() {
  const meta = currentCodeMeta && typeof currentCodeMeta === "object" ? currentCodeMeta : {};
  const path = String(currentCodePath || meta.path || meta.fullPath || "");
  const exactCandidates = [
    normalizeProjectValue(meta.project || ""),
    normalizeProjectValue(extractProjectFromPath(path) || "")
  ].filter(Boolean);

  const select = $("groupSelect");
  if (!select || !select.options) return exactCandidates[0] || "";
  const options = Array.from(select.options).filter(option => option && !option.disabled && option.value !== "ALL");

  for (const candidate of exactCandidates) {
    const exact = options.find(option => normalizeProjectValue(option.value).toLowerCase() === candidate.toLowerCase());
    if (exact) return exact.value;
  }

  const group = normalizeMigrationGroupName(
    meta.group || meta.migrationGroup || extractMigrationGroupFromPath(path) || exactCandidates[0] || ""
  );
  if (group) {
    const key = group.toLowerCase();
    const matched = options.find(option => {
      const values = [option.value, option.textContent]
        .map(normalizeMigrationGroupName)
        .map(value => String(value || "").toLowerCase());
      return values.includes(key);
    });
    if (matched) return matched.value;
  }

  return exactCandidates[0] || group || "";
}

function applySelectedCodeTextSearchConditions(keyword) {
  const keywordInput = $("keywordInput");
  if (keywordInput) keywordInput.value = keyword;

  const groupSelect = $("groupSelect");
  const project = resolveCurrentSourceProjectForSearch();
  if (groupSelect && project) {
    const exactOption = Array.from(groupSelect.options || []).find(option => !option.disabled && option.value === project);
    if (exactOption) {
      groupSelect.value = exactOption.value;
    } else {
      // ���݊J���Ă�����\�[�X��project������option�ɖ����ꍇ���AServlet�֐�����project��n����悤�⊮����B
      const option = document.createElement("option");
      option.value = project;
      option.textContent = normalizeMigrationGroupName(project) || project;
      groupSelect.appendChild(option);
      groupSelect.value = project;
    }
    refreshGroupCombo({ resetFilter: true });
  }
}

function runSearchFromSelectedCodeText(keyword) {
  const normalizedKeyword = normalizeCodeSelectionSearchKeyword(keyword);
  if (!hasExecutableSearchKeyword(normalizedKeyword)) return false;

  applySelectedCodeTextSearchConditions(normalizedKeyword);
  clearCodeSelectionSearchState({ clearNativeSelection: true });
  // �����{�^���Ɠ���̒ʏ팟���o�H���g�p���A�ŏI�I�ɂ�Servlet /search��POST����B
  return runSearchFromCurrentInput("normal");
}

function bindCodeSelectionSearch() {
  const codeBlock = $("codeBlock");
  if (!codeBlock) return;

  codeBlock.addEventListener("mouseup", event => {
    if (event.button !== 0) return;
    // �����I��͈͂��N���b�N���Č�����\��ς݂̏ꍇ�́Aclick�܂ŗ\���Ԃ�ێ�����B
    if (codeSelectionSearchClickArmed) return;
    // �h���b�O�I�𒼌��mouseup�ł̓l�C�e�B�uSelection��ێ�����B�I�𒆂̔w�i�F��CSS ::selection�ŉ��F�\������B
    captureCodeSelectionSearchState();
  });

  codeBlock.addEventListener("mousedown", event => {
    codeSelectionSearchClickArmed = null;
    // ��������̓��[�U�[�́u���̃N���b�N�v�Ȃ̂ŁA�h���b�O����click�}�~�t���O�͉�������B
    codeSelectionSearchSuppressImmediateClick = false;
    if (event.button !== 0 || !codeSelectionSearchState) return;
    if (codeSelectionSearchState.path !== String(currentCodePath || "")) return;
    if (!isPointInsideStoredCodeSelection(codeSelectionSearchState.range, event.clientX, event.clientY)) return;

    // �I��͈͓������ɃN���b�N�����ꍇ����������\�񂷂�B
    // preventDefault�Ńu���E�U��mousedown����Selection����������̂�h���A���F�\����click�܂ňێ�����B
    event.preventDefault();
    codeSelectionSearchClickArmed = codeSelectionSearchState;
  });

  codeBlock.addEventListener("click", event => {
    const armed = codeSelectionSearchClickArmed;
    codeSelectionSearchClickArmed = null;
    if (armed && armed.path === String(currentCodePath || "")) {
      event.preventDefault();
      event.stopPropagation();
      runSearchFromSelectedCodeText(armed.keyword);
      return;
    }

    // �h���b�O�I�𑀍삻�̂��̂ɕt�����Ĕ�������click�͌����ł͂Ȃ��B
    // ���ʂ�codeKeywordLink�N���b�N�ւ��������A�I����Ԃ������F�Ŏc���B
    if (codeSelectionSearchSuppressImmediateClick && codeSelectionSearchState) {
      codeSelectionSearchSuppressImmediateClick = false;
      event.preventDefault();
      event.stopPropagation();
    }
  });

  // 2026-08-19 fix139: ���F�őI�𒆂̃\�[�X������́A�N���b�N�����łȂ�Enter�ł������ʏ팟�������s����B
  // �l�C�e�B�uSelection�����݂�codeBlock���Ɏ��݂���ꍇ�������΂��A��UI�փt�H�[�J�X�ړ��ς݂Ȃ牽�����Ȃ��B
  document.addEventListener("keydown", event => {
    if (event.key !== "Enter" || event.isComposing || event.shiftKey || event.ctrlKey || event.altKey || event.metaKey) return;
    if (currentView !== "code" || activeCodePanel !== "source" || !codeSelectionSearchState) return;

    const activeElement = document.activeElement;
    if (activeElement
        && activeElement !== document.body
        && activeElement !== document.documentElement
        && !codeBlock.contains(activeElement)) {
      return;
    }

    const candidate = getCodeSelectionSearchCandidate();
    if (!candidate || candidate.path !== String(currentCodePath || "")) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    codeSelectionSearchState = candidate;
    runSearchFromSelectedCodeText(candidate.keyword);
  }, true);
}

function runSearchFromCurrentInput(mode = "normal") {
  const params = buildSearchParams(mode);
  if (!hasExecutableSearchKeyword(params.rawKeyword)) return false;
  // [5] �������s���̂��̂�1�����Ƃ��ĕۑ����邽�߁A�Œ�ID��view:search�͂����ł͐ς܂Ȃ��B
  showView("search", { recordNavigation: false });
  runSearch(true, mode, { paramsOverride: params });
  return true;
}

function buildSearchParams(mode = "normal") {
  const keywordInput = $("keywordInput");
  const projectSelect = $("groupSelect");
  const directoryGroupSelect = $("directoryGroupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  const rawKeyword = keywordInput ? keywordInput.value.trim() : "";
  // 0�s�ڑ����́u�I���Ȃ��v�́A���������Ƃ��Ă͑S�������ɂ���B
  const project = projectSelect && projectSelect.value ? projectSelect.value : "ALL";
  const directoryGroup = normalizeDirectoryGroupFilterValue(
    directoryGroupSelect && directoryGroupSelect.value ? directoryGroupSelect.value : "ALL"
  );
  const language = normalizeLanguageValueForKrugle(languageSelect && languageSelect.value ? languageSelect.value : "ALL");
  const languageForApi = language;
  const projectText = optionText(projectSelect) || (project === "ALL" ? "���ׂ�" : project);
  const directoryGroupText = optionText(directoryGroupSelect) || (directoryGroup === "ALL" ? "���ׂ�" : directoryGroup);
  const languageText = getLanguageDisplayTextForSearch(languageSelect, language);

  return {
    rawKeyword,
    keyword: normalizeKeywordForMode(rawKeyword, mode),
    project,
    projectText,
    directoryGroup,
    directoryGroupText,
    language,
    languageText,
    languageForApi,
    findin: "ALL",
    clone: cloneCheck && cloneCheck.checked ? "NO" : "YES",
    source_disp: "NO"
  };
}


function buildSearchParamsFromCondition(condition, mode = "normal") {
  const source = condition || {};
  const rawKeyword = String(source.keyword || "").trim();
  const project = String(source.project || "ALL").trim() || "ALL";
  const directoryGroup = normalizeDirectoryGroupFilterValue(String(source.directoryGroup || "ALL").trim() || "ALL");
  const language = normalizeLanguageValueForKrugle(String(source.language || "ALL").trim() || "ALL");
  const languageForApi = language;
  const projectText = project === "ALL" ? "���ׂ�" : normalizeMigrationGroupName(project) || project;
  const directoryGroupText = directoryGroup === "ALL" ? "���ׂ�" : directoryGroup;
  const languageText = language === "ALL" ? "���ׂ�" : language;

  return {
    rawKeyword,
    keyword: normalizeKeywordForMode(rawKeyword, mode),
    project,
    projectText,
    directoryGroup,
    directoryGroupText,
    language,
    languageText,
    languageForApi,
    findin: String(source.findin || "ALL").trim() || "ALL",
    clone: source.clone || "YES",
    source_disp: source.source_disp || "NO"
  };
}


function normalizeDirectoryGroupFilterValue(value) {
  const text = String(value == null ? "" : value).trim();
  if (!text || text.toUpperCase() === "ALL" || text === "���ׂ�") return "ALL";
  return cleanDirectoryGroupName(text) || text;
}

function getDirectoryGroupLookupMigrationGroup(projectValue) {
  const normalized = normalizeMigrationGroupName(projectValue);
  if (!normalized) return "";
  // nikkoEZ.java17 ��AI_FILE1�ɒ��ڃ��R�[�h���Ȃ����߁A������Java�N���X�����Ɠ��l��nikkoEZ���Q�Ƃ���B
  return /^nikkoEZ\.java17$/i.test(normalized) ? "nikkoEZ" : normalized;
}

function getRecentDirectoryGroupsForMigrationGroup(projectValue) {
  const selectedGroup = normalizeMigrationGroupName(projectValue).toLowerCase();
  const lookupGroup = getDirectoryGroupLookupMigrationGroup(projectValue).toLowerCase();
  const result = [];
  const used = new Set();

  getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT).forEach(value => {
    const parts = formatHistoryFileParts(value);
    const historyGroup = normalizeMigrationGroupName(parts[1]).toLowerCase();
    if (historyGroup !== selectedGroup && historyGroup !== lookupGroup) return;

    const directoryGroup = normalizeDirectoryGroupFilterValue(parts[2]);
    if (directoryGroup === "ALL" || isPlaceholderHistoryValue(directoryGroup)) return;
    const key = directoryGroup.toLowerCase();
    if (used.has(key)) return;
    used.add(key);
    result.push(directoryGroup);
  });

  return result;
}

function resetDirectoryGroupSelect(message = "") {
  const select = $("directoryGroupSelect");
  if (!select) return;
  select.innerHTML = "";
  const all = document.createElement("option");
  all.value = "ALL";
  all.textContent = "���ׂ�";
  select.appendChild(all);

  if (message) {
    const note = document.createElement("option");
    note.value = "";
    note.disabled = true;
    note.textContent = message;
    select.appendChild(note);
  }
  select.value = "ALL";
}

function renderDirectoryGroupSelectOptions(projectValue, rows, preserveValue = "ALL") {
  const select = $("directoryGroupSelect");
  if (!select) return;

  const values = [];
  const used = new Set();
  (Array.isArray(rows) ? rows : []).forEach(row => {
    const value = normalizeDirectoryGroupFilterValue(
      row && typeof row === "object" ? (row.directoryGroup || row.dirGroup || row.DIRGROUP || "") : row
    );
    if (!value || value === "ALL" || isPlaceholderHistoryValue(value)) return;
    const key = value.toLowerCase();
    if (used.has(key)) return;
    used.add(key);
    values.push(value);
  });

  const recent = getRecentDirectoryGroupsForMigrationGroup(projectValue)
    .filter(value => used.has(value.toLowerCase()));
  const recentSet = new Set(recent.map(value => value.toLowerCase()));
  const others = values
    .filter(value => !recentSet.has(value.toLowerCase()))
    .sort((a, b) => a.localeCompare(b, "ja", { numeric: true, sensitivity: "variant" }));

  select.innerHTML = "";
  const all = document.createElement("option");
  all.value = "ALL";
  all.textContent = "���ׂ�";
  select.appendChild(all);

  const appendGroup = (label, items) => {
    if (!items.length) return;
    const group = document.createElement("optgroup");
    group.label = label;
    items.forEach(value => {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      group.appendChild(option);
    });
    select.appendChild(group);
  };

  appendGroup("�ŋ߉{��", recent);
  appendGroup("�f�B���N�g���O���[�v", others);

  const desired = normalizeDirectoryGroupFilterValue(preserveValue);
  select.value = Array.from(select.options).some(option => option.value === desired) ? desired : "ALL";
}

async function loadDirectoryGroupsForSelectedMigrationGroup(options = {}) {
  const projectSelect = $("groupSelect");
  const directorySelect = $("directoryGroupSelect");
  if (!directorySelect) return;

  const selectedProject = projectSelect && projectSelect.value ? projectSelect.value : "ALL";
  const preserveValue = options.preserveValue !== false ? directorySelect.value || "ALL" : "ALL";
  if (!selectedProject || selectedProject === "ALL") {
    resetDirectoryGroupSelect();
    return;
  }

  const lookupGroup = getDirectoryGroupLookupMigrationGroup(selectedProject);
  if (!lookupGroup) {
    resetDirectoryGroupSelect();
    return;
  }

  const cacheKey = lookupGroup.toLowerCase();
  const loadId = ++directoryGroupLoadSequence;
  if (directoryGroupOptionsCache.has(cacheKey)) {
    renderDirectoryGroupSelectOptions(selectedProject, directoryGroupOptionsCache.get(cacheKey), preserveValue);
    return;
  }

  resetDirectoryGroupSelect("�Ǎ���...");
  try {
    const data = await fetchJson(DIRECTORY_GROUP_ENDPOINT, { group: lookupGroup }, {
      method: "GET",
      timeoutMs: API_ACCESS_TIMEOUT_MS
    });
    if (loadId !== directoryGroupLoadSequence) return;
    const rows = Array.isArray(data && data.rows) ? data.rows : [];
    directoryGroupOptionsCache.set(cacheKey, rows);
    renderDirectoryGroupSelectOptions(selectedProject, rows, preserveValue);
  } catch (e) {
    if (loadId !== directoryGroupLoadSequence) return;
    console.warn("�f�B���N�g���O���[�v�擾���s", e);
    resetDirectoryGroupSelect("�擾�ł��܂���ł���");
  }
}

function filterSearchResultsByDirectoryGroup(rows, directoryGroup) {
  const target = normalizeDirectoryGroupFilterValue(directoryGroup);
  const source = Array.isArray(rows) ? rows : [];
  if (target === "ALL") {
    return source.map((row, index) => Object.assign({}, row, { no: String(index + 1) }));
  }

  const targetKey = target.toLowerCase();
  return source
    .filter(row => normalizeDirectoryGroupFilterValue(row && row.directoryGroup).toLowerCase() === targetKey)
    .map((row, index) => Object.assign({}, row, { no: String(index + 1) }));
}

function clearInitialSearchForm() {
  const keywordInput = $("keywordInput");
  const groupSelect = $("groupSelect");
  const directoryGroupSelect = $("directoryGroupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  if (keywordInput) keywordInput.value = "";
  setSelectValueByTextOrValue(groupSelect, "ALL", "ALL");
  if (directoryGroupSelect) resetDirectoryGroupSelect();
  setSelectValueByTextOrValue(languageSelect, "ALL", "ALL");
  if (cloneCheck) cloneCheck.checked = false;
  refreshGroupCombo({ resetFilter: true });
}

// 2026-08-18 fix121: ���������p�l���̏��^�N���A�{�^���B
// �������͂�������ԁi�L�[���[�h��A�ڍs�O���[�v/����=���ׂāAClone���`�F�b�N�j�֖߂��A
// �������ʂ̗�t�B���^�[���������āu�������c���Č����Ȃ��v��Ԃ�h���B
function clearAllSearchConditions() {
  clearInitialSearchForm();
  resetSearchResultColumnFilters({ render: true });
  const keywordInput = $("keywordInput");
  if (keywordInput) {
    window.requestAnimationFrame(() => keywordInput.focus({ preventScroll: true }));
  }
}

// 2026-08-20 fix148: ��������3���ڂ̉E�[�~�́A���̍��ڂ���������Ԃ֖߂��B
function clearSingleSearchCondition(type) {
  if (type === "keyword") {
    const keywordInput = $("keywordInput");
    if (keywordInput) {
      keywordInput.value = "";
      keywordInput.focus({ preventScroll: true });
    }
    return;
  }

  if (type === "group") {
    const groupSelect = $("groupSelect");
    setSelectValueByTextOrValue(groupSelect, "ALL", "ALL");
    refreshGroupCombo({ resetFilter: true });
    loadDirectoryGroupsForSelectedMigrationGroup({ preserveValue: false });
    return;
  }

  if (type === "language") {
    setSelectValueByTextOrValue($("languageSelect"), "ALL", "ALL");
  }
}

function normalizeSearchRow(row, index = 0) {
  const source = row || {};
  const fileName = source.fileName || source.file || source.name || "";
  const project = normalizeProjectValue(source.project || source.projectName || source.projectValue || "");
  const rawPath = source.fullPath || source.filePath || source.path || fileName;
  const path = buildCompleteKruglePath(rawPath, project, source.group || source.migrationGroup || source.ikogroup || source.ikoGroup || "");
  const projectParts = String(project).split(".");
  const sourceGroup = normalizeMigrationGroupName(source.group || source.migrationGroup || source.ikogroup || source.ikoGroup || "");
  const pathGroup = normalizeMigrationGroupName(extractMigrationGroupFromPath(path));
  const projectGroup = normalizeMigrationGroupName(project);
  const legacyProjectGroup = normalizeMigrationGroupName(projectParts.length > 1 ? projectParts.slice(1).join(".") : projectParts[0]);
  // ���S�p�X/Project�͈ڍs�O���[�v���̐��{�Ƃ��Ĉ����A��Servlet�� java17 �̂悤��
  // ���������Ԃ����ꍇ�ł� nikkoEZ.java17 �֎��ȏC���ł���悤�ɂ���B
  const group = pathGroup || projectGroup || sourceGroup || legacyProjectGroup || "";
  const directoryGroup = cleanDirectoryGroupName(source.directoryGroup || source.dirGroup || source.directory || extractDirectoryGroupFromPath(path));

  return {
    no: source.no || String(index + 1),
    fileName,
    lineNo: source.lineNo || source.line || "",
    project,
    group,
    directoryGroup,
    path,
    href: source.href || "",
    sourceUrl: source.sourceUrl || "",
    preview: source.preview || "",
    language: source.language || inferLanguageFromPath(path, "java")
  };
}

function normalizeSearchResultSortKey(value) {
  return String(value || "").trim().toLowerCase();
}

function addPriorityRank(map, value) {
  const key = normalizeSearchResultSortKey(value);
  if (!key || isPlaceholderHistoryValue(key) || map.has(key)) return;
  map.set(key, map.size);
}

function buildSearchResultPriorityMapsFromHistory() {
  const groupRank = new Map();
  const directoryGroupRank = new Map();
  const values = getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT);

  values.forEach(value => {
    const parts = formatHistoryFileParts(value);
    addPriorityRank(groupRank, parts[1]);
    addPriorityRank(directoryGroupRank, parts[2]);
  });

  return { groupRank, directoryGroupRank };
}

function getPriorityRank(map, value) {
  const key = normalizeSearchResultSortKey(value);
  return map && map.has(key) ? map.get(key) : Number.MAX_SAFE_INTEGER;
}

function getSearchResultLanguageRank(row) {
  const language = String(row && (row.language || inferLanguageFromPath(row.path, "")) || "").trim().toLowerCase();
  if (language === "java") return 0;
  if (language === "sql") return 1;

  const pathLanguage = inferLanguageFromPath(row && row.path, "").toLowerCase();
  if (pathLanguage === "java") return 0;
  if (pathLanguage === "sql") return 1;
  return 2;
}

function compareSearchResultRowsByHistoryPriority(a, b, priorityMaps) {
  const groupDiff = getPriorityRank(priorityMaps.groupRank, a.group) - getPriorityRank(priorityMaps.groupRank, b.group);
  if (groupDiff !== 0) return groupDiff;

  const directoryDiff = getPriorityRank(priorityMaps.directoryGroupRank, a.directoryGroup) - getPriorityRank(priorityMaps.directoryGroupRank, b.directoryGroup);
  if (directoryDiff !== 0) return directoryDiff;

  const languageDiff = getSearchResultLanguageRank(a) - getSearchResultLanguageRank(b);
  if (languageDiff !== 0) return languageDiff;

  const nameA = String(a.fileName || a.path || "");
  const nameB = String(b.fileName || b.path || "");
  const nameDiff = nameA.localeCompare(nameB, "ja", { numeric: true, sensitivity: "variant" });
  if (nameDiff !== 0) return nameDiff;

  return String(a.path || "").localeCompare(String(b.path || ""), "ja", { numeric: true, sensitivity: "variant" });
}

function buildSearchResultSortRecord(row, index, priorityMaps) {
  const normalized = normalizeSearchRow(row, index);
  const languageRank = getSearchResultLanguageRank(normalized);
  return {
    row: normalized,
    index,
    groupRank: getPriorityRank(priorityMaps.groupRank, normalized.group),
    directoryGroupRank: getPriorityRank(priorityMaps.directoryGroupRank, normalized.directoryGroup),
    languageRank,
    fileNameKey: String(normalized.fileName || normalized.path || ""),
    pathKey: String(normalized.path || "")
  };
}

function compareSearchResultSortRecords(a, b) {
  // fix91: Servlet�����肵���u�����L�[���[�h == �t�@�C�����v�̊��S��v���ŗD��ňێ�����B
  const exactDiff = Number(Boolean(b.row && b.row.exactFileNameMatch)) - Number(Boolean(a.row && a.row.exactFileNameMatch));
  if (exactDiff !== 0) return exactDiff;

  const groupDiff = a.groupRank - b.groupRank;
  if (groupDiff !== 0) return groupDiff;

  const directoryDiff = a.directoryGroupRank - b.directoryGroupRank;
  if (directoryDiff !== 0) return directoryDiff;

  const languageDiff = a.languageRank - b.languageRank;
  if (languageDiff !== 0) return languageDiff;

  const nameDiff = a.fileNameKey.localeCompare(b.fileNameKey, "ja", { numeric: true, sensitivity: "variant" });
  if (nameDiff !== 0) return nameDiff;

  const pathDiff = a.pathKey.localeCompare(b.pathKey, "ja", { numeric: true, sensitivity: "variant" });
  return pathDiff !== 0 ? pathDiff : a.index - b.index;
}

function sortSearchResultsForDisplay(rows) {
  const priorityMaps = buildSearchResultPriorityMapsFromHistory();
  return (Array.isArray(rows) ? rows : [])
    .map((row, index) => buildSearchResultSortRecord(row, index, priorityMaps))
    .sort(compareSearchResultSortRecords)
    .map((item, index) => Object.assign({}, item.row, { no: String(index + 1) }));
}


function normalizeCloneDisplayValue(value, params) {
  const raw = value == null ? "" : String(value).trim();
  if (raw === "YES" || raw === "�\��" || raw === "�\������") return "�\��";
  if (raw === "NO" || raw === "��\��" || raw === "�\�����Ȃ�") return "��\��";

  // ��WAR�œ��{��萔�������������Ă��Ă��A���M����clone�������琳�����\������B
  return params && params.clone === "YES" ? "�\��" : "��\��";
}

function setText(id, value) {
  const element = $(id);
  if (element) element.textContent = value == null ? "" : String(value);
}

function setSummaryFromParams(params, startedAt, endedAt, hitCount) {
  setText("summaryCount", hitCount == null ? "-" : hitCount);
  setText("summaryKeyword", params ? params.rawKeyword : "");
  setText("summaryProject", params ? (params.projectText || params.project) : "");
  setText("summaryDirectoryGroup", params ? (params.directoryGroupText || params.directoryGroup || "ALL") : "ALL");
  setText("summaryLanguage", params ? (params.languageText || params.language) : "");
  setText("summaryStart", startedAt ? formatDateTime(startedAt) : "-");
  setText("summaryEnd", endedAt ? formatDateTime(endedAt) : "-");
  setText("summaryClone", params && params.clone === "YES" ? "�\��" : "��\��");
}

function setSummaryFromServer(summary, params, startedAt, endedAt, fallbackCount) {
  const source = summary || {};
  const hasDirectoryFilter = params && normalizeDirectoryGroupFilterValue(params.directoryGroup) !== "ALL";
  setText("summaryCount", hasDirectoryFilter ? fallbackCount : (source.hitCount || source.count || fallbackCount || 0));
  setText("summaryKeyword", source.keyword || (params ? params.rawKeyword : ""));
  setText("summaryProject", source.project || (params ? (params.projectText || params.project) : ""));
  setText("summaryDirectoryGroup", params ? (params.directoryGroupText || params.directoryGroup || "ALL") : "ALL");
  setText("summaryLanguage", source.language || (params ? (params.languageText || params.language) : ""));
  setText("summaryStart", formatSummaryDateTimeValue(source.startTime, startedAt));
  setText("summaryEnd", formatSummaryDateTimeValue(source.endTime, endedAt));
  setText("summaryClone", normalizeCloneDisplayValue(source.clone, params));
}

// 2026-08-18 fix112: 2000���������ł�Servlet��result.cgi�̐擪100�������Ԃ��B
// ���̏�Ԃ��������ʉ�ʂɏ펞�\�����A�^�C���A�E�g����̂��ߌ��������ύX�𑣂��B
function setSearchResultLimitNotice(data) {
  const notice = $("searchResultLimitNotice");
  if (!notice) return;

  const source = data || {};
  const summary = source.summary || {};
  const limited = Boolean(source.limited || source.resultLimited || summary.limited || summary.resultLimited);
  if (!limited) {
    notice.hidden = true;
    notice.textContent = "";
    return;
  }

  const message = String(
    source.notice ||
    source.limitNotice ||
    summary.notice ||
    summary.limitNotice ||
    "�������ʂ�2000���ȏ�ł��B�����Ɏ��Ԃ�������^�C���A�E�g���N����\�������邽�߁A100���̂ݕ\�����Ă��܂��B����������ύX���Ă��������B"
  ).trim();
  notice.textContent = message;
  notice.hidden = false;
}

function buildInitialResultPlaceholderRows(count = INITIAL_RESULT_PLACEHOLDER_COUNT) {
  return Array.from({ length: count }, (_, index) => ({
    no: String(index + 1),
    fileName: HISTORY_PLACEHOLDER_VALUE,
    group: HISTORY_PLACEHOLDER_VALUE,
    directoryGroup: HISTORY_PLACEHOLDER_VALUE,
    path: HISTORY_PLACEHOLDER_VALUE,
    placeholder: true
  }));
}

function normalizeSearchResultFilterText(value) {
  let text = String(value == null ? "" : value);
  try {
    text = text.normalize("NFKC");
  } catch (e) {
    // normalize���Ή����ł͌�������̂܂ܔ�r����B
  }
  return text.toLocaleLowerCase("ja-JP").trim();
}

function getSearchResultFilterCellValue(row, key) {
  const normalized = normalizeSearchRow(row || {}, 0);
  if (key === "fileName") return normalized.fileName || normalized.path || "";
  if (key === "group") return normalized.group || normalized.project || "";
  if (key === "directoryGroup") return normalized.directoryGroup || "";
  if (key === "path") return normalized.path || "";
  return "";
}

function hasActiveSearchResultColumnFilters() {
  return SEARCH_RESULT_FILTER_KEYS.some(key => normalizeSearchResultFilterText(searchResultColumnFilters[key]));
}

function filterSearchResultsByColumnFilters(rows) {
  const source = Array.isArray(rows) ? rows : [];
  const active = SEARCH_RESULT_FILTER_KEYS
    .map(key => [key, normalizeSearchResultFilterText(searchResultColumnFilters[key])])
    .filter(([, value]) => Boolean(value));
  if (!active.length) return source.slice();

  return source.filter(row => active.every(([key, filterValue]) =>
    normalizeSearchResultFilterText(getSearchResultFilterCellValue(row, key)).includes(filterValue)
  ));
}

function syncSearchResultColumnFilterUi(options = {}) {
  const row = $("resultColumnFilterRow");
  if (row) row.hidden = !activeSearchResultFilterKey;

  document.querySelectorAll(".resultColumnFilterToggle[data-result-filter-key]").forEach(button => {
    const key = button.dataset.resultFilterKey || "";
    const expanded = key === activeSearchResultFilterKey;
    button.setAttribute("aria-expanded", expanded ? "true" : "false");
    button.classList.toggle("isOpen", expanded);
    button.classList.toggle("isFiltered", Boolean(normalizeSearchResultFilterText(searchResultColumnFilters[key])));
  });

  document.querySelectorAll(".resultColumnFilterField[data-result-filter-field]").forEach(field => {
    const key = field.dataset.resultFilterField || "";
    field.hidden = key !== activeSearchResultFilterKey;
  });

  document.querySelectorAll(".resultColumnFilterInput[data-result-filter-input]").forEach(input => {
    const key = input.dataset.resultFilterInput || "";
    if (input.value !== String(searchResultColumnFilters[key] || "")) input.value = searchResultColumnFilters[key] || "";
  });

  if (options.focus === true && activeSearchResultFilterKey) {
    const input = document.querySelector(`.resultColumnFilterInput[data-result-filter-input="${activeSearchResultFilterKey}"]`);
    if (input) {
      window.requestAnimationFrame(() => {
        input.focus({ preventScroll: true });
        const length = input.value.length;
        if (typeof input.setSelectionRange === "function") input.setSelectionRange(length, length);
      });
    }
  }
}

function updateSearchResultFilterSummaryCount(filteredRows) {
  const summaryCount = $("summaryCount");
  if (!hasActiveSearchResultColumnFilters()) {
    if (searchResultFilterSummaryBaseText) {
      setText("summaryCount", searchResultFilterSummaryBaseText);
      searchResultFilterSummaryBaseText = "";
    }
    return;
  }
  if (!searchResultFilterSummaryBaseText && summaryCount) {
    searchResultFilterSummaryBaseText = String(summaryCount.textContent || "").trim();
  }
  setText("summaryCount", Array.isArray(filteredRows) ? filteredRows.length : 0);
}

function renderSearchResultsWithColumnFilters() {
  const filteredRows = filterSearchResultsByColumnFilters(lastSearchResults);
  const renderInfo = renderSearchRows(filteredRows, { normalized: true });
  updateSearchResultFilterSummaryCount(filteredRows);
  return renderInfo;
}

function resetSearchResultColumnFilters(options = {}) {
  SEARCH_RESULT_FILTER_KEYS.forEach(key => { searchResultColumnFilters[key] = ""; });
  activeSearchResultFilterKey = "";
  searchResultFilterSummaryBaseText = "";
  syncSearchResultColumnFilterUi();
  if (options.render === true) renderSearchResultsWithColumnFilters();
}

function bindSearchResultColumnFilters() {
  const filterRow = $("resultColumnFilterRow");
  if (!filterRow || filterRow.__krugleColumnFilterBound === true) return;
  filterRow.__krugleColumnFilterBound = true;

  document.querySelectorAll(".resultColumnFilterToggle[data-result-filter-key]").forEach(button => {
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      const key = button.dataset.resultFilterKey || "";
      if (!SEARCH_RESULT_FILTER_KEYS.includes(key)) return;
      activeSearchResultFilterKey = activeSearchResultFilterKey === key ? "" : key;
      syncSearchResultColumnFilterUi({ focus: Boolean(activeSearchResultFilterKey) });
    });
  });

  document.querySelectorAll(".resultColumnFilterInput[data-result-filter-input]").forEach(input => {
    input.addEventListener("input", () => {
      const key = input.dataset.resultFilterInput || "";
      if (!SEARCH_RESULT_FILTER_KEYS.includes(key)) return;
      searchResultColumnFilters[key] = input.value || "";
      renderSearchResultsWithColumnFilters();
      syncSearchResultColumnFilterUi();
    });
    input.addEventListener("keydown", event => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      activeSearchResultFilterKey = "";
      syncSearchResultColumnFilterUi();
    });
  });

  document.querySelectorAll(".resultColumnFilterClear[data-result-filter-clear]").forEach(button => {
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      const key = button.dataset.resultFilterClear || "";
      if (!SEARCH_RESULT_FILTER_KEYS.includes(key)) return;
      searchResultColumnFilters[key] = "";
      activeSearchResultFilterKey = "";
      const input = document.querySelector(`.resultColumnFilterInput[data-result-filter-input="${key}"]`);
      if (input) input.value = "";
      renderSearchResultsWithColumnFilters();
      syncSearchResultColumnFilterUi();
    });
  });

  syncSearchResultColumnFilterUi();
}

function renderInitialResultPlaceholders() {
  renderSearchInitialEmptyState();
}

function renderSearchInitialEmptyState() {
  const body = $("resultBody");
  if (!body) return;
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.add("isInitialEmptyResultCard");
    card.classList.remove("hasSearchResultRows");
  }
  body.innerHTML = `
    <tr class="resultEmptyStateRow">
      <td colspan="5">
        <div class="resultEmptyStateMessage">�������ʂ������ɕ\������܂�</div>
      </td>
    </tr>
  `;
}

function resetInitialSearchSummary() {
  setText("summaryCount", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryKeyword", "");
  setText("summaryProject", "ALL");
  setText("summaryDirectoryGroup", "ALL");
  setText("summaryLanguage", "ALL");
  setText("summaryStart", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryEnd", HISTORY_PLACEHOLDER_VALUE);
  setText("summaryClone", "��\��");
}

function getSearchRowFromElement(rowElement, fallbackIndex = 0) {
  const index = Number(rowElement && rowElement.dataset ? rowElement.dataset.index : fallbackIndex);
  if (Number.isFinite(index) && currentRenderedSearchRows[index]) return currentRenderedSearchRows[index];
  return normalizeSearchRow({
    no: rowElement && rowElement.dataset ? rowElement.dataset.no || String(fallbackIndex + 1) : String(fallbackIndex + 1),
    fileName: rowElement && rowElement.dataset ? rowElement.dataset.fileName || "" : "",
    project: rowElement && rowElement.dataset ? rowElement.dataset.project || "" : "",
    group: rowElement && rowElement.dataset ? rowElement.dataset.group || "" : "",
    directoryGroup: rowElement && rowElement.dataset ? rowElement.dataset.directoryGroup || "" : "",
    path: rowElement && rowElement.dataset ? rowElement.dataset.path || "" : "",
    href: rowElement && rowElement.dataset ? rowElement.dataset.href || "" : "",
    sourceUrl: rowElement && rowElement.dataset ? rowElement.dataset.sourceUrl || "" : "",
    preview: rowElement ? rowElement.getAttribute("aria-label") || (rowElement.dataset ? rowElement.dataset.path || "" : "") : "",
    language: rowElement && rowElement.dataset ? rowElement.dataset.language || "" : ""
  }, fallbackIndex);
}

function bindResultRowEvents(body, normalizedRows = []) {
  if (!body) return;
  currentRenderedSearchRows = Array.isArray(normalizedRows) ? normalizedRows : [];
  if (body.__krugleResultRowDelegatedClickBound === true) return;
  body.__krugleResultRowDelegatedClickBound = true;
  body.addEventListener("click", event => {
    const rowElement = event.target && event.target.closest ? event.target.closest("tr[data-index]") : null;
    if (!rowElement || !body.contains(rowElement)) return;
    const index = Number(rowElement.dataset.index);
    const row = getSearchRowFromElement(rowElement, Number.isFinite(index) ? index : 0);
    if (row && !row.placeholder) {
      // [5] ��Krugle�̃����Nvisited�����B���S�p�X��SessionStorage�֕ۑ����Ă���\�[�X�֑J�ڂ���B
      markSearchResultVisited(row.path);
      openCode(row.path, { row });
    }
  });
}

function setResultCardState(rowCount) {
  const card = document.querySelector("#searchView .resultCard");
  if (card) {
    card.classList.remove("isInitialEmptyResultCard");
    card.classList.toggle("hasSearchResultRows", Number(rowCount || 0) > 0);
  }
}

function buildSearchResultRowHtml(row, index) {
  const visited = !row.placeholder && isSearchResultVisited(row.path);
  const rowClasses = [
    row.placeholder ? "isPlaceholderResultRow" : "",
    visited ? "isVisitedResult" : ""
  ].filter(Boolean).join(" ");
  return `
    <tr class="${rowClasses}"${visited ? ' data-visited="true"' : ""}
        data-index="${index}"
        data-no="${escapeHtml(row.no || String(index + 1))}"
        data-file-name="${escapeHtml(row.fileName || "")}"
        data-project="${escapeHtml(row.project || "")}"
        data-group="${escapeHtml(row.group || "")}"
        data-directory-group="${escapeHtml(row.directoryGroup || "")}"
        data-path="${escapeHtml(row.path || "")}"
        data-language="${escapeHtml(row.language || "")}"
        aria-label="${escapeHtml(row.placeholder ? "" : (row.preview || row.path))}">
      <td>${escapeHtml(row.no || String(index + 1))}</td>
      <td><span class="searchResultFileName">${escapeHtml(row.fileName || row.path)}</span>${visited ? '<span class="searchResultVisitedLabel">�{����</span>' : ''}</td>
      <td>${escapeHtml(row.group || row.project)}</td>
      <td>${escapeHtml(row.directoryGroup || "")}</td>
      <td>${escapeHtml(row.path || "")}</td>
    </tr>
  `;
}

function buildSearchResultRowsHtml(rows, startIndex = 0, endIndex = rows.length) {
  const parts = [];
  const safeEnd = Math.min(endIndex, rows.length);
  for (let index = startIndex; index < safeEnd; index++) {
    parts.push(buildSearchResultRowHtml(rows[index], index));
  }
  return parts.join("");
}

function scheduleSearchRowsAppend(body, rows, startIndex, renderId) {
  const schedule = typeof window.requestIdleCallback === "function"
    ? callback => window.requestIdleCallback(callback, { timeout: 120 })
    : callback => window.requestAnimationFrame(callback);

  const appendChunk = () => {
    if (renderId !== searchRenderSequence) return;
    if (!body || !body.isConnected) return;
    const endIndex = Math.min(startIndex + SEARCH_RENDER_CHUNK_ROWS, rows.length);
    body.insertAdjacentHTML("beforeend", buildSearchResultRowsHtml(rows, startIndex, endIndex));
    if (endIndex < rows.length) {
      scheduleSearchRowsAppend(body, rows, endIndex, renderId);
    }
  };

  schedule(appendChunk);
}

function renderSearchHtml(resultHtml, rows = []) {
  const body = $("resultBody");
  if (!body) return;

  const normalizedRows = Array.isArray(rows) ? rows.map(normalizeSearchRow) : [];
  setResultCardState(normalizedRows.length);
  searchRenderSequence += 1;
  currentRenderedSearchRows = normalizedRows;
  body.innerHTML = resultHtml || `
    <tr class="resultNoDataRow">
      <td colspan="5">�������ʂ�����܂���</td>
    </tr>
  `;
  bindResultRowEvents(body, normalizedRows);
}

function renderSearchRows(rows, options = {}) {
  const body = $("resultBody");
  if (!body) return { rowCount: 0, initialRows: 0, chunked: false };

  const isPlaceholderMode = options && options.placeholder === true;
  const alreadyNormalized = options && options.normalized === true;
  const normalizedRows = Array.isArray(rows)
    ? (isPlaceholderMode || alreadyNormalized ? rows : rows.map(normalizeSearchRow))
    : [];
  const rowCount = normalizedRows.length;
  const renderId = ++searchRenderSequence;
  currentRenderedSearchRows = normalizedRows;
  setResultCardState(rowCount);
  bindResultRowEvents(body, normalizedRows);

  if (!rowCount) {
    body.innerHTML = `
      <tr class="resultNoDataRow">
        <td colspan="5">�������ʂ�����܂���</td>
      </tr>
    `;
    return { rowCount: 0, initialRows: 0, chunked: false };
  }

  const initialRows = rowCount > SEARCH_RENDER_INITIAL_ROWS ? SEARCH_RENDER_INITIAL_ROWS : rowCount;
  body.innerHTML = buildSearchResultRowsHtml(normalizedRows, 0, initialRows);

  if (initialRows < rowCount) {
    scheduleSearchRowsAppend(body, normalizedRows, initialRows, renderId);
  }

  return { rowCount, initialRows, chunked: initialRows < rowCount };
}



// 2026-08-07 �C��19:
// �������ʃ^�u��Copy�ł́AsummaryGrid�i�q�b�g��/����������2�s�j���o�͂��Ȃ��B
// ��ʂ̌������ʃe�[�u���Ɠ���5�񂾂���TSV������B
const SEARCH_RESULT_EXPORT_HEADERS = Object.freeze(["No", "�t�@�C����", "�ڍs�O���[�v", "�f�B���N�g���O���[�v", "�p�X"]);

function getSearchResultExportRows() {
  const sourceRows = Array.isArray(lastSearchResults) && lastSearchResults.length
    ? filterSearchResultsByColumnFilters(lastSearchResults)
    : Array.from(document.querySelectorAll("#resultBody tr[data-index]"))
        .map((rowElement, index) => normalizeSearchRow({
          no: rowElement.dataset.no || String(index + 1),
          fileName: rowElement.dataset.fileName || "",
          project: rowElement.dataset.project || "",
          group: rowElement.dataset.group || "",
          directoryGroup: rowElement.dataset.directoryGroup || "",
          path: rowElement.dataset.path || "",
          language: rowElement.dataset.language || ""
        }, index));

  return sourceRows
    .map((row, index) => normalizeSearchRow(row, index))
    .filter(row => row && !row.placeholder && !isPlaceholderHistoryValue(row.path || row.fileName || ""));
}

function buildSearchResultExportValues(row, index) {
  const normalized = normalizeSearchRow(row, index);
  return [
    normalized.no || String(index + 1),
    normalized.fileName || normalized.path || "",
    normalized.group || normalized.project || "",
    normalized.directoryGroup || "",
    normalized.path || ""
  ];
}

function buildSearchResultCopyText(rows) {
  const body = (Array.isArray(rows) ? rows : []).map((row, index) =>
    buildSearchResultExportValues(row, index).join("\t")
  );
  return [SEARCH_RESULT_EXPORT_HEADERS.join("\t")].concat(body).join("\n");
}


// 2026-08-07 �C��20:
// �z�[���^�u��Copy/Download�ł́ADOM��innerText�����̂܂܎g��Ȃ��B
// historySearchText����span�����s�Ƃ��ăR�s�[�����������邽�߁A
// �\�����f�[�^����TSV��g�ݗ��āA�Z����CR/LF/TAB����������1�s1�����ɌŒ肷��B
const HOME_FILE_HISTORY_EXPORT_HEADERS = Object.freeze(["No", "�ߋ��̉{������ �^ �t�@�C����", "�ڍs�O���[�v", "�f�B���N�g���O���[�v"]);
const HOME_SEARCH_HISTORY_EXPORT_HEADERS = Object.freeze(["No", "�ߋ��̉{������ �^ �����L�[���[�h", "�Ώۃv���W�F�N�g", "����"]);

function normalizeExportCell(value) {
  const text = String(value ?? "")
    .replace(/[\r\n]+/g, " ")
    .replace(/\t+/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
  return text || HISTORY_PLACEHOLDER_VALUE;
}

function buildTsvLine(values) {
  return (Array.isArray(values) ? values : [])
    .map(normalizeExportCell)
    .join("\t");
}

function getHomeFileHistoryExportRows() {
  return filterHistoryFileRows(
    getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT),
    "homeFile"
  );
}

function getHomeSearchHistoryExportRows() {
  let words = USE_SAMPLE_DATA ? sampleSearchWords : readArray(SEARCH_HISTORY_STORAGE_KEY, []);
  if (!USE_SAMPLE_DATA) {
    words = seedHistoryStorage(SEARCH_HISTORY_STORAGE_KEY, words, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }
  return filterHistorySearchRows(getDisplayHistoryRows(words, SEARCH_HISTORY_HOME_DISPLAY_LIMIT));
}

function buildHomeFileHistoryExportValues(value, index) {
  const parts = formatHistoryFileParts(value);
  return [String(index + 1), parts[0], parts[1], parts[2]];
}

function buildHomeSearchHistoryExportValues(value, index) {
  if (isPlaceholderHistoryValue(value)) {
    return [String(index + 1), HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE];
  }
  const parsed = parseSearchHistoryValue(value);
  return [
    String(index + 1),
    parsed.keyword || HISTORY_PLACEHOLDER_VALUE,
    parsed.group || HISTORY_PLACEHOLDER_VALUE,
    parsed.language || HISTORY_PLACEHOLDER_VALUE
  ];
}

function buildHomeHistoryExportText() {
  const fileLines = [buildTsvLine(HOME_FILE_HISTORY_EXPORT_HEADERS)].concat(
    getHomeFileHistoryExportRows().map((value, index) => buildTsvLine(buildHomeFileHistoryExportValues(value, index)))
  );
  const searchLines = [buildTsvLine(HOME_SEARCH_HISTORY_EXPORT_HEADERS)].concat(
    getHomeSearchHistoryExportRows().map((value, index) => buildTsvLine(buildHomeSearchHistoryExportValues(value, index)))
  );
  return fileLines.concat([""], searchLines).join("\n");
}


// 2026-08-07 fix28:
// highlight.js �� .properties / .env / .lst �Ȃǂ̎Г��e�L�X�g�Ō��ꔻ�肪�Ԃ��ƁA
// Cupertino �̔��w�i�������炸���w�i�̂܂܌�����ꍇ������B
// �����̓��[�U�[�v�]�ǂ��� .sh �����A�܂� highlight.js �� bash �Ƃ��ĕ\������B
const SHELL_LIKE_TEXT_EXTENSIONS = new Set([
  "properties", "property", "props", "prop",
  "env", "lst", "list", "txt",
  "conf", "cfg", "cnf", "ini",
  "profile"
]);

function cleanPathForLanguage(path) {
  return String(path || "")
    .split(/[?#]/)[0]
    .replace(/\\/g, "/")
    .toLowerCase();
}

function getPathExtensionForLanguage(path) {
  const value = cleanPathForLanguage(path);
  const fileName = value.substring(value.lastIndexOf("/") + 1);
  const dotIndex = fileName.lastIndexOf(".");
  if (dotIndex < 0) return "";
  return fileName.substring(dotIndex + 1);
}

function isShellLikeTextPath(path) {
  const value = cleanPathForLanguage(path);
  const fileName = value.substring(value.lastIndexOf("/") + 1);
  const extension = getPathExtensionForLanguage(value);
  return SHELL_LIKE_TEXT_EXTENSIONS.has(extension) || fileName === ".env" || fileName.startsWith(".env.");
}

// 2026-08-13 fix69:
// JSP/HTML�n�\�[�X�́A�\�[�X�{�����̂��̂� <html> / <script> / <li> �Ȃǂ��܂ށB
// highlight.js ��Krugle HTML wrapper���o�̌딻���DOM�Ƃ��ĉ��߂���Ȃ��悤�A
// �Y���g���q�͈��S�ȃv���[���e�L�X�g�`��֊񂹂�B
const RAW_MARKUP_SOURCE_EXTENSIONS = new Set([
  "jsp", "jspx", "html", "htm", "xhtml", "tag", "tagx",
  // 2026-08-13 fix71: HTML�ȊO�ł��Apre/code�֗������ނ�DOM���߃��X�N������
  // XML/SVG�n�}�[�N�A�b�v��highlight.js�ɓn�����A�K��textContent�̃v���[���\���Ɋ񂹂�B
  "xml", "xsd", "xsl", "xslt", "svg"
]);

function isRawMarkupSourcePath(path) {
  return RAW_MARKUP_SOURCE_EXTENSIONS.has(getPathExtensionForLanguage(path));
}

function containsExecutableMarkupRiskForPreCode(sourceText) {
  const source = String(sourceText || "");
  if (!source) return false;

  // 2026-08-13 fix71:
  // codeBlock �ւ͕K�� textContent �œ���Ă��邪�Ahighlight.js��㑱���H�֓n���O�ɁA
  // HTML/JSP�ȊO�̃\�[�X���Ɋ܂܂����s�n�}�[�N�A�b�v�����S���Ō��m����B
  // ��: JavaScript/SQL/XML/Java��������� <script> / onerror= / javascript: / SVG �ȂǁB
  return /<\s*\/?\s*(?:script|iframe|object|embed|svg|math|link|meta|style|img|body|html|head|form|input|button|textarea|select|option)\b/i.test(source)
    || /\son[a-z][a-z0-9_-]*\s*=/i.test(source)
    || /(?:href|src|xlink:href|formaction|action)\s*=\s*["']?\s*javascript\s*:/i.test(source)
    || /<%[@!=]?|<jsp:/i.test(source);
}

function isSafeMarkupHighlightSource(displayLanguage, path) {
  const language = normalizeHighlightLanguage(displayLanguage || "");
  if (isRawMarkupSourcePath(path)) return true;
  return language === "jsp" || language === "html" || language === "xhtml" || language === "xml" || language === "svg";
}

function shouldRenderSourceAsSafePlainText(displayLanguage, path, sourceText) {
  // fix89: JSP/HTML/XML�ȂǁA�t�@�C����ʂ����m�ȃ}�[�N�A�b�v�͕ʂ̈��S�n�C���C�g�o�H�ŏ�������B
  // �s���Ȍ���̖{���Ɏ��s�n�}�[�N�A�b�v�����������ꍇ�����A�]���ǂ���v���[���\���֑ޔ�����B
  if (isSafeMarkupHighlightSource(displayLanguage, path)) return false;

  const source = String(sourceText || "");
  if (containsExecutableMarkupRiskForPreCode(source)) return true;

  // �p�X/���ꂪ�s���Ȃ܂�JSP/HTML�炵���{�����������ꍇ�͈��S���Ńv���[���`�悷��B
  return /^\s*(?:<%@|<jsp:|<!DOCTYPE\s+html\b|<html\b)/i.test(source);
}

function renderSourceAsSafePlainText(codeBlock, sourceText) {
  if (!codeBlock) return;
  codeBlock.removeAttribute("data-safe-markup-highlight");
  codeBlock.className = "language-plaintext hljs codeBlockPlainSource";
  codeBlock.setAttribute("data-safe-plain-source", "true");
  codeBlock.textContent = sourceText || "";
  enforceSafeCodeBlockDom(codeBlock);
}

function enforceSafeCodeBlockDom(codeBlock) {
  if (!codeBlock || typeof codeBlock.querySelectorAll !== "function") return;

  // codeBlock�z���́Ahighlight.js��span�Ǝ��O�n�C���C�gbutton�ȊO�������Ȃ��B
  // ����A�O�����C�u������㑱���H���\�����Ȃ��^�O/�����𐶐����Ă��A������֖߂��B
  const allowedTags = new Set(["SPAN", "BUTTON"]);
  Array.from(codeBlock.querySelectorAll("*")).forEach(element => {
    if (!allowedTags.has(element.tagName)) {
      element.replaceWith(document.createTextNode(element.textContent || ""));
    }
  });

  Array.from(codeBlock.querySelectorAll("*")).forEach(element => {
    Array.from(element.attributes || []).forEach(attribute => {
      const name = String(attribute.name || "").toLowerCase();
      if (name.startsWith("on") || /^(href|src|srcdoc|xlink:href|formaction|action)$/i.test(name)) {
        element.removeAttribute(attribute.name);
        return;
      }
      if (name === "style" && !(element.classList && element.classList.contains("codeKeywordLink"))) {
        element.removeAttribute(attribute.name);
      }
    });
  });
}


function inferLanguageFromPath(path, fallback = "plaintext") {
  const value = cleanPathForLanguage(path);
  if (value.endsWith(".java")) return "java";
  if (value.endsWith(".sql")) return "sql";
  if (value.endsWith(".xml")) return "xml";
  if (value.endsWith(".jsp")) return "xml";
  if (value.endsWith(".html") || value.endsWith(".htm")) return "xml";
  if (value.endsWith(".js")) return "javascript";
  if (value.endsWith(".css")) return "css";
  if (value.endsWith(".sh") || value.endsWith(".csh") || value.endsWith(".ksh") || value.endsWith(".bash")) return "bash";
  if (isShellLikeTextPath(value)) return "bash";
  return fallback;
}

function resolveHighlightDisplayLanguage(language, path) {
  if (isShellLikeTextPath(path)) return "bash";

  let value = normalizeHighlightLanguage(language || inferLanguageFromPath(path, "plaintext"));
  if (!value) value = inferLanguageFromPath(path, "plaintext");
  if (value === "shell") value = "bash";

  // highlight.js �ɖ��o�^�̊g���q��n���ƁAhljs �N���X���t�������w�i�̂܂܎c�邱�Ƃ�����B
  // ���o�^����� bash�Abash ���Ȃ���� plaintext �ɗ��Ƃ��B
  if (window.hljs && typeof window.hljs.getLanguage === "function" && !window.hljs.getLanguage(value)) {
    return window.hljs.getLanguage("bash") ? "bash" : "plaintext";
  }
  return value || "plaintext";
}

const GROUP_SELECT_SECTIONS = [
  {
    key: "NIKKO",
    label: "NIKKO",
    match: value => /^(newnikko|nikko|nk)/i.test(value)
  },
  {
    key: "BPS",
    label: "BPS",
    match: value => /^(bpnet|bps)/i.test(value)
  },
  {
    key: "SY",
    label: "�� SY�͂��܂�",
    match: value => /^sy/i.test(value)
  },
  {
    key: "RPS",
    label: "RPS",
    match: value => /^rps/i.test(value)
  },
  {
    key: "OTHER",
    label: "���̑�",
    match: () => true
  }
];

function normalizeGroupProjectOption(project) {
  const source = project || {};
  const value = typeof project === "string" ? project : (source.value || source.text || "");
  const text = typeof project === "string" ? project : (source.text || source.value || "");
  const normalized = {
    value: String(value == null ? "" : value).trim(),
    text: String(text == null ? "" : text).trim(),
    selected: Boolean(source && source.selected)
  };
  if (!normalized.value && !normalized.text) return null;
  if (!normalized.text) normalized.text = normalized.value;
  if (!normalized.value) normalized.value = normalized.text;
  return normalized;
}

function isAllProjectOption(option) {
  const value = String(option && option.value || "").trim().toLowerCase();
  const text = String(option && option.text || "").trim().toLowerCase();
  return value === "all" || text === "all" || text === "���ׂ�";
}

function groupProjectClassifierValue(option) {
  return `${option.value || ""} ${option.text || ""}`.replace(/\s+/g, "").trim();
}

function groupProjectDisplayText(option) {
  const rawText = String((option && (option.text || option.value)) || "").trim();
  if (!rawText) return "";

  // Select �� value �� API ���痈���l�����̂܂ܕێ�����B
  // ��ʂɏo�����������ANIKKO. / BPS. / RPS. / SY. �Ȃǂ̃J�e�S���ړ������O���B
  const stripped = rawText.replace(/^(?:NewNikko|NIKKO|BPS|RPS|SY)[._-](?=.)/i, "");
  return stripped || rawText;
}

function findGroupProjectSection(option) {
  const value = groupProjectClassifierValue(option);
  return GROUP_SELECT_SECTIONS.find(section => section.match(value)) || GROUP_SELECT_SECTIONS[GROUP_SELECT_SECTIONS.length - 1];
}

const RECENT_GROUP_SELECT_SECTION_LABEL = "�ŋ߉{�������ڍs�O���[�v";

function normalizeGroupSelectCompareValue(value) {
  return String(value == null ? "" : value).trim().toLowerCase();
}

function getHistoryMigrationGroupPriority() {
  const result = [];
  const seen = new Set();
  const values = readFileHistoryValues();

  values.forEach(value => {
    const entry = splitHistoryStorageValue(value);
    const rawPath = String(entry.path || "").trim().replace(/\\/g, "/");
    if (!rawPath || isPlaceholderHistoryValue(rawPath)) return;

    const firstSegment = rawPath.replace(/^\/+/, "").split("/")[0] || "";
    const project = normalizeProjectValue(
      entry.project || (isKnownMigrationGroupSegment(firstSegment) ? firstSegment : "")
    );
    const group = normalizeMigrationGroupName(
      entry.group || extractMigrationGroupFromPath(rawPath) || project
    );

    const exactProjectKey = normalizeGroupSelectCompareValue(project);
    const groupKey = normalizeGroupSelectCompareValue(group);
    const uniqueKey = exactProjectKey || groupKey;
    if (!uniqueKey || seen.has(uniqueKey)) return;

    seen.add(uniqueKey);
    result.push({ exactProjectKey, groupKey });
  });

  return result;
}

function getGroupSelectOptionMatchScore(option, historyItem) {
  if (!option || !historyItem) return 0;

  const valueKey = normalizeGroupSelectCompareValue(option.value);
  const projectKey = normalizeGroupSelectCompareValue(normalizeProjectValue(option.value));
  if (historyItem.exactProjectKey &&
      (valueKey === historyItem.exactProjectKey || projectKey === historyItem.exactProjectKey)) {
    return 2;
  }

  if (!historyItem.groupKey) return 0;
  const candidateGroupKeys = [
    normalizeMigrationGroupName(option.value),
    normalizeMigrationGroupName(option.text),
    groupProjectDisplayText(option)
  ].map(normalizeGroupSelectCompareValue).filter(Boolean);

  return candidateGroupKeys.includes(historyItem.groupKey) ? 1 : 0;
}

function isRecentGroupSelectCopiedOption(option) {
  if (!option || !option.parentElement) return false;
  const parent = option.parentElement;
  if (String(parent.tagName || "").toUpperCase() !== "OPTGROUP") return false;
  const label = String(parent.label || parent.getAttribute("label") || "").trim();
  return label === RECENT_GROUP_SELECT_SECTION_LABEL;
}

function collectGroupSelectOptions(select, options = {}) {
  const records = [];
  const seen = new Set();
  const skipRecentCopiedOptions = options.skipRecentCopiedOptions !== false;

  Array.from(select && select.options ? select.options : []).forEach(option => {
    if (!option || option.disabled || isAllProjectOption(option)) return;
    // ��i�փR�s�[�����u�ŋ߉{�������ڍs�O���[�v�v�́A����p�̕ʘg�Ƃ��Ĉ����B
    // ���� optgroup ���̌�⏇�܂ŗ������Ɉ��������Ȃ��悤�A
    // original �ꗗ��g�ݒ����ޗ�����͏��O����B
    if (skipRecentCopiedOptions && isRecentGroupSelectCopiedOption(option)) return;
    const key = normalizeGroupSelectCompareValue(option.value || option.textContent);
    if (!key || seen.has(key)) return;
    seen.add(key);
    records.push({
      value: option.value,
      text: String(option.textContent || option.value || "").trim(),
      className: option.className || "",
      title: option.title || ""
    });
  });

  return records;
}

function appendGroupSelectOption(parent, record) {
  const option = document.createElement("option");
  option.value = record.value;
  option.textContent = record.text;
  if (record.className) option.className = record.className;
  if (record.title) option.title = record.title;
  parent.appendChild(option);
}

function prioritizeGroupSelectOptionsByHistory() {
  const select = $("groupSelect");
  if (!select) return;

  const selectedValue = select.value || "ALL";
  const records = collectGroupSelectOptions(select);
  if (!records.length) return;

  // �ŋ߉{�������ڍs�O���[�v�͏�i�ցu�ړ��v�����A��i�փR�s�[����B
  // ���������������񂠂��Ă��A��i�̃R�s�[��1�������ɂ���B
  const copiedIndexes = new Set();
  const recentRecords = [];
  getHistoryMigrationGroupPriority().forEach(historyItem => {
    let matchedIndex = -1;
    let matchedScore = 0;

    records.forEach((record, index) => {
      if (copiedIndexes.has(index)) return;
      const score = getGroupSelectOptionMatchScore(record, historyItem);
      if (score > matchedScore) {
        matchedIndex = index;
        matchedScore = score;
      }
    });

    if (matchedIndex >= 0) {
      copiedIndexes.add(matchedIndex);
      recentRecords.push(records[matchedIndex]);
    }
  });

  // ���̕��ޗ��ɂ͑S�����c���B��i�փR�s�[�����������O���Ȃ��B
  const originalBuckets = GROUP_SELECT_SECTIONS.reduce((acc, section) => {
    acc[section.key] = [];
    return acc;
  }, {});

  records.forEach(record => {
    const section = findGroupProjectSection(record);
    originalBuckets[section.key].push(record);
  });

  const fragment = document.createDocumentFragment();
  const allOption = document.createElement("option");
  allOption.value = "ALL";
  allOption.className = "groupSelectAll";
  allOption.textContent = "���ׂ�";
  fragment.appendChild(allOption);

  if (recentRecords.length) {
    const recentGroup = document.createElement("optgroup");
    recentGroup.label = RECENT_GROUP_SELECT_SECTION_LABEL;
    recentRecords.forEach(record => appendGroupSelectOption(recentGroup, record));
    fragment.appendChild(recentGroup);
  }

  GROUP_SELECT_SECTIONS.forEach(section => {
    const items = originalBuckets[section.key] || [];
    if (!items.length) return;
    const group = document.createElement("optgroup");
    group.label = section.label;
    items.forEach(record => appendGroupSelectOption(group, record));
    fragment.appendChild(group);
  });

  select.innerHTML = "";
  select.appendChild(fragment);
  setGroupSelectValue(select, selectedValue);
  refreshGroupCombo({ resetFilter: true });
}

function buildGroupedProjectOptionsHtml(projects) {
  const normalized = (Array.isArray(projects) ? projects : [])
    .map(normalizeGroupProjectOption)
    .filter(Boolean);

  const seen = new Set(["all"]);
  const buckets = GROUP_SELECT_SECTIONS.reduce((acc, section) => {
    acc[section.key] = [];
    return acc;
  }, {});

  normalized.forEach(option => {
    if (isAllProjectOption(option)) return;
    const seenKey = String(option.value || option.text || "").trim().toLowerCase();
    if (!seenKey || seen.has(seenKey)) return;
    seen.add(seenKey);
    const section = findGroupProjectSection(option);
    buckets[section.key].push(option);
  });

  const html = [`<option value="ALL" class="groupSelectAll">���ׂ�</option>`];
  GROUP_SELECT_SECTIONS.forEach(section => {
    const items = buckets[section.key] || [];
    if (!items.length) return;
    html.push(`<optgroup label="${escapeHtml(section.label)}">`);
    items.forEach(item => {
      const displayText = groupProjectDisplayText(item);
      const selected = item.selected ? " selected" : "";
      html.push(`<option value="${escapeHtml(item.value)}"${selected}>${escapeHtml(displayText)}</option>`);
    });
    html.push(`</optgroup>`);
  });
  return html.join("");
}

function setGroupSelectValue(select, currentValue) {
  if (!select) return;
  const target = currentValue || "ALL";
  const hasTarget = Array.from(select.options).some(option => !option.disabled && option.value === target);
  select.value = hasTarget ? target : "ALL";
}


function groupComboOptionMatches(option, query) {
  if (!query) return true;
  const text = String(option && option.textContent || "").toLowerCase();
  const value = String(option && option.value || "").toLowerCase();
  return text.includes(query) || value.includes(query);
}

function getGroupComboElements() {
  return {
    select: $("groupSelect"),
    combo: $("groupCombo"),
    button: $("groupComboButton"),
    search: $("groupComboSearch"),
    list: $("groupComboList")
  };
}

function ensureGroupComboDom() {
  const select = $("groupSelect");
  if (!select) return null;

  const field = select.closest ? select.closest(".field") : null;
  if (field) field.classList.add("fieldGroup");

  let combo = $("groupCombo");
  if (!combo) {
    combo = document.createElement("div");
    combo.id = "groupCombo";
    combo.className = "groupCombo";
    combo.innerHTML = `
      <div id="groupComboButton" class="groupComboButton" role="combobox" aria-haspopup="listbox" aria-expanded="false" aria-controls="groupComboMenu">
        <input id="groupComboSearch" class="groupComboSearch" type="text" autocomplete="off" spellcheck="false" aria-label="�ڍs�O���[�v����" value="���ׂ�">
        <span class="groupComboArrow" aria-hidden="true"></span>
      </div>
      <div id="groupComboMenu" class="groupComboMenu" role="listbox" aria-label="�ڍs�O���[�v�I��">
        <div id="groupComboList" class="groupComboList"></div>
      </div>
    `;
    select.insertAdjacentElement("afterend", combo);
  }

  select.classList.add("nativeGroupSelect");
  if (field) field.classList.add("isComboReady");

  const elements = getGroupComboElements();
  if (!combo.dataset.bound) {
    combo.dataset.bound = "1";
    combo.dataset.searching = "0";

    const openFromDisplay = () => {
      openGroupCombo();
    };

    elements.button.addEventListener("click", event => {
      event.preventDefault();
      openFromDisplay();
    });

    elements.search.addEventListener("focus", () => {
      openFromDisplay();
      // ���ݑI�𒆂̕\�������͏����\���Ƃ��Ďc���B
      // ���̂܂ܓ��͂���ƒu����������悤�ɑS�I������B
      setTimeout(() => elements.search.select(), 0);
    });

    elements.search.addEventListener("input", () => {
      combo.dataset.searching = "1";
      openGroupCombo({ skipSelect: true });
      refreshGroupCombo({ keepOpen: true });
    });

    elements.search.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        event.preventDefault();
        closeGroupCombo();
        elements.search.focus({ preventScroll: true });
        return;
      }
      if (event.key === "Enter") {
        const firstItem = elements.list.querySelector(".groupComboItem");
        if (firstItem) {
          event.preventDefault();
          selectGroupComboValue(firstItem.dataset.value);
        }
        return;
      }
      if (event.key === "ArrowDown") {
        const firstItem = elements.list.querySelector(".groupComboItem");
        if (firstItem) {
          event.preventDefault();
          firstItem.focus({ preventScroll: true });
        }
      }
    });

    elements.list.addEventListener("click", event => {
      const item = event.target.closest ? event.target.closest(".groupComboItem") : null;
      if (!item) return;
      event.preventDefault();
      selectGroupComboValue(item.dataset.value);
    });

    elements.list.addEventListener("keydown", event => {
      const current = event.target.closest ? event.target.closest(".groupComboItem") : null;
      if (!current) return;
      const items = Array.from(elements.list.querySelectorAll(".groupComboItem"));
      const index = items.indexOf(current);
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectGroupComboValue(current.dataset.value);
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        closeGroupCombo();
        elements.search.focus({ preventScroll: true });
        return;
      }
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const nextIndex = event.key === "ArrowDown" ? Math.min(items.length - 1, index + 1) : Math.max(0, index - 1);
        if (items[nextIndex]) items[nextIndex].focus({ preventScroll: true });
      }
    });

    elements.list.addEventListener("wheel", event => {
      // �h���b�v�_�E�����ł́A�y�[�W���ł͂Ȃ����X�g����D�悵�ďc�X�N���[��������B
      const list = elements.list;
      const maxScrollTop = list.scrollHeight - list.clientHeight;
      const goingUp = event.deltaY < 0;
      const goingDown = event.deltaY > 0;
      const canScrollUp = list.scrollTop > 0;
      const canScrollDown = list.scrollTop < maxScrollTop - 1;
      if ((goingUp && canScrollUp) || (goingDown && canScrollDown)) {
        event.stopPropagation();
      }
    }, { passive: true });

    document.addEventListener("click", event => {
      if (!combo.contains(event.target)) closeGroupCombo();
    });
  }

  refreshGroupCombo({ resetFilter: true, keepOpen: combo.classList.contains("isOpen") });
  return elements;
}

function openGroupCombo(options = {}) {
  const elements = getGroupComboElements();
  if (!elements.combo || !elements.button || !elements.search) return;
  elements.combo.classList.add("isOpen");
  elements.button.setAttribute("aria-expanded", "true");
  refreshGroupCombo({ keepOpen: true });
  if (!options.skipSelect) {
    setTimeout(() => {
      elements.search.focus({ preventScroll: true });
      if (elements.combo.dataset.searching !== "1") elements.search.select();
    }, 0);
  }
}

function closeGroupCombo() {
  const elements = getGroupComboElements();
  if (!elements.combo || !elements.button || !elements.search) return;
  elements.combo.classList.remove("isOpen");
  elements.button.setAttribute("aria-expanded", "false");
  elements.combo.dataset.searching = "0";
  elements.search.value = getSelectedGroupComboLabel(elements.select);
}

function selectGroupComboValue(value) {
  const elements = getGroupComboElements();
  if (!elements.select) return;
  const target = String(value || "ALL");
  const option = Array.from(elements.select.options).find(item => !item.disabled && item.value === target);
  elements.select.value = option ? option.value : "ALL";
  elements.select.dispatchEvent(new Event("change", { bubbles: true }));
  if (elements.combo) elements.combo.dataset.searching = "0";
  if (elements.search) elements.search.value = getSelectedGroupComboLabel(elements.select);
  refreshGroupCombo({ resetFilter: true });
  closeGroupCombo();
  if (elements.search) elements.search.focus({ preventScroll: true });
}

function getSelectedGroupComboLabel(select) {
  if (!select) return "���ׂ�";
  const selected = select.options[select.selectedIndex];
  if (!selected || selected.disabled) return "���ׂ�";
  return String(selected.textContent || selected.value || "���ׂ�").trim() || "���ׂ�";
}

function appendGroupComboItem(fragment, option, className = "") {
  const item = document.createElement("button");
  item.type = "button";
  item.className = `groupComboItem ${className}`.trim();
  item.setAttribute("role", "option");
  item.dataset.value = option.value || "ALL";
  item.textContent = String(option.textContent || option.value || "").trim();
  item.title = option.value || item.textContent;
  item.tabIndex = -1;
  fragment.appendChild(item);
  return item;
}

function refreshGroupCombo(options = {}) {
  const elements = getGroupComboElements();
  const { select, combo, search, list } = elements;
  if (!select || !combo || !search || !list) return;

  if (options.resetFilter) {
    combo.dataset.searching = "0";
    search.value = getSelectedGroupComboLabel(select);
  }

  const query = combo.dataset.searching === "1" ? String(search.value || "").trim().toLowerCase() : "";

  const fragment = document.createDocumentFragment();
  const allOptions = [];
  const sections = [];
  let currentSection = null;

  Array.from(select.options).forEach(option => {
    if (option.disabled && option.classList.contains("groupSelectHeader")) {
      currentSection = { label: String(option.textContent || "").trim(), items: [] };
      sections.push(currentSection);
      return;
    }

    if (option.value === "ALL" || option.classList.contains("groupSelectAll")) {
      allOptions.push(option);
      return;
    }

    if (!currentSection) {
      currentSection = { label: "���̑�", items: [] };
      sections.push(currentSection);
    }
    currentSection.items.push(option);
  });

  allOptions.forEach(option => {
    if (!query || groupComboOptionMatches(option, query)) {
      const item = appendGroupComboItem(fragment, option, "groupComboAll");
      item.setAttribute("aria-selected", select.value === option.value ? "true" : "false");
      item.classList.toggle("isSelected", select.value === option.value);
    }
  });

  let visibleDataCount = 0;
  sections.forEach(section => {
    const matchedItems = section.items.filter(option => groupComboOptionMatches(option, query));
    if (!matchedItems.length) return;

    const header = document.createElement("div");
    header.className = "groupComboHeader";
    header.textContent = section.label;
    fragment.appendChild(header);

    matchedItems.forEach(option => {
      const item = appendGroupComboItem(fragment, option, "groupComboData");
      const selected = select.value === option.value;
      item.setAttribute("aria-selected", selected ? "true" : "false");
      item.classList.toggle("isSelected", selected);
      visibleDataCount += 1;
    });
  });

  if (!fragment.childNodes.length || (query && visibleDataCount === 0 && !allOptions.some(option => groupComboOptionMatches(option, query)))) {
    const empty = document.createElement("div");
    empty.className = "groupComboEmpty";
    empty.textContent = "�Y���Ȃ�";
    fragment.appendChild(empty);
  }

  const previousScrollTop = list.scrollTop;
  list.innerHTML = "";
  list.appendChild(fragment);
  if (options.keepOpen) list.scrollTop = Math.min(previousScrollTop, Math.max(0, list.scrollHeight - list.clientHeight));
}

async function loadInitialData() {
  if (USE_SAMPLE_DATA) {
    prioritizeGroupSelectOptionsByHistory();
    return;
  }

  try {
    const resolved = await resolveApiBaseOnce();
    let data = resolved.initData;
    if (!data) {
      try {
        data = await fetchJsonAtBase(resolved.base, "/init", {}, {
          method: "GET",
          timeoutMs: API_ACCESS_TIMEOUT_MS
        });
        validateInitResponse(data, resolved.base);
      } catch (e) {
        clearApiBaseSelection();
        const retried = await resolveApiBaseOnce({ forceCheck: true });
        data = retried.initData;
      }
    }

    const projects = Array.isArray(data && data.projects) ? data.projects : [];
    const select = $("groupSelect");
    if (!select) return;
    if (!projects.length) {
      prioritizeGroupSelectOptionsByHistory();
      return;
    }

    const current = select.value || "ALL";
    select.innerHTML = buildGroupedProjectOptionsHtml(projects);
    setGroupSelectValue(select, current);
    prioritizeGroupSelectOptionsByHistory();
  } catch (e) {
    // HTML�ɖ��ߍ��񂾏����I�������c���A��ʑS�̂͗��p�\�ȏ�Ԃɂ���B
    console.warn("/init �ڑ����s�BHTML�����l���g�p���܂��B", e);
    prioritizeGroupSelectOptionsByHistory();
    showCopyFeedback("Servlet���ڑ��i�����l�ŕ\���j");
  }
}

function readArray(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) && value.length > 0 ? value : fallback;
  } catch (e) {
    return fallback;
  }
}

function saveArray(key, value) {
  // 2026-08-20 fix152: �t�@�C�������^���������Ƃ��ő�500����ێ�����B
  localStorage.setItem(key, JSON.stringify((Array.isArray(value) ? value : []).slice(0, HISTORY_STORAGE_LIMIT)));
}

function isAutoFilledRecentTab(item) {
  return Boolean(item && (item.autoFilled === true || item.__autoFilled === true));
}

function createAutoFilledRecentTab(path, openedAt) {
  return {
    path: getHistoryEntryPath(path || currentCodePath || sampleFiles[0]),
    openedAt: toSafeDate(openedAt).toISOString(),
    autoFilled: true
  };
}

function ensureMinimumRecentTabs(tabs) {
  const base = (Array.isArray(tabs) ? tabs : [])
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (base.length === 0) {
    base.push(createAutoFilledRecentTab(currentCodePath || sampleFiles[0], new Date()));
  }

  // ��������35�������̏ꍇ�́A��ʉE�[�ɂ���Ō�̎�������1�����߂���35���܂ŕ⊮����B
  // �⊮�s�� localStorage �֕ۑ����Ȃ��B���ۂɉ{�����ꂽ�����ƍ�����Ȃ��悤 autoFilled ��t����B
  let cursor = toSafeDate(base[base.length - 1].openedAt);
  const fillerPath = base[base.length - 1].path || currentCodePath || sampleFiles[0];
  while (base.length < RECENT_TAB_MIN_COUNT) {
    cursor = new Date(cursor.getTime() - 60 * 1000);
    base.push(createAutoFilledRecentTab(fillerPath, cursor));
  }

  return base.slice(0, RECENT_TAB_STORE_LIMIT);
}

function readRecentTabs() {
  // �@�z�[�������A�A��i�t�@�C�����^�u�A�B�\�[�X�E�������͓������f�[�^������B
  // �t�@�C�����^�u�� fileStorage �ɓ����Ă���t�@�C�����𕪂����̂܂܎g���B
  // ��������������������ꍇ�́A���я����100���܂łɐ�������B
  const historyValues = readFileHistoryValues();
  const tabs = normalizeFileHistoryValues(historyValues)
    .map((value, index) => buildRecentTabFromHistoryValue(value, new Date(Date.now() - index * 60 * 1000)))
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  return tabs.map((item, index) => normalizeRecentTab(item, index));
}

function saveRecentTabs(value) {
  // �݊��p�B���ԃ^�u��p��localStorage�͎g�킸�Akrugle.history.files�𐳂Ƃ���B
}

function recentTabKey(item) {
  if (!item) return "";
  return `${item.openedAt || ""}::${item.path || ""}`;
}

function createRecentTabInstanceId(item, index) {
  const safeIndex = Math.max(0, Number.isFinite(Number(index)) ? Number(index) : 0);
  const path = String(item && item.path || "");
  const openedAt = String(item && item.openedAt || "");
  // Path��openedAt�������ł��A�w�b�_�[��̕\���ʒu���Ⴆ�Εʃ^�u�Ƃ��Ĉ����B
  return `recent-instance:${safeIndex}:${openedAt}:${path}`;
}

function findRecentTabInstanceIndex(tabs, tabId) {
  const id = String(tabId || "");
  if (!id) return -1;
  return (Array.isArray(tabs) ? tabs : []).findIndex((item, index) => createRecentTabInstanceId(item, index) === id);
}

function findRecentTabInstanceIdForItem(targetItem) {
  const target = normalizeRecentTab(targetItem, 0);
  if (!target || !target.path || !target.openedAt) return "";

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  const targetKey = recentTabKey(target);
  let index = tabs.findIndex(item => recentTabKey(item) === targetKey);
  if (index < 0) index = tabs.findIndex(item => item.path === target.path);
  return index >= 0 ? createRecentTabInstanceId(tabs[index], index) : "";
}

// 2026-08-21: �����w�b�_�[�^�u�^�ߋ��{����������J���ꍇ�́AfileStorage�֐V�K�ǉ�����
// ���ɑ��݂���^�u�C���X�^���X�����̂܂܃A�N�e�B�u�ɂ���B
// recentTabId ������Ε\���ʒu�܂Ŋ܂߂Ċ��S��v�A���� recentItem(openedAt+path)�A�Ō��path�ŏƍ�����B
function activateExistingRecentTab(path, options = {}) {
  const fullPath = getHistoryEntryPath(path || "");
  if (!fullPath) return null;

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);
  if (!tabs.length) return null;

  let index = -1;
  const requestedTabId = String(options.recentTabId || "");
  if (requestedTabId) {
    index = findRecentTabInstanceIndex(tabs, requestedTabId);
  }

  const requestedItem = options.recentItem && typeof options.recentItem === "object"
    ? options.recentItem
    : null;
  if (index < 0 && requestedItem && requestedItem.path && requestedItem.openedAt) {
    const targetPath = getHistoryEntryPath(requestedItem.path);
    const targetOpenedAt = toSafeDate(requestedItem.openedAt).toISOString();
    index = tabs.findIndex(item => item.path === targetPath && item.openedAt === targetOpenedAt);
  }

  if (index < 0) {
    index = tabs.findIndex(item => item.path === fullPath);
  }
  if (index < 0) return null;

  const item = tabs[index];
  setActiveRecentTabId(createRecentTabInstanceId(item, index));
  ensureActiveRecentVisible(tabs);
  renderRecentTabs();
  return item;
}

function setActiveRecentTabId(tabId) {
  activeRecentTabKey = String(tabId || "");
  if (activeRecentTabKey) volatileVisitedRecentTabIds.add(activeRecentTabKey);
}

function readVisitedRecentTabIdSet() {
  return new Set(volatileVisitedRecentTabIds);
}

function updateRecentTabVisitedStyles() {
  const visitedIds = readVisitedRecentTabIdSet();
  document.querySelectorAll(".tabTime[data-tab-id]").forEach(button => {
    const visited = visitedIds.has(button.dataset.tabId || "");
    button.classList.toggle("isVisited", visited);
    if (visited) {
      button.setAttribute("data-visited", "true");
    } else {
      button.removeAttribute("data-visited");
    }
  });
}

function ensureActiveRecentVisible(tabs) {
  if (!Array.isArray(tabs) || !tabs.length) {
    recentWindowStart = 0;
    return;
  }

  const activeIndex = findRecentTabInstanceIndex(tabs, activeRecentTabKey);
  if (activeIndex < 0) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    return;
  }

  if (activeIndex < recentWindowStart) {
    recentWindowStart = activeIndex;
  } else if (activeIndex >= recentWindowStart + RECENT_TAB_VISIBLE_LIMIT) {
    recentWindowStart = activeIndex - RECENT_TAB_VISIBLE_LIMIT + 1;
  }

  recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
}

function addRecentTab(path, meta = {}) {
  const fullPath = getHistoryEntryPath(path);
  if (!fullPath) return null;

  // localStorage�֕ۑ����������ƁA��ʁESessionStorage�Ŏg�����ID�̓��������S�Ɉ�v������B
  // �ȑO��Date�̃~���b�t��ID�ƁA�ۑ���̕b�P��ID������Ă������߁A�����^�u�����ł��Ȃ������B
  const openedAt = new Date();
  const storageValue = createHistoryStorageValue(fullPath, openedAt, meta);
  const canonicalOpenedAt = getHistoryEntryOpenedAt(storageValue, openedAt);
  const item = { path: fullPath, openedAt: canonicalOpenedAt };

  addHistory(FILE_HISTORY_STORAGE_KEY, storageValue, []);
  setActiveRecentTabId(createRecentTabInstanceId(item, 0));
  recentWindowStart = 0;
  renderRecentTabs();
  return item;
}

function toSafeDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? new Date() : date;
}

function normalizeRecentTab(item, index) {
  const fallback = sampleRecentTabs[index % sampleRecentTabs.length] || sampleRecentTabs[0];
  const path = getHistoryEntryPath(item && item.path ? item.path : (fallback ? fallback.path : sampleFiles[0]));
  const openedAtValue = item && item.openedAt ? item.openedAt : (fallback ? fallback.openedAt : new Date().toISOString());
  const openedAt = toSafeDate(openedAtValue).toISOString();
  return { path, openedAt, autoFilled: isAutoFilledRecentTab(item) };
}

function formatTabDate(isoText) {
  const date = toSafeDate(isoText);
  const week = ["��", "��", "��", "��", "��", "��", "�y"][date.getDay()];
  const pad = value => String(value).padStart(2, "0");
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())}(${week})`;
}

// �w�b�_�[�����^�u�ɂ͎����ł͂Ȃ��t�@�C������\������B
// Unicode������1�����Ƃ��Đ����A�擪12�����𒴂���ꍇ���������Ɂu�c�v��t����B
function getRecentTabFileName(path) {
  const cleanPath = String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/")
    .replace(/\/+$/, "");
  const fileName = cleanPath.substring(cleanPath.lastIndexOf("/") + 1);
  return fileName || cleanPath || "-";
}


// 2026-08-14 fix86:
// �\�[�X�R�[�h�^�u��̃t�@�C�����o�b�W�͔p�~���A��ʉ�������fixed�\���֓�������B
// �\�[�X�\���ł�basename�A�e�[�u�����\���ł̓e�[�u������\������B
function updateCodeContextFixedLabel(path = currentCodePath) {
  const sourceTab = $("codeSourceModeTab");
  if (sourceTab) {
    sourceTab.removeAttribute("data-badge");
    sourceTab.removeAttribute("data-file-name-badge");
    sourceTab.removeAttribute("title");
    sourceTab.removeAttribute("aria-label");
  }

  const label = $("codeContextFixedLabel");
  if (!label) return "";

  let visibleName = "";
  if (currentView === "code" && isTableInfoPanel(activeCodePanel)) {
    const state = getActiveTableInfoState();
    const selected = state && state.selected ? state.selected : {};
    visibleName = String((selected && selected.name) || (state && state.tableName) || "").trim();
  } else if (currentView === "code" && activeCodePanel === "source") {
    const normalizedPath = getHistoryEntryPath(path || currentCodePath);
    const meta = currentCodeMeta && typeof currentCodeMeta === "object" ? currentCodeMeta : {};
    const metaPath = getHistoryEntryPath(meta.path || meta.fullPath || "");
    const canUseMeta = Boolean(metaPath && normalizedPath && metaPath === normalizedPath);

    const fileName = String((canUseMeta && meta.fileName) || getRecentTabFileName(normalizedPath) || "-").trim() || "-";
    const group = normalizeMigrationGroupName(
      (canUseMeta && (meta.group || meta.migrationGroup)) || extractMigrationGroupFromPath(normalizedPath) || "-"
    ) || "-";
    const directoryGroup = cleanDirectoryGroupName(
      (canUseMeta && (meta.directoryGroup || meta.dirGroup)) || getRawDirectoryGroupFromPath(normalizedPath) || "-"
    ) || "-";
    const language = String(
      (canUseMeta && meta.language) || inferLanguageFromPath(normalizedPath, currentSourceLanguage || "") || getFileExtensionLabel(normalizedPath) || "-"
    ).replace(/^\./, "").trim() || "-";

    visibleName = [fileName, group, directoryGroup, language].join("�@�b�@");
  }

  label.textContent = visibleName;
  label.hidden = !visibleName;
  label.classList.toggle("isVisible", Boolean(visibleName));
  return visibleName;
}

function formatRecentTabFileName(path, maxLength = 12) {
  const fileName = getRecentTabFileName(path);
  const characters = Array.from(fileName);
  return characters.length > maxLength
    ? `${characters.slice(0, maxLength).join("")}�c`
    : fileName;
}


// 2026-08-03 �T�C�g�C��1: �w�b�_�[�����^�uhover���̍��ѕ\�������𐮌`����B
// �\���`��: �t�@�C���� = xxx.java �b nkCCIS �b kyak.online.jar �b .java
function getRawDirectoryGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "-";

  if (isKnownMigrationGroupSegment(parts[0])) {
    return parts[1] || "-";
  }

  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return parts[1] || parts[0] || "-";
  }

  return parts[0] || "-";
}

function getFileExtensionLabel(path) {
  const fileName = getRecentTabFileName(path);
  const match = String(fileName || "").match(/\.([^./\\]+)$/);
  return match ? match[1] : "-";
}

function buildFullWidthHoverBandText(items) {
  return (Array.isArray(items) ? items : [])
    .map(item => {
      const label = String(item && item.label || "").trim();
      const value = String(item && item.value || "-").trim() || "-";
      return label ? `${label}�@���@${value}` : value;
    })
    .filter(Boolean)
    .join("�@�b�@");
}

function formatRecentTabFullPathBandText(path) {
  const fileName = getRecentTabFileName(path) || "-";
  const group = extractMigrationGroupFromPath(path) || "-";
  const directoryGroup = getRawDirectoryGroupFromPath(path) || "-";
  const extension = getFileExtensionLabel(path);
  return buildFullWidthHoverBandText([
    { label: "�t�@�C����", value: fileName },
    { value: group },
    { value: directoryGroup },
    { value: extension }
  ]);
}

function formatRecentTabItemBandText(item) {
  const source = item && typeof item === "object" ? item : {};
  const path = String(source.path || "").trim();
  const fileName = String(source.fileName || getRecentTabFileName(path) || "-").trim() || "-";
  const group = normalizeMigrationGroupName(
    source.group || source.migrationGroup || extractMigrationGroupFromPath(path) || "-"
  ) || "-";
  const directoryGroup = cleanDirectoryGroupName(
    source.directoryGroup || source.dirGroup || getRawDirectoryGroupFromPath(path) || "-"
  ) || "-";
  const language = String(
    source.language || inferLanguageFromPath(path, "") || getFileExtensionLabel(path) || "-"
  ).replace(/^\./, "").trim() || "-";

  return buildFullWidthHoverBandText([
    { label: "�t�@�C����", value: fileName },
    { label: "�ڍs�O���[�v", value: group },
    { label: "�f�B���N�g���O���[�v", value: directoryGroup },
    { label: "����", value: language }
  ]);
}

function ensureRecentTabFullPathViewportBand() {
  let band = $("recentTabFullPathViewportBand");
  if (!band && document.body) {
    band = document.createElement("div");
    band.id = "recentTabFullPathViewportBand";
    band.className = "recentTabFullPathViewportBand";
    band.setAttribute("aria-hidden", "true");
    document.body.appendChild(band);
  }
  return band;
}

// 2026-08-04 �T�C�g�C��1: �S���O���[�т̕\��������span�P�ʂɕ������Ĕz�u����B
// �u�t�@�C���� = ... �b nkCCIS �b kyak.online.jar �b java�v�̊e���ڂ��span�ɂ���B
function splitFullWidthBandTextItems(text) {
  const value = String(text || "").trim();
  if (!value) return [];
  return value
    .split(/[�@\s]*[�b|][�@\s]*/)
    .map(part => part.trim())
    .filter(Boolean);
}

function renderFullWidthBandContent(band, text) {
  if (!band) return false;
  const items = splitFullWidthBandTextItems(text);
  band.textContent = "";
  if (!items.length) return false;

  const inner = document.createElement("span");
  inner.className = "recentTabFullPathBandInner";
  items.forEach((item, index) => {
    const part = document.createElement("span");
    part.className = "recentTabFullPathBandPart";
    part.textContent = item;
    inner.appendChild(part);

    if (index < items.length - 1) {
      const separator = document.createElement("span");
      separator.className = "recentTabFullPathBandSeparator";
      separator.setAttribute("aria-hidden", "true");
      separator.textContent = "�b";
      inner.appendChild(separator);
    }
  });
  band.appendChild(inner);
  return true;
}

// 2026-08-03 �T�C�g�C��7: �e�[�u���shover�ł��A�w�b�_�[�����^�u�Ɠ����S���O���[�т�\������B
// hover����ENTER���������ꍇ�́A���̍s�N���b�N�Ɠ������������s����B
let activeFullWidthHoverBandAction = null;

// 2026-08-04 �T�C�g�C��3: hover�т���ENTER/�N���b�N�őJ�ڂ�������ɁA
// �J�ڐ�ŋ��R�J�[�\�����ɂ���ʗv�f��hover�т������\������邱�Ƃ�}�~����B
let fullWidthHoverBandSuppressUntil = 0;

function isFullWidthHoverBandSuppressed() {
  return Date.now() < fullWidthHoverBandSuppressUntil;
}

function suppressFullWidthHoverBandTemporarily(durationMs = 1200) {
  fullWidthHoverBandSuppressUntil = Date.now() + Math.max(0, Number(durationMs) || 0);
  hideRecentTabFullPathViewportBand();
}

function clearFullWidthHoverBandSuppression() {
  fullWidthHoverBandSuppressUntil = 0;
}

function showRecentTabFullPathViewportBand(text, action) {
  // 2026-08-04 �T�C�g�C��2: �w�b�_�[�����^�uhover����ENTER�őΏۃ\�[�X���J����悤�ɂ���B
  if (isFullWidthHoverBandSuppressed()) {
    hideRecentTabFullPathViewportBand();
    return;
  }
  activeFullWidthHoverBandAction = null;
  const band = ensureRecentTabFullPathViewportBand();
  if (!band) return;
  const hasContent = renderFullWidthBandContent(band, text);
  band.classList.toggle("isVisible", hasContent);
  document.body.classList.toggle("isRecentTabFullPathBandVisible", hasContent);
  activeFullWidthHoverBandAction = typeof action === "function" && hasContent ? action : null;
}

function hideRecentTabFullPathViewportBand() {
  activeFullWidthHoverBandAction = null;
  const band = $("recentTabFullPathViewportBand");
  if (band) {
    band.classList.remove("isVisible");
  }
  if (document.body) {
    document.body.classList.remove("isRecentTabFullPathBandVisible");
  }
}

function showInteractiveFullWidthHoverBand(text, action) {
  if (isFullWidthHoverBandSuppressed()) {
    hideRecentTabFullPathViewportBand();
    return;
  }
  const band = ensureRecentTabFullPathViewportBand();
  if (!band) return;
  const hasContent = renderFullWidthBandContent(band, text);
  band.classList.toggle("isVisible", hasContent);
  if (document.body) {
    document.body.classList.toggle("isRecentTabFullPathBandVisible", hasContent);
  }
  activeFullWidthHoverBandAction = typeof action === "function" && hasContent ? action : null;
}

function hideInteractiveFullWidthHoverBand(action) {
  if (action && activeFullWidthHoverBandAction && activeFullWidthHoverBandAction !== action) return;
  activeFullWidthHoverBandAction = null;
  const band = $("recentTabFullPathViewportBand");
  if (band) band.classList.remove("isVisible");
  if (document.body) document.body.classList.remove("isRecentTabFullPathBandVisible");
}

function isKeyboardTypingTarget(target) {
  const element = target && target.nodeType === 1 ? target : null;
  const tagName = target && target.tagName ? target.tagName.toLowerCase() : "";
  if (["input", "select", "textarea"].includes(tagName)) return true;
  return Boolean(target && target.isContentEditable);
}

function isTabPreviewControllerElement(target) {
  const element = target && target.nodeType === 1 ? target : null;
  if (!element || typeof element.closest !== "function") return false;
  return Boolean(element.closest(".codeSideNavBtn, .recentNavArrow"));
}

function isRenderedRecentTabButtonElement(target) {
  const element = target && target.nodeType === 1 ? target : null;
  if (!element || typeof element.closest !== "function") return false;
  return Boolean(element.closest(".tabTime[data-tab-id], .tabTime[data-path]"));
}

function activateFullWidthHoverBandActionByEnter(event) {
  if (!activeFullWidthHoverBandAction || !event || event.key !== "Enter") return false;
  if (isKeyboardTypingTarget(event.target)) return false;
  // 2026-08-12 fix60:
  // �}�E�X�J�[�\�����E/���^�u�ړ��{�^���A�܂��̓w�b�_�[���E����ɂ����Ԃ�Enter�́A
  // ����focus�������^�u�Ɏc���Ă��Ă��Ahover�т̊m��(openCode)�ł͂Ȃ�
  // �e�{�^���́u��/�O�̐����^�u��hover�����悤�Ɍ�����v�v���r���[�����֕K���n���B
  if (activeCodeSideNavigationHoverOffset || activeRecentNavArrowHoverOffset) return false;
  // �E/���^�u�ړ��{�^����w�b�_�[���E��󎩐g��Enter�����ꍇ�́A
  // ������hover�ъm��A�N�V���������s�����A�e�{�^����keydown������
  // �Ώې����^�u�̋^��hover�v���r���[�\���������s�킹��B
  if (isTabPreviewControllerElement(event.target)) return false;
  const action = activeFullWidthHoverBandAction;
  event.preventDefault();
  event.stopPropagation();
  clearRecentTabKeyboardPreviewStyles();
  suppressFullWidthHoverBandTemporarily();
  action();
  return true;
}

function createHistorySearchBandText(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim())
    .filter(Boolean);
  const keyword = parts[0] || "-";
  const group = parts[1] || "-";
  const language = parts[2] || "-";
  return buildFullWidthHoverBandText([
    { label: "�����L�[���[�h", value: keyword },
    { value: group },
    { value: language }
  ]);
}

function createSearchResultBandText(row) {
  const source = row || {};
  const path = source.path || source.fullPath || source.filePath || "";
  const fileName = source.fileName || getRecentTabFileName(path) || source.path || "-";
  const group = normalizeMigrationGroupName(source.group || source.project || extractMigrationGroupFromPath(path) || "-") || "-";
  const directoryGroup = source.directoryGroup || getRawDirectoryGroupFromPath(path) || "-";
  const language = String(source.language || getFileExtensionLabel(path) || "-").replace(/^\./, "") || "-";
  return buildFullWidthHoverBandText([
    { label: "�t�@�C����", value: fileName },
    { value: group },
    { value: directoryGroup },
    { value: language }
  ]);
}

function bindFullWidthHoverBandToRow(rowElement, text, action) {
  if (!rowElement || !text || typeof action !== "function") return;
  if (rowElement.classList.contains("isPlaceholderHistoryRow") || rowElement.classList.contains("isPlaceholderResultRow")) return;
  if (rowElement.classList.contains("resultEmptyStateRow") || rowElement.classList.contains("resultNoDataRow")) return;

  rowElement.tabIndex = 0;
  rowElement.dataset.hoverBandText = text;
  // 2026-08-04 �T�C�g�C��5: �shover���Ƀu���E�U�W���̍���title�c�[���`�b�v���o���Ȃ��B
  // Full���̃O���[�т͓Ǝ�UI�ŕ\�����邽�߁A�l�C�e�B�utitle��aria-label�֑ޔ�����B
  const nativeTitle = rowElement.getAttribute("title");
  if (nativeTitle) {
    if (!rowElement.getAttribute("aria-label")) rowElement.setAttribute("aria-label", nativeTitle);
    rowElement.removeAttribute("title");
  }

  const show = () => showInteractiveFullWidthHoverBand(text, action);
  const hide = () => hideInteractiveFullWidthHoverBand(action);

  rowElement.addEventListener("mouseenter", show);
  rowElement.addEventListener("mouseleave", hide);
  rowElement.addEventListener("focusin", show);
  rowElement.addEventListener("focusout", hide);
  rowElement.addEventListener("click", hide);
}

// �w�b�_�[�̃t�@�C�������^�u�́A�t�@�C�������̂��̂ł͂Ȃ����t�P�ʂ̔ԍ��ŕ\������B
// ������t���ł͌Â�����1����̔Ԃ��A999�𒴂����ꍇ��1�֖߂��B
function getRecentTabNumberLabelForIndex(index) {
  const safeIndex = Math.max(0, Number(index) || 0);
  const number = (safeIndex % 999) + 1;
  return String(number);
}

function createRecentTabNumberLabelMap(tabs) {
  const result = new Map();
  const groupedByDate = new Map();

  (Array.isArray(tabs) ? tabs : []).forEach((item, index) => {
    if (!item || !item.openedAt) return;
    const key = dateKey(item.openedAt);
    if (!groupedByDate.has(key)) groupedByDate.set(key, []);
    groupedByDate.get(key).push({ item, index });
  });

  groupedByDate.forEach(entries => {
    const count = entries.length;
    entries.forEach((entry, index) => {
      // tabs�͐V�������B���t���̈�ԌÂ��^�u��1�ɂ��邽�߁A�\�����͍~���ԍ��ɂ���B
      result.set(createRecentTabInstanceId(entry.item, entry.index), getRecentTabNumberLabelForIndex(count - 1 - index));
    });
  });

  return result;
}


function dateKey(isoText) {
  const date = toSafeDate(isoText);
  const pad = value => String(value).padStart(2, "0");
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}`;
}

function shiftRecentWindow(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  const maxStart = Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT);
  recentWindowStart = Math.max(0, Math.min(maxStart, recentWindowStart + offset));
  manualRecentWindowShift = true;
  renderRecentTabs();
}

function renderRecentTabs() {
  const area = $("recentTabArea");
  if (!area) return;

  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!activeRecentTabKey && currentView === "code" && currentCodePath && tabs.length) {
    const fallbackActiveIndex = tabs.findIndex(item => item.path === currentCodePath);
    if (fallbackActiveIndex >= 0) {
      setActiveRecentTabId(createRecentTabInstanceId(tabs[fallbackActiveIndex], fallbackActiveIndex));
    }
  }

  if (manualRecentWindowShift) {
    recentWindowStart = Math.max(0, Math.min(recentWindowStart, Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT)));
    manualRecentWindowShift = false;
  } else {
    ensureActiveRecentVisible(tabs);
  }

  area.classList.toggle("hasMoreLeft", recentWindowStart > 0);
  area.classList.toggle("hasMoreRight", recentWindowStart + RECENT_TAB_VISIBLE_LIMIT < tabs.length);

  const visibleTabs = tabs.slice(recentWindowStart, recentWindowStart + RECENT_TAB_VISIBLE_LIMIT);
  const recentTabNumberLabelMap = createRecentTabNumberLabelMap(tabs);
  const visitedRecentTabIds = readVisitedRecentTabIdSet();
  const groups = [];
  visibleTabs.forEach(item => {
    const key = dateKey(item.openedAt);
    const last = groups[groups.length - 1];
    if (!last || last.key !== key) {
      groups.push({ key, label: formatTabDate(item.openedAt), count: 1 });
    } else {
      last.count += 1;
    }
  });

  area.innerHTML = `
    <button class="recentNavArrow recentNavArrowLeft" type="button" aria-label="���̃^�u�ֈړ�" title="���̃^�u�ֈړ�">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M14.2 4.8L8.3 12l5.9 7.2" />
      </svg>
    </button>
    <div class="recentDateRow">
      ${groups.map((group, index) => {
        const prevGroup = groups[index - 1];
        const afterNarrowDateGroup = !!prevGroup && prevGroup.count <= 2;
        const className = afterNarrowDateGroup ? "recentDateGroup isAfterNarrowDateGroup" : "recentDateGroup";
        const shiftPx = 0;
        const extraWidthPx = group.count <= 2 && index < groups.length - 1 ? (group.count === 1 ? 70 : 44) : 0;
        return `
        <div class="${className}" style="--tab-count:${group.count}; --date-shift-x:${shiftPx}px; --date-extra-width:${extraWidthPx}px">
          ${escapeHtml(group.label)}
        </div>
      `;
      }).join("")}
    </div>
    <div class="recentTimeRow">
      ${visibleTabs.map((item, index) => {
        const absoluteIndex = recentWindowStart + index;
        const tabId = createRecentTabInstanceId(item, absoluteIndex);
        const isVisited = visitedRecentTabIds.has(tabId);
        const fullFileName = getRecentTabFileName(item.path);
        const numberLabel = recentTabNumberLabelMap.get(tabId) || getRecentTabNumberLabelForIndex(index);
        const fullPathBandText = formatRecentTabItemBandText(item);
        return `
          <button class="tabTime${isVisited ? " isVisited" : ""}${tabId === activeRecentTabKey ? " isActive" : ""}" type="button"
                  data-tab-id="${escapeHtml(tabId)}"
                  data-path="${escapeHtml(item.path)}"
                  data-opened-at="${escapeHtml(item.openedAt)}"
                  data-recent-index="${absoluteIndex}"
                  data-full-file-name="${escapeHtml(fullFileName)}"
                  data-hover-band-text="${escapeHtml(fullPathBandText)}"
                  data-number-label="${escapeHtml(numberLabel)}"
                  aria-label="${escapeHtml(`�t�@�C�� ${fullFileName}�A�^�u�ԍ� ${numberLabel}`)}"
                  title="${escapeHtml(fullFileName)}">
            <span class="recentTabLabel">${escapeHtml(numberLabel)}</span>
            <span class="recentTabTooltip" role="tooltip" aria-hidden="true">${escapeHtml(fullFileName)}</span>
            <span class="recentTabFullPathBand" role="tooltip" aria-hidden="true">${escapeHtml(fullPathBandText)}</span>
          </button>
        `;
      }).join("")}
    </div>
    <button class="recentNavArrow recentNavArrowRight" type="button" aria-label="�E�̃^�u�ֈړ�" title="�E�̃^�u�ֈړ�">
      <svg class="recentNavIconSvg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M9.8 4.8L15.7 12l-5.9 7.2" />
      </svg>
    </button>
  `;

  area.querySelectorAll(".tabTime").forEach(button => {
    const openRecentTabSourceFromHeader = () => {
      const index = Number(button.dataset.recentIndex);
      const item = tabs[index];
      if (item) openCode(item.path, { addRecent: false, recentItem: item, recentTabId: button.dataset.tabId || "" });
    };
    const showHeaderHoverBand = () => {
      showRecentTabFullPathViewportBand(
        button.dataset.hoverBandText || button.dataset.path || "",
        openRecentTabSourceFromHeader
      );
    };

    button.addEventListener("mouseenter", showHeaderHoverBand);
    button.addEventListener("mouseleave", hideRecentTabFullPathViewportBand);
    button.addEventListener("focus", showHeaderHoverBand);
    button.addEventListener("blur", hideRecentTabFullPathViewportBand);
    button.addEventListener("click", () => {
      clearRecentTabKeyboardPreviewStyles();
      suppressFullWidthHoverBandTemporarily();
      openRecentTabSourceFromHeader();
    });
  });

  const recentPrevButton = area.querySelector(".recentNavArrowLeft");
  const recentNextButton = area.querySelector(".recentNavArrowRight");
  bindRecentNavArrowPreviewButton(recentPrevButton, -1);
  bindRecentNavArrowPreviewButton(recentNextButton, 1);

  updateRecentTabVisitedStyles();
}

function openRelativeRecentTab(offset) {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);

  if (!tabs.length) return;

  let index = findRecentTabInstanceIndex(tabs, activeRecentTabKey);
  if (index < 0) index = tabs.findIndex(item => item.path === currentCodePath);
  if (index < 0) index = 0;

  const nextIndex = (index + offset + tabs.length) % tabs.length;
  const next = tabs[nextIndex];
  if (next && next.path) {
    openCode(next.path, {
      addRecent: false,
      recentItem: next,
      recentTabId: createRecentTabInstanceId(next, nextIndex)
    });
  }
}

function getHeaderKeyboardNavigationRecentTabs() {
  return readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);
}

function getHeaderKeyboardNavigationItems() {
  const items = [
    { type: "view", viewName: "home" },
    { type: "view", viewName: "search" }
  ];

  getHeaderKeyboardNavigationRecentTabs().forEach((item, index) => {
    items.push({
      type: "recent",
      recentItem: item,
      recentIndex: index,
      recentTabId: createRecentTabInstanceId(item, index)
    });
  });

  return items;
}

function getCurrentHeaderKeyboardNavigationIndex(items) {
  if (!Array.isArray(items) || !items.length) return 0;
  if (currentView === "search") return Math.min(1, items.length - 1);
  if (currentView !== "code") return 0;

  const activeIndex = items.findIndex(item =>
    item &&
    item.type === "recent" &&
    item.recentTabId === activeRecentTabKey
  );
  if (activeIndex >= 0) return activeIndex;

  const pathIndex = items.findIndex(item =>
    item &&
    item.type === "recent" &&
    item.recentItem &&
    item.recentItem.path === currentCodePath
  );
  return pathIndex >= 0 ? pathIndex : Math.min(2, items.length - 1);
}

function activateHeaderKeyboardNavigationItem(item) {
  if (!item) return;

  if (item.type === "view") {
    showView(item.viewName);
    return;
  }

  if (item.type === "recent" && item.recentItem && item.recentItem.path) {
    openCode(item.recentItem.path, {
      addRecent: false,
      recentItem: item.recentItem,
      recentTabId: item.recentTabId || createRecentTabInstanceId(item.recentItem, item.recentIndex)
    });
  }
}

function moveMainTabByKeyboard(offset) {
  // �E/���^�u�ړ��{�^���͏]���ǂ���A�w�b�_�[�S�̂̃^�u���ő����ړ�����B
  // Home �� Search �� Source Tab 1 �� Source Tab 2 �� ... �� Last �� Home �̏z�B
  // �t������ Home �� Search �� Source Tab 1 �� ... �� Last �̏z�ɂ���B
  const items = getHeaderKeyboardNavigationItems();
  if (!items.length) return;

  const currentIndex = getCurrentHeaderKeyboardNavigationIndex(items);
  const nextIndex = (currentIndex + offset + items.length) % items.length;
  activateHeaderKeyboardNavigationItem(items[nextIndex]);
}

function clearRecentTabKeyboardPreviewStyles() {
  activeRecentTabPreviewTabId = "";
  document.querySelectorAll(".tabTime.isKeyboardPreview").forEach(button => {
    button.classList.remove("isKeyboardPreview");
    button.removeAttribute("aria-selected");
  });
  clearRecentNavArrowPreviewStyles();
  clearCodeSideNavigationPreviewStyles();
}

function getFocusedRecentTabIndex(tabs) {
  const active = document.activeElement;
  if (!active || !active.classList || !active.classList.contains("tabTime")) return -1;
  const index = Number(active.dataset.recentIndex);
  return Number.isFinite(index) && index >= 0 && index < tabs.length ? index : -1;
}

function getCurrentRecentTabKeyboardPreviewIndex(tabs) {
  const focusedIndex = getFocusedRecentTabIndex(tabs);
  if (focusedIndex >= 0) return focusedIndex;

  // 2026-08-14 fix93:
  // recentNavArrowRight / recentNavArrowLeft ��A���N���b�N����ƁA�N���b�N���O�ɖ��{�^����
  // focus���ڂ邽�ߐ����^�u��focusout�ŃO���[�т���u��\���ɂȂ�B
  // �������́u�т��\�����v�̏ꍇ���� preview ID ���̗p���Ă������߁A�A���N���b�N����
  // ���񌻍݊J���Ă���^�u����_�ɖ߂邱�Ƃ��������B
  // �т̕\����ԂƂ͓Ɨ����Ē��O�̃J�[�\���ʒu�ipreview ID�j����_�ɂ��A
  // Right�Ȃ�1�E�ALeft�Ȃ�1���֊m���ɐi�߂�B
  const previewIndex = findRecentTabInstanceIndex(tabs, activeRecentTabPreviewTabId);
  if (previewIndex >= 0) return previewIndex;

  let index = findRecentTabInstanceIndex(tabs, activeRecentTabKey);
  if (index < 0) index = tabs.findIndex(item => item && item.path === currentCodePath);
  return index;
}

function findRenderedRecentTabButtonByTabId(tabId) {
  const area = $("recentTabArea");
  if (!area) return null;
  const buttons = Array.from(area.querySelectorAll(".tabTime"));
  return buttons.find(button => button.dataset.tabId === tabId) || null;
}

function ensureRecentTabIndexRendered(index, tabs) {
  if (index < 0 || !Array.isArray(tabs) || index >= tabs.length) return;

  const maxStart = Math.max(0, tabs.length - RECENT_TAB_VISIBLE_LIMIT);
  let nextStart = recentWindowStart;
  if (index < nextStart) {
    nextStart = index;
  } else if (index >= nextStart + RECENT_TAB_VISIBLE_LIMIT) {
    nextStart = index - RECENT_TAB_VISIBLE_LIMIT + 1;
  }

  nextStart = Math.max(0, Math.min(maxStart, nextStart));
  if (nextStart !== recentWindowStart) {
    recentWindowStart = nextStart;
    manualRecentWindowShift = true;
    renderRecentTabs();
  }
}

function buildRecentTabKeyboardPreviewAction(item, recentTabId) {
  return () => {
    if (!item || !item.path) return;
    openCode(item.path, {
      addRecent: false,
      recentItem: item,
      recentTabId
    });
  };
}

function previewRecentTabByKeyboard(offset, options = {}) {
  // 2026-08-05 �T�C�g�C��4:
  // ArrowLeft / ArrowRight �̓\�[�X�R�[�h�����^�u�𑦎��I�[�v�������A
  // �����^�uhover�Ɠ����S���O���[�т�\������BEnter�ŃN���b�N������openCode�����s����B
  const tabs = getHeaderKeyboardNavigationRecentTabs();
  if (!tabs.length) return false;

  const direction = offset >= 0 ? 1 : -1;
  const currentIndex = getCurrentRecentTabKeyboardPreviewIndex(tabs);
  const baseIndex = currentIndex >= 0 ? currentIndex : (direction > 0 ? -1 : 0);
  const nextIndex = (baseIndex + direction + tabs.length) % tabs.length;
  const item = tabs[nextIndex];
  if (!item || !item.path) return false;

  const recentTabId = createRecentTabInstanceId(item, nextIndex);
  ensureRecentTabIndexRendered(nextIndex, tabs);

  let button = findRenderedRecentTabButtonByTabId(recentTabId);
  if (!button) {
    renderRecentTabs();
    button = findRenderedRecentTabButtonByTabId(recentTabId);
  }
  if (!button) return false;

  clearFullWidthHoverBandSuppression();
  clearRecentTabKeyboardPreviewStyles();
  activeRecentTabPreviewTabId = recentTabId;
  button.classList.add("isKeyboardPreview");
  button.setAttribute("aria-selected", "true");
  if (options.focusTab !== false && typeof button.focus === "function") {
    try {
      button.focus({ preventScroll: true });
    } catch (e) {
      button.focus();
    }
  }

  showRecentTabFullPathViewportBand(
    formatRecentTabItemBandText(item),
    buildRecentTabKeyboardPreviewAction(item, recentTabId)
  );
  return true;
}


function handleRecentTabArrowKeyNavigation(offset, event) {
  // 2026-08-12 fix65:
  // ArrowLeft / ArrowRight ��document keydown�́A����1�{�֏W�񂷂�B
  if (isKeyboardTypingTarget(event && event.target)) return false;
  const ok = previewRecentTabByKeyboard(offset);
  if (!ok) return false;
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  return true;
}

function clearRecentNavArrowPreviewStyles() {
  document.querySelectorAll(".recentNavArrow.isRecentNavArrowPreview").forEach(button => {
    button.classList.remove("isRecentNavArrowPreview");
    button.removeAttribute("aria-current");
  });
}

function activateRecentNavArrowButton(offset, event) {
  // 2026-08-14 fix78:
  // recentNavArrowRight / recentNavArrowLeft �� click / Enter �́A�l�H�I�� KeyboardEvent ����炸�A
  // ���ۂ� ArrowRight / ArrowLeft keydown �Ɠ������ʃn���h���֒��ڗ����B
  // ���ʃn���h������ previewRecentTabByKeyboard() �����s����A
  // �����^�uhover�Ɠ����S���O���[�т�\�����A�Ώې����^�u��focus���ڂ��B
  // ���̌�� Enter �͊��� activateFullWidthHoverBandActionByEnter() �� openCode() �����s����B
  return handleRecentTabArrowKeyNavigation(offset, event);
}

function bindRecentNavArrowPreviewButton(button, offset) {
  if (!button) return;

  const runPreview = event => {
    activateRecentNavArrowButton(offset, event);
  };

  button.addEventListener("click", runPreview);
  button.addEventListener("keydown", event => {
    if (event.key !== "Enter") return;
    // preventDefault �� handleRecentTabArrowKeyNavigation() ���ōs�����߁A
    // Enter�ɂ��button�W��click���ォ���d���΂��邱�Ƃ��h�~�ł���B
    runPreview(event);
  });
}

function clearCodeSideNavigationPreviewStyles() {
  activeCodeSideNavigationPreviewOffset = 0;
  document.querySelectorAll(".codeSideNavBtn.isSideNavigationPreview").forEach(button => {
    button.classList.remove("isSideNavigationPreview");
    button.removeAttribute("aria-current");
  });
}

function previewRecentTabBySideNavigationButton(offset, sourceButton, options = {}) {
  const reuseVisiblePreview = options.reuseVisiblePreview === true;
  const focusTab = options.focusTab === true;
  const hasVisiblePreview = Boolean(
    document.body &&
    document.body.classList.contains("isRecentTabFullPathBandVisible") &&
    activeFullWidthHoverBandAction
  );

  // hover �� focus �� click �̏��œ����{�^���C�x���g���A�����Ă��A���^�u���d�ɐi�߂Ȃ��B
  // ������click/Enter�ł͑Ώۃ^�u��focus���ڂ��K�v�����邽�߁AfocusTab=true�̏ꍇ�͍ăv���r���[����B
  if (!focusTab && reuseVisiblePreview && hasVisiblePreview && activeCodeSideNavigationPreviewOffset === offset) {
    if (sourceButton) {
      sourceButton.classList.add("isSideNavigationPreview");
      sourceButton.setAttribute("aria-current", "true");
    }
    return true;
  }

  const ok = previewRecentTabByKeyboard(offset, { focusTab });
  if (!ok) return false;

  activeCodeSideNavigationPreviewOffset = offset;
  if (sourceButton) {
    sourceButton.classList.add("isSideNavigationPreview");
    sourceButton.setAttribute("aria-current", "true");
  }
  return true;
}

function hideCodeSideNavigationPreview(button, offset) {
  if (button && document.activeElement === button) return;
  if (activeCodeSideNavigationPreviewOffset !== offset) return;
  hideRecentTabFullPathViewportBand();
  clearRecentTabKeyboardPreviewStyles();
}

function activateCodeSideNavigationButton(offset, event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  // 2026-08-12 fix60:
  // �E/���^�u�ړ��{�^����Click/Enter�́A��DOM��hover�C�x���g�␔���^�u�ւ�focus�ړ��ɗ��炸�A
  // �w�b�_�[�����^�u��hover�����Ƃ��Ɠ��������ځE�S���O���[�т�JS��ԂōČ�����B
  // focus�𐔎��^�u�ֈڂ��Ȃ����ƂŁA�{�^�����Enter��A�ł��Ă�1���v���r���[���i�ށB
  const sourceButton = event && event.currentTarget && event.currentTarget.classList
    ? event.currentTarget
    : document.querySelector(offset < 0 ? "#codePrevBtn" : "#codeNextBtn");
  clearFullWidthHoverBandSuppression();
  previewRecentTabBySideNavigationButton(offset, sourceButton, { reuseVisiblePreview: false, focusTab: false });
}

function bindCodeSideNavigationPreviewButton(id, offset) {
  const button = $(id);
  if (!button) return;

  const preview = (event, reuseVisiblePreview = true, focusTab = false) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    clearFullWidthHoverBandSuppression();
    return previewRecentTabBySideNavigationButton(offset, button, { reuseVisiblePreview, focusTab });
  };

  const rememberHoverOffset = () => {
    activeCodeSideNavigationHoverOffset = offset;
  };

  const clearHoverOffset = () => {
    if (activeCodeSideNavigationHoverOffset === offset) {
      activeCodeSideNavigationHoverOffset = 0;
    }
  };

  const showHoverPreview = () => {
    rememberHoverOffset();
    preview(null, true, false);
  };

  // 2026-08-12 fix46:
  // mouseenter�����Ɉˑ������Apointer/focus�ł��E/���^�u�ړ��{�^����̏�Ԃ�ێ�����B
  // ����ɂ��u�J�[�\�����{�^����ɂ����Ԃ�Enter�v��document keydown���Ŋm���Ɍ��o����B
  button.addEventListener("pointerenter", showHoverPreview);
  button.addEventListener("pointerleave", clearHoverOffset);
  button.addEventListener("mouseenter", showHoverPreview);
  button.addEventListener("mouseleave", clearHoverOffset);
  button.addEventListener("focus", showHoverPreview);
  button.addEventListener("blur", clearHoverOffset);

  button.addEventListener("click", event => {
    // click�͑Ώې����^�u��hover�����v���r���[�����ɂ���B��focus�̓{�^�����Ɏc���B
    activateCodeSideNavigationButton(offset, event);
  });

  button.addEventListener("keydown", event => {
    if (event.key !== "Enter" && event.key !== " ") return;
    // �{�^�����g��Enter/Space���A�Ώې����^�u��hover�����v���r���[�����ɂ���B
    activateCodeSideNavigationButton(offset, event);
  });
}

function bindCodeSideNavigationPreviewButtons() {
  bindCodeSideNavigationPreviewButton("codePrevBtn", -1);
  bindCodeSideNavigationPreviewButton("codeNextBtn", 1);
}

function addHistory(key, value, fallback) {
  if (!value) return;
  if (key === FILE_HISTORY_STORAGE_KEY) {
    // 2026-08-20 fix152: �����t���p�X�ł��u�J�����񐔁v���Ƃɕʗ����Ƃ��Ďc���B
    const current = readArray(key, fallback || []);
    const next = normalizeFileHistoryValues([value].concat(current));
    saveArray(key, next);
    prioritizeGroupSelectOptionsByHistory();
    return;
  }

  // ��������������L�[���[�h�^�������d���r�����Ȃ��B
  // �����{�^���A�B�������A�\�[�X�I�𕶎��񌟍��Ȃ� runSearch(true, ...) ��ʂ鑀��1��ɂ�1�s�ǉ�����B
  const next = readArray(key, fallback || []).slice();
  next.unshift(value);
  saveArray(key, next);
}

function buildPlaceholderHistory(count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return Array.from({ length: count }, () => HISTORY_PLACEHOLDER_VALUE);
}

function isPlaceholderHistoryValue(value) {
  return String(value || "").trim() === HISTORY_PLACEHOLDER_VALUE;
}

function isValidFileHistoryPath(path) {
  const text = String(path || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) return false;

  // �ߋ��ł� localStorage �ɓ������u�t�@�C���������v�u�񕪊���̒f�Ёv�Ȃǂ̃S�~�����O����B
  // �t�@�C�������́ANIKKO.nkCCIS/kyak.online.jar/... �̂悤�ȃt���p�X�����𐳂Ƃ���B
  if (text.indexOf("/") < 0) return false;
  if (/^(undefined|null|nan)$/i.test(text)) return false;
  return true;
}

function cleanDirectoryGroupName(value) {
  const text = String(value || "").trim();
  if (!text || isPlaceholderHistoryValue(text)) return text;

  // 2��ڂ̃p�X�v�f�� kyak.online.jar / xxx.war / xxx.zip �̏ꍇ�́A
  // DIRGROUP �Ƃ��Ă͊g���q�𗎂Ƃ��� kyak.online �̌`�ŕ\������B
  return text.replace(/\.(jar|war|ear|zip)$/i, "");
}


function normalizeProjectValue(value) {
  const text = String(value || "").trim().replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
  if (!text || /^(ALL|���ׂ�)$/i.test(text)) return "";
  return text;
}

function resolveProjectFromGroup(group) {
  const normalizedGroup = normalizeMigrationGroupName(group);
  if (!normalizedGroup) return "";

  const select = $("groupSelect");
  if (!select || !select.options) return "";

  const matches = Array.from(select.options)
    .map(option => normalizeProjectValue(option.value))
    .filter(value => value && normalizeMigrationGroupName(value).toLowerCase() === normalizedGroup.toLowerCase());
  return matches.length === 1 ? matches[0] : "";
}

function buildCompleteKruglePath(path, project, group) {
  let rawPath = String(path || "").trim().replace(/\\/g, "/");
  rawPath = rawPath.replace(/^\/+/, "").replace(/\/{2,}/g, "/");
  if (!rawPath || isPlaceholderHistoryValue(rawPath)) return rawPath;

  const normalizedProject = normalizeProjectValue(project) || resolveProjectFromGroup(group);
  const firstSegment = rawPath.split("/")[0] || "";

  // ���ł� NIKKO.nkCCIS/... �̂悤�Ȋ��S�p�X�Ȃ�A���̂܂ܕێ�����B
  if (isKnownMigrationGroupSegment(firstSegment)) return rawPath;
  if (!normalizedProject) return rawPath;
  if (rawPath === normalizedProject || rawPath.startsWith(`${normalizedProject}/`)) return rawPath;
  return `${normalizedProject}/${rawPath}`;
}

function getPathPartsForGroup(path) {
  return String(path || "")
    .split("/")
    .map(part => part.trim())
    .filter(Boolean);
}

function isKnownMigrationGroupSegment(value) {
  return /^(NIKKO|BPS|RPS)\./i.test(String(value || "").trim());
}

function isLikelyDirectoryOnlyPath(parts) {
  if (!Array.isArray(parts) || parts.length < 2) return false;
  return /^(lib|java|src|source|sql|xml|jsp|sh|config|conf|classes)$/i.test(parts[1]);
}

function extractProjectFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";
  if (isKnownMigrationGroupSegment(parts[0])) return parts[0];
  const group = extractMigrationGroupFromPath(path);
  return resolveProjectFromGroup(group) || group || "";
}

function extractMigrationGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";

  // NIKKO.nkCCIS/... / BPS.xxx/... / RPS.xxx/... ��1�K�w�ڂ��ڍs�O���[�v�B
  if (isKnownMigrationGroupSegment(parts[0])) {
    return normalizeMigrationGroupName(parts[0]);
  }

  // SMBC/smbc_dbac/... �̂悤��1�K�w�ڂ��ڍs�O���[�v�A2�K�w�ڂ��f�B���N�g���O���[�v�̌`���B
  // kayk.online/lib/... �̂悤��2�K�w�ڂ� lib �̏ꍇ�́A1�K�w�ڂ��f�B���N�g���O���[�v�Ƃ��Ĉ����B
  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return normalizeMigrationGroupName(parts[0]);
  }

  return "";
}

function extractDirectoryGroupFromPath(path) {
  const parts = getPathPartsForGroup(path);
  if (!parts.length) return "";

  if (isKnownMigrationGroupSegment(parts[0])) {
    return cleanDirectoryGroupName(parts[1] || "");
  }

  if (parts.length >= 2 && !isLikelyDirectoryOnlyPath(parts)) {
    return cleanDirectoryGroupName(parts[1] || parts[0]);
  }

  return cleanDirectoryGroupName(parts[0]);
}

function stringifyHistoryValueForCompare(value) {
  const entry = splitHistoryStorageValue(value);
  return [
    getHistoryEntryPath(value) || "",
    entry.openedAtRaw || "",
    entry.fileName || "",
    entry.project || "",
    entry.group || "",
    entry.directoryGroup || ""
  ].join("");
}

function normalizeHistoryValues(values) {
  const result = [];
  (Array.isArray(values) ? values : []).forEach(value => {
    const text = String(value || "").trim();
    const path = getHistoryEntryPath(value);
    if (!text || !path || isPlaceholderHistoryValue(path)) return;
    // 2026-08-20 fix152: ���������̓C�x���g�����Ȃ̂œ�����e�ł��폜���Ȃ��B
    result.push(text);
  });
  return result;
}

function compareFileHistoryItems(a, b) {
  const aEntry = splitHistoryStorageValue(a && a.value);
  const bEntry = splitHistoryStorageValue(b && b.value);
  const aSeed = aEntry.initialSeed === true;
  const bSeed = bEntry.initialSeed === true;

  // ���ۂɉ{�����������͏�ɏ���seed����ցB����seed���m�͒�`�z��̏��Ԃ����炷��B
  if (aSeed !== bSeed) return aSeed ? 1 : -1;
  if (aSeed && bSeed) {
    const aOrder = INITIAL_FILE_STORAGE_ORDER.has(a.path) ? INITIAL_FILE_STORAGE_ORDER.get(a.path) : Number.MAX_SAFE_INTEGER;
    const bOrder = INITIAL_FILE_STORAGE_ORDER.has(b.path) ? INITIAL_FILE_STORAGE_ORDER.get(b.path) : Number.MAX_SAFE_INTEGER;
    if (aOrder !== bOrder) return aOrder - bOrder;
  }

  const timeDiff = toSafeDate(b.openedAt).getTime() - toSafeDate(a.openedAt).getTime();
  if (timeDiff !== 0) return timeDiff;
  return String(a.path || "").localeCompare(String(b.path || ""));
}

function normalizeFileHistoryValues(values) {
  const result = [];
  (Array.isArray(values) ? values : []).forEach((value, index) => {
    const entry = splitHistoryStorageValue(value);
    const path = buildCompleteKruglePath(entry.path, entry.project, entry.group);
    if (!isValidFileHistoryPath(path)) return;

    const openedAt = parseHistoryOpenedAt(entry.openedAtRaw, new Date(Date.now() - index * 60 * 1000));
    const normalizedValue = createHistoryStorageValue(path, openedAt, {
      fileName: entry.fileName,
      project: entry.project,
      group: entry.group,
      directoryGroup: entry.directoryGroup,
      initialSeed: entry.initialSeed,
      seedMarker: entry.seedMarker
    });

    // 2026-08-20 fix152: path�P�ʂ�Map�����Ȃ��B
    // �����\�[�X�����x�J���Ă��A�J�����C�x���g1�񂲂Ƃ�1�s��ێ�����B
    result.push({ path, openedAt, value: normalizedValue });
  });

  return result
    .sort(compareFileHistoryItems)
    .map(item => item.value);
}

function seedFileHistoryStorage(key, values, sampleValues) {
  let result = normalizeFileHistoryValues(values);
  if (!result.length) {
    result = normalizeFileHistoryValues(sampleValues);
  }

  const raw = Array.isArray(values) ? values.map(stringifyHistoryValueForCompare).filter(Boolean) : [];
  const normalized = result.map(stringifyHistoryValueForCompare).filter(Boolean);
  if (!USE_SAMPLE_DATA && normalized.join("") !== raw.join("")) {
    saveArray(key, result);
  }
  return result;
}

function getDisplayFileHistoryRows(values, count = FILE_HISTORY_HOME_DISPLAY_LIMIT) {
  return normalizeFileHistoryValues(values).slice(0, count);
}

function addSearchResultsToFileHistory(rows, openedAt = new Date()) {
  if (USE_SAMPLE_DATA) return;
  const additions = (Array.isArray(rows) ? rows : [])
    .map((row, index) => normalizeSearchRow(row, index))
    .filter(row => row && !row.placeholder && isValidFileHistoryPath(row.path))
    .map(row => createHistoryStorageValue(row.path, openedAt, {
      fileName: row.fileName,
      project: row.project,
      group: row.group,
      directoryGroup: row.directoryGroup
    }));
  if (!additions.length) return;

  const current = readArray(FILE_HISTORY_STORAGE_KEY, []);
  saveArray(FILE_HISTORY_STORAGE_KEY, normalizeFileHistoryValues(additions.concat(current)));
  prioritizeGroupSelectOptionsByHistory();
  sessionRecentTabs = null;
  renderRecentTabs();
}

function initializeSearchHistoryStorageIfNeeded() {
  if (USE_SAMPLE_DATA) return;

  const initializedVersion = (() => {
    try { return localStorage.getItem(SEARCH_HISTORY_INITIALIZED_VERSION_KEY) || ""; }
    catch (e) { return ""; }
  })();
  if (initializedVersion === SEARCH_HISTORY_INITIAL_VERSION) return;

  const current = normalizeHistoryValues(readArray(SEARCH_HISTORY_STORAGE_KEY, []));
  const previousDefault = normalizeHistoryValues(PREVIOUS_INITIAL_SEARCH_WORDS_V1).slice(0, INITIAL_HISTORY_SAMPLE_COUNT);
  const currentFirst30 = current.slice(0, INITIAL_HISTORY_SAMPLE_COUNT);
  const isUntouchedPreviousDefault = current.length === previousDefault.length &&
    currentFirst30.join("\u0001") === previousDefault.join("\u0001");

  if (!current.length || isUntouchedPreviousDefault) {
    saveArray(
      SEARCH_HISTORY_STORAGE_KEY,
      normalizeHistoryValues(sampleSearchWords).slice(0, INITIAL_HISTORY_SAMPLE_COUNT)
    );
  }

  try { localStorage.setItem(SEARCH_HISTORY_INITIALIZED_VERSION_KEY, SEARCH_HISTORY_INITIAL_VERSION); }
  catch (e) { /* localStorage unavailable: keep current behavior */ }
}

function seedHistoryStorage(key, values, sampleValues, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  const original = normalizeHistoryValues(values);
  const result = original.slice();
  const used = new Set(result);

  (Array.isArray(sampleValues) ? sampleValues : []).forEach(value => {
    if (result.length >= count) return;
    const text = String(value || "").trim();
    if (!text || isPlaceholderHistoryValue(text) || used.has(text)) return;
    used.add(text);
    result.push(text);
  });

  // ����\���◚��20�������̊��ł́A�T���v�����܂߂�20���܂�localStorage�֕ۑ�����B
  // ��ŌŒ�T���v���l�ɍ����ւ��邾���ŁA�S���[�U�[�̏���N������20����������Ԃ��Č��ł���B
  // �ߋ��łœ������u-�v�⊮���A�ۑ����������Ƃŗ����f�[�^���珜������B
  const rawLength = Array.isArray(values) ? values.length : 0;
  const hasStorageDifference = rawLength !== original.length || result.join("") !== original.join("");
  if (!USE_SAMPLE_DATA && hasStorageDifference) {
    saveArray(key, result);
  }
  return result;
}

function getDisplayHistoryRows(values, count = INITIAL_HISTORY_SAMPLE_COUNT) {
  return normalizeHistoryValues(values).slice(0, count);
}

function normalizeMigrationGroupName(value) {
  const text = String(value || "").trim();
  if (!text) return "";

  // 2026-08-14 fix77:
  // �h�b�g�͈ڍs�O���[�v�����̂��̂Ɋ܂܂��ꍇ������B
  // ��: NIKKO.nikkoEZ.java17 -> nikkoEZ.java17
  //      nikkoEZ.java17       -> nikkoEZ.java17
  //      ROKINREN.bpsrk       -> ROKINREN.bpsrk
  // ���̂��߁u�ŏ�/�Ō�̃h�b�g�ȍ~�������c���v�ėp�����͋֎~����B
  // NIKKO / BPS / RPS / NewNikko �͕��ޗp�ړ����Ƃ��Ă̂ݏ�������B
  const withoutKnownPrefix = text.replace(/^(NIKKO|BPS|RPS|NewNikko)\./i, "");
  if (withoutKnownPrefix !== text) return withoutKnownPrefix;

  // �����f�[�^�݊�:
  // SMBC.SMBC / fast2024.fast2024 / nikkoEZ.nikkoEZ �̂悤��
  // �O�オ���ꖼ�̂̏d���\��������1�֏�ށB
  const duplicateMatch = text.match(/^([^.]+)\.([^.]+)$/);
  if (duplicateMatch && duplicateMatch[1].toLowerCase() === duplicateMatch[2].toLowerCase()) {
    return duplicateMatch[2];
  }

  // nikkoEZ.java17 / nikkoEZ.container / ROKINREN.bpsrk ����
  // �h�b�g���܂߂��S�̂�1�̈ڍs�O���[�v���Ȃ̂ŕێ�����B
  return text;
}

function formatHistoryFileParts(value) {
  const entry = splitHistoryStorageValue(value);
  const path = getHistoryEntryPath(value) || entry.path;
  if (!isValidFileHistoryPath(path)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE];
  }

  const pathParts = getPathPartsForGroup(path);
  const fileName = String(entry.fileName || pathParts[pathParts.length - 1] || path).trim();

  // �ۑ��ς݃��^�f�[�^����A���`���A�܂��́u-�v�ł��A���S�p�X�^project����K���⊮����B
  // ��: NIKKO.nkCCIS/kyak.online.jar/... -> nkCCIS / kyak.online
  const storedGroup = normalizeMigrationGroupName(entry.group);
  const pathGroup = normalizeMigrationGroupName(extractMigrationGroupFromPath(path));
  const projectGroup = normalizeMigrationGroupName(entry.project);
  const group = [pathGroup, projectGroup, storedGroup]
    .find(part => part && !isPlaceholderHistoryValue(part)) || HISTORY_PLACEHOLDER_VALUE;

  const storedDirectoryGroup = cleanDirectoryGroupName(entry.directoryGroup);
  const pathDirectoryGroup = cleanDirectoryGroupName(extractDirectoryGroupFromPath(path));
  const directoryGroup = [storedDirectoryGroup, pathDirectoryGroup]
    .find(part => part && !isPlaceholderHistoryValue(part)) || HISTORY_PLACEHOLDER_VALUE;

  return [fileName || HISTORY_PLACEHOLDER_VALUE, group, directoryGroup];
}

function formatHistoryFileHtml(value) {
  const parts = formatHistoryFileParts(value);
  const names = ["name", "group", "area"];
  return parts.map((part, index) =>
    `<span class="historyToken historyToken-${names[index] || index}">${escapeHtml(part)}</span>`
  ).join("");
}

function formatHistoryFileCellsHtml(value, cellClassPrefix = "historyFile") {
  const parts = formatHistoryFileParts(value);
  const classes = ["Name", "Group", "Dir"];
  return parts.map((part, index) =>
    `<td class="${cellClassPrefix}${classes[index]}">${escapeHtml(part)}</td>`
  ).join("");
}


function normalizeHistoryTableFilterText(value) {
  return normalizeSearchResultFilterText(value);
}

function getHistoryFileFilterText(value) {
  return formatHistoryFileParts(value).join(" ");
}

function getHistorySearchFilterText(value) {
  if (isPlaceholderHistoryValue(value)) return HISTORY_PLACEHOLDER_VALUE;
  const parsed = parseSearchHistoryValue(value);
  return [parsed.keyword, parsed.group, parsed.language].filter(Boolean).join(" ");
}

function filterHistoryFileRows(values, filterKey) {
  const source = Array.isArray(values) ? values : [];
  const query = normalizeHistoryTableFilterText(historyTableFilters[filterKey] || "");
  if (!query) return source.slice();
  return source.filter(value => normalizeHistoryTableFilterText(getHistoryFileFilterText(value)).includes(query));
}

function filterHistorySearchRows(values) {
  const source = Array.isArray(values) ? values : [];
  const query = normalizeHistoryTableFilterText(historyTableFilters.homeSearch || "");
  if (!query) return source.slice();
  return source.filter(value => normalizeHistoryTableFilterText(getHistorySearchFilterText(value)).includes(query));
}

function syncHistoryTableFilterUi(options = {}) {
  document.querySelectorAll(".historyTableFilterRow[data-history-filter-row]").forEach(row => {
    const key = row.dataset.historyFilterRow || "";
    row.hidden = key !== activeHistoryTableFilterKey;
  });

  document.querySelectorAll(".historyTableFilterToggle[data-history-filter-key]").forEach(button => {
    const key = button.dataset.historyFilterKey || "";
    const expanded = key === activeHistoryTableFilterKey;
    button.setAttribute("aria-expanded", expanded ? "true" : "false");
    button.classList.toggle("isOpen", expanded);
    button.classList.toggle("isFiltered", Boolean(normalizeHistoryTableFilterText(historyTableFilters[key] || "")));
  });

  document.querySelectorAll(".historyTableFilterInput[data-history-filter-input]").forEach(input => {
    const key = input.dataset.historyFilterInput || "";
    const value = String(historyTableFilters[key] || "");
    if (input.value !== value) input.value = value;
  });

  if (options.focus === true && activeHistoryTableFilterKey) {
    const input = document.querySelector(`.historyTableFilterInput[data-history-filter-input="${activeHistoryTableFilterKey}"]`);
    if (input) {
      window.requestAnimationFrame(() => {
        input.focus({ preventScroll: true });
        const length = input.value.length;
        if (typeof input.setSelectionRange === "function") input.setSelectionRange(length, length);
      });
    }
  }
}

function bindHistoryTableFilters() {
  document.querySelectorAll(".historyTableFilterToggle[data-history-filter-key]").forEach(button => {
    if (button.__krugleHistoryFilterBound === true) return;
    button.__krugleHistoryFilterBound = true;
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      const key = button.dataset.historyFilterKey || "";
      if (!HISTORY_TABLE_FILTER_KEYS.includes(key)) return;
      activeHistoryTableFilterKey = activeHistoryTableFilterKey === key ? "" : key;
      syncHistoryTableFilterUi({ focus: Boolean(activeHistoryTableFilterKey) });
    });
  });

  document.querySelectorAll(".historyTableFilterInput[data-history-filter-input]").forEach(input => {
    if (input.__krugleHistoryFilterBound === true) return;
    input.__krugleHistoryFilterBound = true;
    input.addEventListener("input", () => {
      const key = input.dataset.historyFilterInput || "";
      if (!HISTORY_TABLE_FILTER_KEYS.includes(key)) return;
      historyTableFilters[key] = input.value || "";
      renderHistory();
      syncHistoryTableFilterUi();
    });
    input.addEventListener("keydown", event => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      activeHistoryTableFilterKey = "";
      syncHistoryTableFilterUi();
    });
  });

  document.querySelectorAll(".historyTableFilterClear[data-history-filter-clear]").forEach(button => {
    if (button.__krugleHistoryFilterBound === true) return;
    button.__krugleHistoryFilterBound = true;
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      const key = button.dataset.historyFilterClear || "";
      if (!HISTORY_TABLE_FILTER_KEYS.includes(key)) return;
      historyTableFilters[key] = "";
      activeHistoryTableFilterKey = "";
      const input = document.querySelector(`.historyTableFilterInput[data-history-filter-input="${key}"]`);
      if (input) input.value = "";
      renderHistory();
      syncHistoryTableFilterUi();
    });
  });

  syncHistoryTableFilterUi();
}

function renderGlobalHistoryMini(displayFiles) {
  const body = $("globalHistoryMiniBody");
  if (!body) return;

  // 2026-08-20 fix152: �z�[����500���\���֊g�����邪�A�\�[�X�E�������͏]�������̍ő�300�����ێ�����B
  const source = filterHistoryFileRows(
    (Array.isArray(displayFiles) ? displayFiles : []).slice(0, FILE_HISTORY_GLOBAL_DISPLAY_LIMIT),
    "globalFile"
  );

  body.innerHTML = source.map((value, index) => {
    const path = getHistoryEntryPath(value);
    const openedAt = getHistoryEntryOpenedAt(value);
    const isPlaceholder = !isValidFileHistoryPath(path);
    return `
      <tr class="globalHistoryMiniRow${isPlaceholder ? " isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(path)}" data-opened-at="${isPlaceholder ? "" : escapeHtml(openedAt)}" aria-label="${escapeHtml(path)}">
        <td>${index + 1}</td>
        ${formatHistoryFileCellsHtml(value, "historyFile")}
      </tr>
    `;
  }).join("");

  body.querySelectorAll("tr").forEach(row => {
    const activate = () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path, {
        addRecent: false,
        recentItem: { path: row.dataset.path, openedAt: row.dataset.openedAt || "" }
      });
    };
    row.addEventListener("click", activate);
    if (row.dataset.path) {
      bindFullWidthHoverBandToRow(row, formatRecentTabFullPathBandText(row.dataset.path), activate);
    }
  });
}

function formatHistorySearchHtml(value) {
  if (isPlaceholderHistoryValue(value)) {
    return [HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE, HISTORY_PLACEHOLDER_VALUE]
      .map((part, index) =>
        `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
      )
      .join("");
  }

  return String(value || "")
    .split("|")
    .map(part => part.trim())
    .filter(Boolean)
    .map((part, index) =>
      `<span class="historySearchToken historySearchToken-${index}">${escapeHtml(part)}</span>`
    )
    .join("");
}

// 2026-07-29 �ĊJ�C��3: AJAX�����ł̓u���E�U�W���̓��͗����Ɏc��Ȃ����߁A
// Krugle+ �̌��������� datalist �֔��f���A�����L�[���[�h���͗��Ō��\���ł���悤�ɂ���B
function parseSearchHistoryValue(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim());

  return {
    keyword: parts[0] || "",
    group: parts[1] || "ALL",
    language: parts[2] || "ALL"
  };
}

function getKeywordHistorySuggestions(values, limit = 100) {
  const result = [];
  const used = new Set();

  (Array.isArray(values) ? values : []).forEach(value => {
    const keyword = parseSearchHistoryValue(value).keyword;
    if (!keyword || isPlaceholderHistoryValue(keyword)) return;

    const key = keyword.toLowerCase();
    if (used.has(key)) return;

    used.add(key);
    result.push(keyword);
  });

  return result.slice(0, limit);
}

function renderKeywordHistoryDatalist(values) {
  const list = $("keywordHistoryList");
  if (!list) return;

  let sourceValues = Array.isArray(values)
    ? values
    : (USE_SAMPLE_DATA ? sampleSearchWords : readArray(SEARCH_HISTORY_STORAGE_KEY, []));

  if (!USE_SAMPLE_DATA && !Array.isArray(values)) {
    sourceValues = seedHistoryStorage(SEARCH_HISTORY_STORAGE_KEY, sourceValues, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }

  const suggestions = getKeywordHistorySuggestions(sourceValues);
  list.innerHTML = suggestions
    .map(keyword => `<option value="${escapeHtml(keyword)}"></option>`)
    .join("");
}

function setSelectValueByTextOrValue(selectElement, value, fallback = "ALL") {
  if (!selectElement) return;
  const target = String(value || fallback).trim();
  const normalizedTarget = target.toLowerCase();
  const option = Array.from(selectElement.options).find(item => {
    const optionValue = String(item.value || "").trim().toLowerCase();
    const optionText = String(item.textContent || "").trim().toLowerCase();
    return optionValue === normalizedTarget || optionText === normalizedTarget;
  });
  selectElement.value = option ? option.value : fallback;
}

function fillSearchFormFromHistory(value) {
  const parts = String(value || "")
    .split("|")
    .map(part => part.trim());

  const keyword = parts[0] || "";
  const group = parts[1] || "ALL";
  const language = parts[2] || "ALL";

  const keywordInput = $("keywordInput");
  if (keywordInput) keywordInput.value = keyword;

  setSelectValueByTextOrValue($("groupSelect"), group, "ALL");
  refreshGroupCombo({ resetFilter: true });
  setSelectValueByTextOrValue($("languageSelect"), language, "ALL");
}

function openSearchFromHistory(value) {
  fillSearchFormFromHistory(value);
  showView("search", { recordNavigation: false });
  runSearch(true, "normal");
}

function resetStoredHistories() {
  // �����N���A�Ő����^�u�̎��̂�����ւ�邽�߁A�����^�u�ɕR�Â��y�ʃe�[�u���Q�Ƃ������ɔj������B
  // ���̑���localStorage / SessionStorage�ݒ�͏]���ǂ���c���B
  localStorage.removeItem(FILE_HISTORY_STORAGE_KEY);
  localStorage.removeItem(SEARCH_HISTORY_STORAGE_KEY);
  localStorage.removeItem(FILE_HISTORY_INITIALIZED_VERSION_KEY);
  removeSessionStorage(TABLE_INFO_TAB_SESSION_STORAGE_KEY);

  const initialFiles = createInitialFileHistorySeedValues().slice(0, INITIAL_HISTORY_SAMPLE_COUNT);
  const initialWords = normalizeHistoryValues(sampleSearchWords).slice(0, INITIAL_HISTORY_SAMPLE_COUNT);

  saveArray(FILE_HISTORY_STORAGE_KEY, initialFiles);
  saveArray(SEARCH_HISTORY_STORAGE_KEY, initialWords);
  localStorage.setItem(SEARCH_HISTORY_INITIALIZED_VERSION_KEY, SEARCH_HISTORY_INITIAL_VERSION);
  localStorage.setItem(FILE_HISTORY_INITIALIZED_VERSION_KEY, FILE_HISTORY_INITIAL_VERSION);
  prioritizeGroupSelectOptionsByHistory();

  // �����^�u����������̃t�@�C����������č\�z����B
  sessionRecentTabs = null;
  recentWindowStart = 0;
  activeRecentTabKey = "";
  volatileVisitedRecentTabIds.clear();
  renderRecentTabs();
  renderHistory();
  showCopyFeedback("������30���̏����f�[�^�ɖ߂��܂���");
}

function renderHistory() {
  initializeSearchHistoryStorageIfNeeded();
  let files = readFileHistoryValues();
  let words = USE_SAMPLE_DATA ? sampleSearchWords : readArray(SEARCH_HISTORY_STORAGE_KEY, []);

  if (!USE_SAMPLE_DATA) {
    words = seedHistoryStorage(SEARCH_HISTORY_STORAGE_KEY, words, sampleSearchWords, INITIAL_HISTORY_SAMPLE_COUNT);
  }

  const displayFiles = getDisplayFileHistoryRows(files, FILE_HISTORY_HOME_DISPLAY_LIMIT);
  const displayWords = getDisplayHistoryRows(words, SEARCH_HISTORY_HOME_DISPLAY_LIMIT);
  const filteredHomeFiles = filterHistoryFileRows(displayFiles, "homeFile");
  const filteredHomeWords = filterHistorySearchRows(displayWords);

  renderKeywordHistoryDatalist(words);
  renderGlobalHistoryMini(displayFiles);

  $("historyFileBody").innerHTML = filteredHomeFiles.map((value, index) => {
    const path = getHistoryEntryPath(value);
    const openedAt = getHistoryEntryOpenedAt(value);
    const isPlaceholder = !isValidFileHistoryPath(path);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-path="${isPlaceholder ? "" : escapeHtml(path)}" data-opened-at="${isPlaceholder ? "" : escapeHtml(openedAt)}" aria-label="${escapeHtml(path)}">
        <td>${index + 1}</td>
        ${formatHistoryFileCellsHtml(value, "historyFile")}
      </tr>
    `;
  }).join("");

  $("historySearchBody").innerHTML = filteredHomeWords.map((value, index) => {
    const isPlaceholder = isPlaceholderHistoryValue(value);
    return `
      <tr class="${isPlaceholder ? "isPlaceholderHistoryRow" : ""}" data-keyword="${isPlaceholder ? "" : escapeHtml(value)}" aria-label="${escapeHtml(value)}">
        <td>${index + 1}</td>
        <td class="historySearchText">${formatHistorySearchHtml(value)}</td>
      </tr>
    `;
  }).join("");

  document.querySelectorAll("#historyFileBody tr").forEach(row => {
    const activate = () => {
      if (!row.dataset.path) return;
      openCode(row.dataset.path, {
        addRecent: false,
        recentItem: { path: row.dataset.path, openedAt: row.dataset.openedAt || "" }
      });
    };
    row.addEventListener("click", activate);
    if (row.dataset.path) {
      bindFullWidthHoverBandToRow(row, formatRecentTabFullPathBandText(row.dataset.path), activate);
    }
  });
  document.querySelectorAll("#historySearchBody tr").forEach(row => {
    const activate = () => {
      if (!row.dataset.keyword) return;
      openSearchFromHistory(row.dataset.keyword);
    };
    row.addEventListener("click", activate);
    if (row.dataset.keyword) {
      bindFullWidthHoverBandToRow(row, createHistorySearchBandText(row.dataset.keyword), activate);
    }
  });
}

function setActiveTab(viewName) {
  document.querySelectorAll(".tabBtn").forEach(button => button.classList.remove("isActive"));
  if (viewName !== "code") {
    document.querySelectorAll(".tabTime").forEach(button => button.classList.remove("isActive"));
  }
  const target = document.querySelector(`.tabBtn[data-view="${viewName}"]:not(.tabFile)`);
  if (target) target.classList.add("isActive"); }


function getWindowScrollTopForCodeSearchPanel() {
  const doc = document.documentElement;
  const body = document.body;
  return Math.max(
    0,
    Number(window.pageYOffset || 0),
    Number(doc && doc.scrollTop || 0),
    Number(body && body.scrollTop || 0)
  );
}

let codeSearchPanelScrollAnimationFrame = 0;

function isCodeSearchPanelScrollAutoHideTarget() {
  const codeView = $("codeView");
  return Boolean(document.body && document.body.classList.contains("isCodeScreen") && codeView && codeView.classList.contains("isVisible"));
}

function updateCodeSearchPanelScrollState() {
  if (!document.body) return;
  if (!isCodeSearchPanelScrollAutoHideTarget()) {
    document.body.classList.remove("isCodeSearchPanelScrolled");
    return;
  }

  const shouldHide = getWindowScrollTopForCodeSearchPanel() > 12;
  document.body.classList.toggle("isCodeSearchPanelScrolled", shouldHide);
}

function requestCodeSearchPanelScrollStateUpdate() {
  if (codeSearchPanelScrollAnimationFrame) return;
  codeSearchPanelScrollAnimationFrame = window.requestAnimationFrame
    ? window.requestAnimationFrame(() => {
        codeSearchPanelScrollAnimationFrame = 0;
        updateCodeSearchPanelScrollState();
      })
    : window.setTimeout(() => {
        codeSearchPanelScrollAnimationFrame = 0;
        updateCodeSearchPanelScrollState();
      }, 16);
}

function showView(viewName, options = {}) {
  if ((viewName === "home" || viewName === "search") && options.recordNavigation !== false) {
    recordTabNavigation(createViewTabNavigationEntry(viewName));
  }

  // �R�[�h�擾���Ƀz�[���E�������ʂ֖߂����ꍇ�A�x��ĕԂ���/source���ʂŏ�Ԃ��㏑�������Ȃ��B
  if (viewName !== "code") sourceOpenRequestSequence += 1;

  currentView = viewName;
  document.body.classList.toggle("isCodeScreen", viewName === "code");
  document.querySelectorAll(".viewBlock").forEach(view => view.classList.remove("isVisible"));
  const targetView = $(`${viewName}View`);
  if (targetView) targetView.classList.add("isVisible");
  setActiveTab(viewName);
  if (viewName === "home") renderHistory();
  if (viewName === "code") renderCode();
  requestCodeSearchPanelScrollStateUpdate();
}

function getDirectoryGroup(path) {
  return extractDirectoryGroupFromPath(path);
}

function nowForSearchPerformance() {
  return (window.performance && typeof window.performance.now === "function") ? window.performance.now() : Date.now();
}

function roundSearchPerformanceMs(value) {
  return Math.round(Number(value || 0) * 10) / 10;
}

function logSearchPerformance(metrics) {
  if (!window.console || typeof window.console.info !== "function") return;
  console.info("Krugle+ search performance", metrics);
}

async function runSearch(saveHistory = true, mode = "normal", options = {}) {
  const startedAt = new Date();
  const params = options && options.paramsOverride
    ? Object.assign({}, options.paramsOverride)
    : buildSearchParams(mode);

  // 2026-08-12 fix47: ���[�U�[����̌����ŃL�[���[�h����/�L�������̏ꍇ�́A
  // ��ʕ\����ς����A����ǉ���Servlet�Ăяo�����s��Ȃ��B
  if (saveHistory && !hasExecutableSearchKeyword(params.rawKeyword)) return false;

  lastSearchMode = mode;
  lastSearchParams = params;
  // �V�����������ʂɑO��̗�t�B���^�[�������z���Ȃ��B
  resetSearchResultColumnFilters();

  if (saveHistory) {
    addHistory(SEARCH_HISTORY_STORAGE_KEY, `${params.rawKeyword} | ${params.projectText || params.project} | ${params.languageText || params.language}`, []);
    renderKeywordHistoryDatalist();
  }

  setSummaryFromParams(params, startedAt, null, "������");
  setSearchResultLimitNotice(null);
  // 2026-08-12 fix63: �O�񌟍��̕����`�悪�c���Ă��Ă��A�������́u�������v�\���֒ǋL�����Ȃ��B
  searchRenderSequence += 1;
  currentRenderedSearchRows = [];
  const body = $("resultBody");
  if (body) body.innerHTML = `<tr><td colspan="5">������...</td></tr>`;

  if (USE_SAMPLE_DATA) {
    const endedAt = new Date(startedAt.getTime() + 1000);
    const sortedSampleRows = sortSearchResultsForDisplay(sampleResults);
    lastSearchResults = filterSearchResultsByDirectoryGroup(sortedSampleRows, params.directoryGroup);
    setSummaryFromParams(params, startedAt, endedAt, lastSearchResults.length);
    // 2026-08-04 �T�C�g�C��2: �������s�����ł́A�������ʂ��{�������E�w�b�_�[�����^�u�֓o�^���Ȃ��B
    // ���ۂɌ������ʍs���N���b�N�A�܂���Enter�ŊJ�����Ƃ����� openCode() �o�R�œo�^����B
    const sampleRenderStart = nowForSearchPerformance();
    const sampleRenderInfo = renderSearchRows(lastSearchResults, { normalized: true });
    logSearchPerformance({
      backend: "sample",
      rows: lastSearchResults.length,
      renderInitialMs: roundSearchPerformanceMs(nowForSearchPerformance() - sampleRenderStart),
      initialRows: sampleRenderInfo.initialRows,
      chunked: sampleRenderInfo.chunked
    });
    if (saveHistory && options.recordNavigation !== false) recordCurrentSearchNavigationSnapshot(mode, params);
    return;
  }

  try {
    // 2026-08-05 �C��10:
    // �u���E�U -> Servlet �͏]���ǂ��� /search POST�B
    // Servlet ���� Krugle �� get_csv.cgi �𐳋KCSV�Ƃ��Ď擾�E��򂵂�JSON������B
    // source_disp �� get_csv.cgi �̌���CSV�擾�ł͕s�v�Ȃ��ߓn���Ȃ��B
    const fetchStart = nowForSearchPerformance();
    const data = await fetchJson("/search", {
      path_output_format: "PATH",
      keyword: params.keyword,
      project: params.project,
      language: params.languageForApi,
      findin: params.findin,
      clone: params.clone
    }, { method: "POST" });
    setSearchResultLimitNotice(data);
    const fetchEnd = nowForSearchPerformance();
    const endedAt = new Date();
    const serverRows = Array.isArray(data.rows) ? data.rows : data.results;
    const sortStart = nowForSearchPerformance();
    const sortedServerRows = sortSearchResultsForDisplay(serverRows);
    lastSearchResults = filterSearchResultsByDirectoryGroup(sortedServerRows, params.directoryGroup);
    const sortEnd = nowForSearchPerformance();
    setSummaryFromServer(data.summary, params, startedAt, endedAt, lastSearchResults.length);
    // 2026-08-04 �T�C�g�C��2: �������s�����ł́A�������ʂ��{�������E�w�b�_�[�����^�u�֓o�^���Ȃ��B
    // ���ۂɌ������ʍs���N���b�N�A�܂���Enter�ŊJ�����Ƃ����� openCode() �o�R�œo�^����B
    // 2026-08-03 �T�C�g�C��4: �������ʂ̓N���C�A���g���ŗD�揇�ɕ��ёւ��邽�߁A
    // �T�[�o�[����HTML�ł͂Ȃ��A���ёւ���̍s�f�[�^����ĕ`�悷��B
    // 2026-08-12 fix63: ��������100�����͏���100�s������ɕ`�悵�A�c��͕����ǉ�����B
    const renderStart = nowForSearchPerformance();
    const renderInfo = renderSearchRows(lastSearchResults, { normalized: true });
    const renderEnd = nowForSearchPerformance();
    logSearchPerformance({
      backend: data.backend || "krugle",
      rows: lastSearchResults.length,
      fetchMs: roundSearchPerformanceMs(fetchEnd - fetchStart),
      sortMs: roundSearchPerformanceMs(sortEnd - sortStart),
      renderInitialMs: roundSearchPerformanceMs(renderEnd - renderStart),
      initialRows: renderInfo.initialRows,
      chunked: renderInfo.chunked,
      server: data.performance || null
    });
    if (saveHistory && options.recordNavigation !== false) recordCurrentSearchNavigationSnapshot(mode, params);
  } catch (e) {
    console.error(e);
    lastSearchResults = [];
      setSummaryFromParams(params, startedAt, new Date(), 0);
    if (body) body.innerHTML = `<tr><td colspan="5">/search �ڑ����s�F${escapeHtml(e.message)}</td></tr>`;
    showCopyFeedback("/search �ڑ����s");
    if (saveHistory && options.recordNavigation !== false) recordCurrentSearchNavigationSnapshot(mode, params);
  }
}

function applyInitialSearchCondition() {
  const keywordInput = $("keywordInput");
  const groupSelect = $("groupSelect");
  const languageSelect = $("languageSelect");
  const cloneCheck = $("cloneCheck");

  if (keywordInput) keywordInput.value = INITIAL_SEARCH_CONDITION.keyword;
  setSelectValueByTextOrValue(groupSelect, INITIAL_SEARCH_CONDITION.project, "ALL");
  setSelectValueByTextOrValue(languageSelect, INITIAL_SEARCH_CONDITION.language, "ALL");

  // �Y�t��ʂƓ������uClone ��\���v�͖��`�F�b�N�BAPI�ɂ� clone=YES ��n���B
  if (cloneCheck) cloneCheck.checked = false;

  // �J�X�^���ڍs�O���[�v�\�������݂���ꍇ���A�I�𕶎��𓯊�����B
  refreshGroupCombo({ resetFilter: true });
}

async function loadInitialSearchResult() {
  // ����\����Mock/���������́A�����������͗��֒l�����Ȃ��B
  // �\�����ʂ��� KYF1940 / NIKKO.nkCCIS / Java �����Ŏ擾����B
  clearInitialSearchForm();
  await runSearch(false, INITIAL_SEARCH_CONDITION.mode, {
    paramsOverride: buildSearchParamsFromCondition(INITIAL_SEARCH_CONDITION, INITIAL_SEARCH_CONDITION.mode),
    // �����\���p��52�����A�{�������E�w�b�_�[�����֎����o�^���Ȃ��B
    addResultsToFileHistory: false
  });
  clearInitialSearchForm();
}

async function openCode(path, options = {}) {
  const requestId = ++sourceOpenRequestSequence;
  currentCodePath = getHistoryEntryPath(path || currentCodePath);
  updateCodeContextFixedLabel(currentCodePath);
  const requestedPath = currentCodePath;
  currentCodeMeta = options.row ? Object.assign({}, options.row) : { path: currentCodePath };
  currentCodeMeta.path = currentCodePath;
  // 2026-08-20 fix146:
  // /source-by-class �̓N���C�A���g���� sibling �����p�X�ł͂Ȃ��AServlet �� AI_FILE1/FQN ����Ԃ�
  // resolvedPath �����{�B�����O�̐����p�X�� fileStorage / �w�b�_�[�^�u / BackSpace �����֕ۑ����Ȃ��B
  // 2026-08-21: addRecent:false �́u�����^�u���ė��p����v�����w��Ƃ��Ĉ����B
  // �w�b�_�[�����^�u�E�ߋ��{�������EBackSpace���ł͐V�KfileStorage�s����炸�A
  // �������ʁE�\�[�X���N���X�������N���������V�K�^�u�����B
  const shouldAddRecent = options.addRecent !== false;
  const deferRecentUntilSourceResolution = Boolean(currentCodeMeta.javaClassName);
  currentSourceText = "�ǂݍ��ݒ�...";
  currentSourceLanguage = inferLanguageFromPath(currentCodePath, currentCodeMeta.language || "java");
  activeCodePanel = "source";
  resetTableInfoState();
  resetAiSampleData();

  let openedRecentItem = null;
  if (!deferRecentUntilSourceResolution) {
    if (shouldAddRecent) {
      // �������ʂȂǁu�V�K�^�u�v�̓�������fileStorage�擪��1���ǉ�����B
      openedRecentItem = addRecentTab(currentCodePath, currentCodeMeta || {});
    } else {
      // �w�b�_�[�����^�u�^�ߋ��{�������Ȃǂ́A�ۑ��ς݃^�u�����̂܂ܑI������B
      openedRecentItem = activateExistingRecentTab(currentCodePath, options);
    }
  }

  const navigationRecentItem = openedRecentItem || (
    options.recentItem && options.recentItem.path && options.recentItem.openedAt
      ? { path: getHistoryEntryPath(options.recentItem.path), openedAt: toSafeDate(options.recentItem.openedAt).toISOString() }
      : null
  );
  if (navigationRecentItem && options.recordNavigation !== false) {
    recordTabNavigation(createRecentTabNavigationEntry(navigationRecentItem, currentCodeMeta || {}));
  }

  // fileStorage���ω�����̂͐V�K�^�u�쐬�������B�����^�u�ė��p���͗����̕��сE������ύX���Ȃ��B
  if (!deferRecentUntilSourceResolution && shouldAddRecent) {
    renderGlobalHistoryMini(
      getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT)
    );
  }

  // �V�����A�N�e�B�u�ɂȂ��������^�u�ɕۑ��ς݃e�[�u���^�u������΁A���ʎq�����𕜌�����B
  // ���`�͂����ł͕ێ��E���������A�e�e�[�u���^�u���N���b�N��������Servlet�����蒼���B
  if (!deferRecentUntilSourceResolution) {
    restoreTableInfoTabsForActiveRecentTab();
  }

  showView("code", { recordNavigation: false });
  setCurrentTableNames([]);
  renderCode(currentSourceText, currentSourceLanguage);
  // �ʏ�p�X�̓\�[�X�擾�ƕ��s���āAWAR������AI�T���v���L�����y�ʊm�F����B
  if (!deferRecentUntilSourceResolution) {
    loadAiSampleAssetsInBackground(requestId, currentCodePath);
  }

  if (USE_SAMPLE_DATA) {
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    setCurrentTableNames(["MST_CUSTOMER", "KYF1940", "RPS_TABLE_LIST"]);
    currentSourceText = sampleCode;
    mergeCurrentTableNames(extractJavaTableNamesFromSource(currentSourceText));
    renderCode(currentSourceText, currentSourceLanguage);
    return;
  }

  const sourceParams = {
    path: currentCodeMeta.path || currentCodePath,
    fullPath: currentCodeMeta.path || currentCodePath,
    filePath: currentCodeMeta.path || currentCodePath,
    project: currentCodeMeta.project || "",
    href: currentCodeMeta.href || "",
    sourceUrl: currentCodeMeta.sourceUrl || "",
    language: currentSourceLanguage,
    source_disp: "YES"
  };

  // 2026-08-03 �T�C�g�C��9:
  // Java�N���X���n�C���C�g����J���ꍇ�́A�t�����g�ł͑S�p�X�𐄑������炸�A
  // �N���X�� + �J�ڌ�����Servlet�֓n���AAI_FILE1��FULLPATH/FILEPATH������Servlet���֔C����B
  const sourceEndpoint = currentCodeMeta.javaClassName ? "/source-by-class" : "/source";
  if (currentCodeMeta.javaClassName) {
    sourceParams.className = currentCodeMeta.javaClassName;
    sourceParams.javaClassName = currentCodeMeta.javaClassName;
    // 2026-08-14 fix80: import�Ɋ��S�C���N���X�������݂���ꍇ�́A�P���N���X���Ɨ�����Servlet�֓n���B
    // AI_FILE1�œ����N���X�������q�b�g���Ă��AServlet����package���S��v�����ŗD��ł���悤�ɂ���B
    sourceParams.qualifiedClassName = currentCodeMeta.javaQualifiedClassName || currentCodeMeta.qualifiedClassName || "";
    sourceParams.javaQualifiedClassName = sourceParams.qualifiedClassName;
    sourceParams.importQualifiedClassName = sourceParams.qualifiedClassName;
    sourceParams.originPath = currentCodeMeta.originPath || currentCodeMeta.originFullPath || "";
    sourceParams.originFullPath = currentCodeMeta.originFullPath || currentCodeMeta.originPath || "";
    sourceParams.originProject = currentCodeMeta.originProject || "";
    sourceParams.originGroup = currentCodeMeta.originGroup || "";
    sourceParams.originDirectoryGroup = currentCodeMeta.originDirectoryGroup || "";
    sourceParams.originPackage = currentCodeMeta.originPackage || "";
  }
  // 2026-08-05 �C��11: Krugle source_disp.cgi �̎�URL��Servlet���� ? �ȍ~�� %2F �t���ɐ��K�G���R�[�h����B
  const directUrl = `${apiPath(sourceEndpoint)}?${buildQueryString(sourceParams)}`;

  try {
    // source��GET�ŌĂԁB�\�[�X�\���� /init �a�ʊm�F��҂����A�ۑ��ςݐڑ���܂��͑�1Servlet�֒��ڎ��ɍs���B
    const cacheKey = buildSourceResponseCacheKey(sourceEndpoint, sourceParams);
    const cachedData = readSourceResponseCache(cacheKey);
    const data = cachedData || await fetchSourceJsonFast(sourceEndpoint, sourceParams);

    // 2026-08-24 fix158: Java�N���X�Q�ƑJ�ڂ�Servlet�̓�d���؍ς݉����������󗝂���B
    // ��WAR�E�B�����E����path�Emock����������Đ����^�u�Ƃ��ĕۑ����Ȃ��B
    if (sourceEndpoint === "/source-by-class") {
      const verifiedPath = String(data && (data.resolvedPath || data.fullPath || data.path) || "").trim();
      const expectedClass = String(currentCodeMeta.javaClassName || "").trim();
      const returnedClass = String(data && data.className || "").trim();
      const returnedFile = getRecentTabFileName(verifiedPath);
      if (!data || data.status !== "ok" || data.resolutionVerified !== true || !verifiedPath ||
          (expectedClass && returnedClass && expectedClass !== returnedClass) ||
          (expectedClass && returnedFile.toLowerCase() !== `${expectedClass}.java`.toLowerCase())) {
        const safeMessage = String(data && (data.error || data.resolutionMessage) ||
          "Servlet��Java�Q�Ɛ�̈��S�����m�F�ł��Ȃ��������߁A��J�ږh�~�̂��ߊJ���܂���ł����B");
        throw createApiError(safeMessage, {
          apiUnavailable: false,
          responseData: data || {},
          unsafeSourceResolution: true
        });
      }
    }

    if (!cachedData) writeSourceResponseCache(cacheKey, data);
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    if (data.resolvedPath || data.fullPath || data.path) {
      const resolvedPath = data.resolvedPath || data.fullPath || data.path;
      currentCodePath = getHistoryEntryPath(resolvedPath);
      updateCodeContextFixedLabel(currentCodePath);
      currentCodeMeta.path = currentCodePath;
      currentCodeMeta.fullPath = currentCodePath;
      currentCodeMeta.fileName = getRecentTabFileName(currentCodePath);
      currentCodeMeta.project = data.project || extractProjectFromPath(currentCodePath) || currentCodeMeta.project || "";
      currentCodeMeta.group = data.group || extractMigrationGroupFromPath(currentCodePath) || currentCodeMeta.group || "";
      currentCodeMeta.directoryGroup = data.directoryGroup || getRawDirectoryGroupFromPath(currentCodePath) || currentCodeMeta.directoryGroup || "";
    }

    if (deferRecentUntilSourceResolution) {
      // Servlet���Ԃ��� resolvedPath ��B��̐��{�Ƃ��ĕۑ�����B
      // ����ɂ��A�N���X���N���b�N��ɑ��^�u�ֈړ�����BackSpace�Ŗ߂��Ă��A
      // query/.../MeigaraIchiranQueryRecord.java ���̎��݃p�X�����̂܂ܕ��������B
      openedRecentItem = addRecentTab(currentCodePath, currentCodeMeta || {});
      if (openedRecentItem && options.recordNavigation !== false) {
        recordTabNavigation(createRecentTabNavigationEntry(openedRecentItem, currentCodeMeta || {}));
      }
      renderGlobalHistoryMini(
        getDisplayFileHistoryRows(readFileHistoryValues(), FILE_HISTORY_HOME_DISPLAY_LIMIT)
      );
      // class���N���b�N�͉����O�p�X�������l�̂��߁AresolvedPath�m����AI�T���v�����肷��B
      loadAiSampleAssetsInBackground(requestId, currentCodePath);
    }

    currentSourceText = stripKrugleMockSourceBanner(data.source || data.text || "");
    currentSourceLanguage = data.language || currentSourceLanguage;
    if (currentCodeMeta && typeof currentCodeMeta === "object") {
      currentCodeMeta.language = currentSourceLanguage;
    }
    updateCodeContextFixedLabel(currentCodePath);

    // 2026-08-07 �C��22:
    // /source Servlet��RPS_TABLE_LIST�ƍ��ς݂� tableHighlightTargets �𓯍����邽�߁A
    // �ŏ��� renderCode() ����e�[�u���n�C���C�g�𔽉f����B
    // �ǉ��� /table-highlight-targets �́A��WAR�����Esource-by-class�E�����X�V���̕ی��Ƃ��Č㑱�m�F�����s���B
    const initialTableTargets = getLegacyServerTableHighlightTargets(data);
    setCurrentTableNames(initialTableTargets);
    if (data.tableListError) {
      console.warn("table list load failed:", data.tableListError);
    }
    renderCode(currentSourceText, currentSourceLanguage);
    loadSourceTableHighlightTargetsInBackground(requestId, currentCodePath, currentSourceText, data, sourceEndpoint, initialTableTargets);
  } catch (e) {
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    console.error(e);
    currentSourceText = `/source �ڑ����s

${e.message}

���ڊm�FURL:
${directUrl}

�m�F�|�C���g:
1. krugleapi.war ��CORS�Ή��ł�
2. /krugleapi/source ��404�ɂȂ�Ȃ���
3. Chrome DevTools��Network��Access-Control-Allow-Origin���Ԃ��Ă��邩`;
    renderCode(currentSourceText, "plaintext");
    showCopyFeedback("/source �ڑ����s");
  }
}

function stripKrugleMockSourceBanner(sourceText) {
  const source = normalizeKrugleSourceText(String(sourceText || "").replace(/^\uFEFF/, ""));

  // ��WAR���t�����Ă���Mock�����R�����g�́A�\���ECopy�EDownload�̑Ώۂ��珜�O����B
  return source
    .replace(/^[ \t]*\/\*[ \t]*Krugle Mock: embedded template=[\s\S]*?\*\/[ \t]*(?:\r?\n)?/, "")
    .replace(/^--[ \t]*Krugle Mock: embedded template=.*(?:\r?\n)?/, "")
    .replace(/^--[ \t]*Krugle Mock SQL[ \t]*(?:\r?\n)?/, "");
}

// 2026-08-05 �C��8:
// Krugle source_disp.cgi �� HTML(<pre><ol><li>...</li></ol></pre>)�␧�䕶����Ԃ��ꍇ�����邽�߁A
// Java��Filter�ɉ����ăN���C�A���g���ł��ی��Ƃ��ăv���[���\�[�X�֐��`����B
function normalizeKrugleSourceText(sourceText) {
  let source = String(sourceText || "")
    .replace(/^\uFEFF/, "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "");

  const htmlExtracted = extractKrugleHtmlListSource(source);
  if (htmlExtracted) {
    source = htmlExtracted;
  } else {
    source = removeAppendedKrugleHtmlDocument(source);
    source = decodeHtmlEntities(source);
  }

  return normalizeSourceLineBreaks(source);
}

function isKrugleSourceHtmlListDocument(sourceText) {
  const source = String(sourceText || "");
  if (!/<li\b/i.test(source) || !/<\/li>/i.test(source)) return false;
  if (!/<pre\b[^>]*>\s*<ol\b[^>]*>/i.test(source) || !/<\/ol>\s*<\/pre>/i.test(source)) return false;

  // ��Krugle��source_disp.cgi�́A�^�C�g��/�p�X�\�� + hr + pre/ol/li �Ƃ������i�����B
  if (/<p\b[^>]*>\s*<strong\b/i.test(source) && /<hr\b/i.test(source)) return true;

  // ���i���ꕔ�����������ł��Ali�̒��g��HTML�G�X�P�[�v���ꂽ�\�[�X�s�Ȃ�Krugle wrapper�Ƃ��Ĉ����B
  // �t�ɁAJSP/HTML�\�[�X�{�����̂��̂� <html>/<li> ���܂܂�邾���̏ꍇ�́A�����ŏ��O����B
  const bodies = [];
  source.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi, (_, body) => {
    if (bodies.length < 12) bodies.push(String(body || ""));
    return "";
  });
  if (!bodies.length) return false;

  const encodedLineCount = bodies.filter(body => /&(?:lt|gt|quot|apos|amp|#\d+|#x[0-9a-f]+);/i.test(body)).length;
  return encodedLineCount >= Math.min(2, bodies.length);
}

function extractKrugleHtmlListSource(sourceText) {
  const source = String(sourceText || "");
  if (!isKrugleSourceHtmlListDocument(source)) return "";

  const lines = [];
  source.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi, (_, body) => {
    const line = decodeHtmlEntities(stripHtmlTags(String(body || "")))
      .replace(/[\r\n]+/g, "")
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
      .replace(/[ \t\f]+$/g, "");
    lines.push(line);
    return "";
  });

  return lines.length ? lines.join("\n") : "";
}

function removeAppendedKrugleHtmlDocument(sourceText) {
  const source = String(sourceText || "");
  const htmlIndex = source.search(/<html\b/i);
  if (htmlIndex < 0) return source;

  const before = source.substring(0, htmlIndex);
  if (!before.trim()) return source;

  // 2026-08-13 fix74:
  // JSP/HTML�\�[�X�{���́uJSP�f�B���N�e�B�u/DOCTYPE �̌�� <HTML> �������v�`�����ʂɂ���B
  // �������́A���� <HTML> ���uKrugle�����ɕt�����]����HTML�����v�ƌ�F���A
  // <%@ page ... %> �� <!DOCTYPE ...> ��2�s�������c���Ĉȍ~������Ă����B
  // �擪�����}�[�N�A�b�v�\�[�X�炵���ꍇ�͐�΂ɐ؂�̂ĂȂ��B
  if (looksLikeMarkupSourcePrefix(before)) return source;

  const appended = source.substring(htmlIndex);
  // �]����Krugle HTML�t�b�^�[/���b�p�[�炵�����i������ꍇ�����A�ی��Ƃ��Đ؂藣���B
  // �P�ɃR�[�h���� <html> �Ƃ��������񂪌��ꂽ���x�ł͍��Ȃ��B
  if (looksLikeAppendedKrugleHtmlDocument(appended)) {
    return before;
  }
  return source;
}

function looksLikeMarkupSourcePrefix(text) {
  const value = String(text || "").trim().toLowerCase();
  if (!value) return false;
  return value.indexOf("<%@") >= 0
    || value.indexOf("<%--") >= 0
    || value.indexOf("<jsp:") >= 0
    || value.indexOf("<!doctype") >= 0
    || value.indexOf("<?xml") >= 0
    || value.indexOf("<!--") >= 0;
}

function looksLikeAppendedKrugleHtmlDocument(text) {
  const value = String(text || "").toLowerCase();
  if (value.indexOf("<html") < 0 || value.indexOf("</html>") < 0) return false;
  return value.indexOf("source_disp.cgi") >= 0
    || value.indexOf("krugle") >= 0
    || /<p\b[^>]*>\s*<strong\b/i.test(text)
    || /<pre\b[^>]*>\s*<ol\b[^>]*>/i.test(text);
}

function stripHtmlTags(value) {
  return String(value || "")
    .replace(/<br\s*\/?\s*>/gi, "\n")
    .replace(/<\/(p|div|li)\s*>/gi, "\n")
    .replace(/<[^>]+>/g, "");
}

function decodeHtmlEntities(value) {
  const text = String(value || "")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&");

  return text.replace(/&#(x[0-9a-f]+|\d+);/gi, (_, code) => {
    const radix = /^x/i.test(code) ? 16 : 10;
    const normalizedCode = /^x/i.test(code) ? code.substring(1) : code;
    const value = parseInt(normalizedCode, radix);
    return Number.isFinite(value) ? String.fromCharCode(value) : _;
  });
}

function normalizeSourceLineBreaks(sourceText) {
  const lines = String(sourceText || "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .split("\n")
    .map(line => line.replace(/[ \t\f]+$/g, ""));

  let start = 0;
  let end = lines.length - 1;
  while (start <= end && lines[start].trim().length === 0) start += 1;
  while (end >= start && lines[end].trim().length === 0) end -= 1;
  if (start > end) return "";

  const removeOneBlankFromEachGap = isLikelyParserInsertedBlankLines(lines, start, end);
  const normalized = [];
  let pendingBlanks = 0;
  let wroteNonBlank = false;

  for (let i = start; i <= end; i += 1) {
    const line = lines[i];
    if (line.trim().length === 0) {
      pendingBlanks += 1;
      continue;
    }

    if (wroteNonBlank && pendingBlanks > 0) {
      const keep = removeOneBlankFromEachGap ? Math.max(0, pendingBlanks - 1) : Math.min(pendingBlanks, 1);
      for (let k = 0; k < keep; k += 1) normalized.push("");
    }
    normalized.push(line);
    wroteNonBlank = true;
    pendingBlanks = 0;
  }

  return normalized.join("\n");
}

function isLikelyParserInsertedBlankLines(lines, start = 0, end = lines.length - 1) {
  let nonBlank = 0;
  let gapCount = 0;
  let positiveGaps = 0;
  let oneBlankGaps = 0;
  let blankLines = 0;
  let pendingBlanks = -1;
  let currentOneBlankStreak = 0;
  let maxOneBlankStreak = 0;

  for (let i = start; i <= end; i += 1) {
    const blank = String(lines[i] || "").trim().length === 0;
    if (blank) {
      blankLines += 1;
      if (pendingBlanks >= 0) pendingBlanks += 1;
      continue;
    }

    nonBlank += 1;
    if (pendingBlanks >= 0) {
      gapCount += 1;
      if (pendingBlanks > 0) {
        positiveGaps += 1;
        if (pendingBlanks === 1) {
          oneBlankGaps += 1;
          currentOneBlankStreak += 1;
          maxOneBlankStreak = Math.max(maxOneBlankStreak, currentOneBlankStreak);
        } else {
          currentOneBlankStreak = 0;
        }
      } else {
        currentOneBlankStreak = 0;
      }
    }
    pendingBlanks = 0;
  }

  if (nonBlank < 12 || gapCount < 10 || blankLines < 8) return false;
  if (maxOneBlankStreak >= 8 && oneBlankGaps >= 8) return true;
  return positiveGaps * 100 >= gapCount * 35 && oneBlankGaps * 100 >= positiveGaps * 65;
}

function renderCode(sourceText = currentSourceText, language = currentSourceLanguage) {
  // codeBlock��DOM���č\�z����O�ɁA��DOM���w���I��Range�����j������B
  clearCodeSelectionSearchState();
  if (activeCodePanel === "ai" && !currentAiSampleData.commentAvailable) {
    activeCodePanel = "source";
  } else if (activeCodePanel === "summary" && !currentAiSampleData.summaryAvailable) {
    activeCodePanel = "source";
  }

  const codeView = $("codeView");
  const codeBlock = $("codeBlock");
  const tableInfoPanel = $("tableInfoPanel");
  const summaryPanel = $("markdownSummaryPanel");
  const aiSampleNotice = $("aiSampleNotice");
  const codeBodyFrame = codeView ? codeView.querySelector(".codeBodyFrame") : null;
  const tableMode = isTableInfoPanel(activeCodePanel);
  const aiMode = activeCodePanel === "ai" && currentAiSampleData.commentAvailable;
  const summaryMode = activeCodePanel === "summary" && currentAiSampleData.summaryAvailable;

  if (tableMode) {
    activeTableInfoTabId = getTableInfoTabIdFromPanel(activeCodePanel) || activeTableInfoTabId;
    tableInfoState = getActiveTableInfoState();
  }

  const tableDetailMode = tableMode && tableInfoState && tableInfoState.status === "detail";
  if (codeView) {
    codeView.classList.toggle("isTableInfoMode", tableMode);
    codeView.classList.toggle("isTableInfoDetailMode", tableDetailMode);
    codeView.classList.toggle("isAiExplanationMode", aiMode);
    codeView.classList.toggle("isSummaryMode", summaryMode);
  }
  if (tableInfoPanel) tableInfoPanel.hidden = !tableMode;
  if (codeBodyFrame) codeBodyFrame.hidden = tableMode;
  if (summaryPanel) summaryPanel.hidden = !summaryMode;
  // AI���p�T���v�����ӕ��́A���́u�\�[�X�R�[�h�v�ł͂Ȃ�AI�n�^�u�\��������������B
  if (aiSampleNotice) aiSampleNotice.hidden = !(aiMode || summaryMode);

  document.querySelectorAll(".codeModeTab").forEach(button => {
    button.classList.toggle("isActive", button.dataset.codePanel === activeCodePanel);
  });

  // fix82: openCode�ȊO�̍ĕ`��o�H�ł��A�\�[�X�^�u�̃t�@�C�����o�b�W�����݃p�X�֓�������B
  updateCodeContextFixedLabel(currentCodePath);

  if (tableMode) {
    if (aiSampleNotice) aiSampleNotice.hidden = true;
    if (summaryPanel) summaryPanel.hidden = true;
    const titleElement = $("codeTitle");
    if (titleElement) {
      // 2026-08-12 fix48: �e�[�u���ڍו\�������AcodeTitle�Ƀe�[�u����/DBTYPE/�X�L�[�}/Version��\������B
      titleElement.textContent = getTableInfoTitle();
    }
    syncCodePathCopyUi();
    renderTableInfoPanel();
    renderRecentTabs();
    return;
  }

  const source = stripKrugleMockSourceBanner(sourceText || (USE_SAMPLE_DATA ? sampleCode : ""));
  let displayText = source;
  let displayLanguage = language || inferLanguageFromPath(currentCodePath, "java");

  if (aiMode) {
    displayText = currentAiSampleData.commentSource || "";
    displayLanguage = currentAiSampleData.commentLanguage || inferLanguageFromPath(currentCodePath, displayLanguage);
  } else if (summaryMode) {
    displayText = currentAiSampleData.summaryMarkdown || "";
    displayLanguage = "plaintext";
  }

  if (codeView) codeView.classList.remove("isTableInfoDetailMode");
  const codeTitleElement = $("codeTitle");
  if (codeTitleElement) {
    codeTitleElement.textContent = currentCodePath || "";
    codeTitleElement.classList.remove("isPathCopyFlashing");
  }
  syncCodePathCopyUi();

  // �v�������Markdown��pDOM�ֈ��S�Ƀ����_�����O����B
  // codeBlock�ɂ���Markdown��ێ����A����Copy/Download�����Ƃ̌݊�����ۂB
  if (summaryMode) {
    codeBlock.removeAttribute("data-highlighted");
    delete codeBlock.dataset.highlighted;
    codeBlock.removeAttribute("data-safe-plain-source");
    codeBlock.removeAttribute("data-safe-markup-highlight");
    codeBlock.className = "language-plaintext";
    codeBlock.textContent = displayText;
    renderAiSummaryPanel(displayText);
    renderRecentTabs();
    return;
  }

  if (summaryPanel) summaryPanel.hidden = true;
  displayLanguage = resolveHighlightDisplayLanguage(displayLanguage, currentCodePath);

  codeBlock.removeAttribute("data-highlighted");
  delete codeBlock.dataset.highlighted;

  const safeMarkupHighlight = activeCodePanel === "source"
    && isSafeMarkupHighlightSource(displayLanguage, currentCodePath);
  const safePlainSource = activeCodePanel === "source"
    && shouldRenderSourceAsSafePlainText(displayLanguage, currentCodePath, displayText);

  if (safePlainSource) {
    renderSourceAsSafePlainText(codeBlock, displayText || "");
  } else {
    codeBlock.removeAttribute("data-safe-plain-source");
    if (safeMarkupHighlight) {
      // fix89: JSP/HTML/XML�̓\�[�X�������innerHTML�֒��ړ���Ȃ��B
      // textContent��DOM�֓������Ă���highlight.js(xml)�ɏ��������邱�ƂŁA<script>��JSP�������s�����Ȃ��B
      displayLanguage = "xml";
      codeBlock.className = "language-xml safeMarkupHighlightedSource";
      codeBlock.setAttribute("data-safe-markup-highlight", "true");
    } else {
      codeBlock.removeAttribute("data-safe-markup-highlight");
      codeBlock.className = `language-${displayLanguage}`;
    }
    codeBlock.textContent = displayText || "";
  }
  setCodeFontSize(codeFontSize);

  if (!safePlainSource && window.hljs) {
    try {
      window.hljs.highlightElement(codeBlock);
      // highlight.js����������DOM����i�ŕK���������ASPAN�ȊO�̎��s�\�v�f/�������c���Ȃ��B
      enforceSafeCodeBlockDom(codeBlock);
    } catch (error) {
      console.warn("highlight.js failed. fallback:", displayLanguage, error);
      codeBlock.removeAttribute("data-highlighted");
      delete codeBlock.dataset.highlighted;
      codeBlock.textContent = displayText || "";
      if (safeMarkupHighlight) {
        // �}�[�N�A�b�v�\�[�X��bash�֌딻�肳�����A���S�ȃv���[���\���֖߂��B
        codeBlock.removeAttribute("data-safe-markup-highlight");
        renderSourceAsSafePlainText(codeBlock, displayText || "");
      } else {
        displayLanguage = "bash";
        codeBlock.className = "language-bash";
        try {
          window.hljs.highlightElement(codeBlock);
          enforceSafeCodeBlockDom(codeBlock);
        } catch (fallbackError) {
          console.warn("highlight.js bash fallback failed:", fallbackError);
          codeBlock.className = "language-plaintext hljs";
          codeBlock.textContent = displayText || "";
        }
      }
    }
  }

  if (!safePlainSource) enforceSafeCodeBlockDom(codeBlock);

  if (activeCodePanel === "source" && !safePlainSource && !safeMarkupHighlight) {
    enhanceSourceHighlights(codeBlock, {
      language: displayLanguage,
      path: currentCodePath
    });
    enforceSafeCodeBlockDom(codeBlock);
  }

  renderRecentTabs();
}

function updateHighlightToggleButton() {
  const button = $("highlightToggleBtn");
  if (!button) return;

  const enabled = codeHighlightBackgroundEnabled === true;
  const nextState = enabled ? "OFF" : "ON";

  button.classList.toggle("isOn", enabled);
  button.classList.toggle("isOff", !enabled);
  button.setAttribute("aria-pressed", enabled ? "true" : "false");
  button.setAttribute(
    "aria-label",
    `�n�C���C�g�\���͌���${enabled ? "ON" : "OFF"}�ł��B�N���b�N�����${nextState}�ɂȂ�܂��B`
  );
  button.title = `�n�C���C�g�\��: ${enabled ? "ON" : "OFF"}�i�w�i�F�̂ݐؑցj`;

  const label = document.createElement("span");
  label.className = "highlightToggleLabel";
  label.textContent = "�n�C���C�g�\��";

  const off = document.createElement("span");
  off.className = "highlightToggleChoice highlightToggleChoiceOff" + (!enabled ? " isActive" : "");
  off.textContent = "OFF";
  off.setAttribute("aria-hidden", "true");

  const on = document.createElement("span");
  on.className = "highlightToggleChoice highlightToggleChoiceOn" + (enabled ? " isActive" : "");
  on.textContent = "ON";
  on.setAttribute("aria-hidden", "true");

  button.replaceChildren(label, off, on);
}

function setCodeHighlightBackgroundEnabled(enabled) {
  codeHighlightBackgroundEnabled = enabled === true;

  const codeView = $("codeView");
  if (codeView) {
    codeView.classList.toggle("isHighlightBackgroundOn", codeHighlightBackgroundEnabled);
    codeView.classList.toggle("isHighlightBackgroundOff", !codeHighlightBackgroundEnabled);
  }

  updateHighlightToggleButton();
}

function toggleCodeHighlightBackground() {
  setCodeHighlightBackgroundEnabled(!codeHighlightBackgroundEnabled);
}

// 2026-08-25 [3]: �\�[�X�R�[�h�̐܂�Ԃ��\�� ON/OFF�B
// DOM��highlight.js�̌��ʂ͍�蒼�����AcodeView�̏��class������؂�ւ���B
function updateCodeWrapToggleButton() {
  const button = $("codeWrapToggleBtn");
  if (!button) return;

  const enabled = codeWrapEnabled === true;
  const nextState = enabled ? "OFF" : "ON";
  button.classList.toggle("isOn", enabled);
  button.classList.toggle("isOff", !enabled);
  button.setAttribute("aria-pressed", enabled ? "true" : "false");
  button.setAttribute(
    "aria-label",
    `�܂�Ԃ��\���͌���${enabled ? "ON" : "OFF"}�ł��B�N���b�N�����${nextState}�ɂȂ�܂��B`
  );
  button.title = `�܂�Ԃ��\��: ${enabled ? "ON" : "OFF"}`;

  const label = document.createElement("span");
  label.className = "codeWrapToggleLabel";
  label.textContent = "�܂�Ԃ��\��";

  const on = document.createElement("span");
  on.className = "codeWrapToggleChoice codeWrapToggleChoiceOn" + (enabled ? " isActive" : "");
  on.textContent = "ON";
  on.setAttribute("aria-hidden", "true");

  const off = document.createElement("span");
  off.className = "codeWrapToggleChoice codeWrapToggleChoiceOff" + (!enabled ? " isActive" : "");
  off.textContent = "OFF";
  off.setAttribute("aria-hidden", "true");

  button.replaceChildren(label, on, off);
}

function setCodeWrapEnabled(enabled) {
  codeWrapEnabled = enabled !== false;
  const codeView = $("codeView");
  if (codeView) {
    codeView.classList.toggle("isCodeWrapOn", codeWrapEnabled);
    codeView.classList.toggle("isCodeWrapOff", !codeWrapEnabled);
  }

  // OFF��ON�֖߂������́A���X�N���[���ʒu�����[�֖߂��B
  if (codeWrapEnabled) {
    const pre = document.querySelector("#codeView .codeBodyFrame > pre");
    if (pre) pre.scrollLeft = 0;
  }

  updateCodeWrapToggleButton();
}

function toggleCodeWrap() {
  setCodeWrapEnabled(!codeWrapEnabled);
}

function normalizeTableNames(tableNames) {
  const out = [];
  const seen = new Set();
  (Array.isArray(tableNames) ? tableNames : []).forEach(value => {
    const name = String(value == null ? "" : value).trim();
    // 2026-07-31 �C��2: �e�[�u�����͑啶������������ʂ���B
    // KYF0010 �� Kyf0010 �͕ʕ��Ƃ��Ĉ����A�o�^�����啶�������Ȃ��B
    if (!name || seen.has(name)) return;
    seen.add(name);
    out.push(name);
  });
  return out;
}

function setCurrentTableNames(tableNames) {
  currentTableNames = normalizeTableNames(tableNames);
  currentTableNameSet = new Set(currentTableNames);
}

function mergeCurrentTableNames(tableNames) {
  if (!Array.isArray(tableNames) || tableNames.length === 0) return;
  setCurrentTableNames((currentTableNames || []).concat(tableNames));
}

function getLegacyServerTableHighlightTargets(data) {
  if (!data || typeof data !== "object") return [];
  return normalizeTableNames(data.tableHighlightTargets || data.tableNames || []);
}

function buildTableHighlightCandidateTokens(sourceText, legacyTargets = []) {
  const tokens = [];
  const seen = new Set();
  const add = value => {
    const token = String(value == null ? "" : value).trim();
    if (!/^[A-Z][A-Z0-9_$#]{2,}$/.test(token)) return;
    if (seen.has(token)) return;
    seen.add(token);
    tokens.push(token);
  };

  (Array.isArray(legacyTargets) ? legacyTargets : []).forEach(add);

  const source = String(sourceText || "");
  const pattern = /(^|[^A-Za-z0-9_$#])([A-Z][A-Z0-9_$#]{2,})(?=$|[^A-Za-z0-9_$#])/g;
  let match;
  while ((match = pattern.exec(source)) !== null) {
    add(match[2]);
    if (tokens.length >= 5000) break;
  }
  return tokens;
}

async function loadSourceTableHighlightTargets(sourceText, sourceResponseData = {}, options = {}) {
  const legacyTargets = getLegacyServerTableHighlightTargets(sourceResponseData);
  const candidates = buildTableHighlightCandidateTokens(sourceText, legacyTargets);
  if (candidates.length === 0) return [];

  try {
    const params = {
      mode: "highlightTargets",
      candidates: candidates.join("\n")
    };
    const source = String(sourceText || "");
    if (source.length > 0 && source.length <= 200000) {
      params.source = source;
    }

    const data = await fetchJson(TABLE_HIGHLIGHT_ENDPOINT, params, {
      method: "POST",
      timeoutMs: API_ACCESS_TIMEOUT_MS,
      transport: "fetch"
    });

    if (data && data.ok === true) {
      return normalizeTableNames(data.tableHighlightTargets || data.tableNames || []);
    }
    console.warn("table highlight target validation failed:", data && data.error ? data.error : data);
  } catch (e) {
    console.warn("table highlight target validation failed:", e);
  }

  // �� /source �͊���RPS_TABLE_LIST�ƍ��ς݂̂��߁A����API�����s�����ꍇ�����݊��t�H�[���o�b�N����B
  // /source-by-class �͋�Servlet���啶������L���Ԃ����߁A���s���͌�n�C���C�g�h�~��D�悵�ċ�ɂ���B
  return options.allowLegacyFallback === true ? legacyTargets : [];
}

function areSameTableTargets(left, right) {
  const a = normalizeTableNames(left);
  const b = normalizeTableNames(right);
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i += 1) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

function loadSourceTableHighlightTargetsInBackground(requestId, requestedPath, sourceText, sourceResponseData, sourceEndpoint, initialTargets) {
  window.setTimeout(async () => {
    const tableTargets = await loadSourceTableHighlightTargets(sourceText, sourceResponseData, {
      allowLegacyFallback: sourceEndpoint !== "/source-by-class"
    });
    if (requestId !== sourceOpenRequestSequence || currentView !== "code" || currentCodePath !== requestedPath) return;
    if (activeCodePanel !== "source") return;
    if (areSameTableTargets(initialTargets, tableTargets)) return;
    setCurrentTableNames(tableTargets);
    renderCode(currentSourceText, currentSourceLanguage);
  }, 0);
}

function isJavaSourceForTableHighlight(language, path) {
  const normalized = normalizeHighlightLanguage(language);
  return normalized === "java" || /\.java(?:$|[?#])/i.test(String(path || ""));
}

function extractJavaTableNamesFromSource(sourceText) {
  const source = String(sourceText || "");
  const out = [];
  const seen = new Set();
  const pattern = /\b([A-Z][A-Za-z0-9_$]*?)Table(?:Accessor|Record(?:Value|PKey)?|Record|Data)?\b/g;
  let match;

  while ((match = pattern.exec(source)) !== null) {
    const rawName = String(match[1] || "").replace(/[$_#]+$/g, "");
    if (!rawName || !/[0-9]/.test(rawName)) continue;

    const normalized = rawName.toUpperCase();
    if (normalized.length < 4 || seen.has(normalized)) continue;
    seen.add(normalized);
    out.push(normalized);
  }

  return out;
}

function normalizeHighlightLanguage(language) {
  const rawValue = String(language || "")
    .toLowerCase()
    .trim()
    .replace(/^language-/, "");
  if (!rawValue) return "plaintext";

  const aliasMap = {
    "shell": "bash",
    "shell script": "bash",
    "c++": "cpp",
    "c#": "csharp",
    "html": "xml",
    "xhtml": "xml"
  };
  const value = aliasMap[rawValue] || rawValue;

  // className�֓��錾�ꖼ�����S�ȃg�[�N���ɐ�������B
  // �s���������܂ޒl�́Ahighlight.js�֓n����plaintext�֗��Ƃ��B
  if (!/^[a-z0-9][a-z0-9_+.#-]*$/.test(value)) return "plaintext";

  if (value === "java") return "java";
  if (value === "sql") return "sql";
  return value;
}

// 2026-08-18 fix118: Java�N���X���̎��O�n�C���C�g�́A�\�����t�@�C�����̂��̂� .java �̏ꍇ�����L���ɂ���B
// Servlet��language�l��ߋ��̐���l������� "java" �ł��A.sql / .sh / ���̑��t�@�C����Java�N���X�Ώۂɂ��Ȃ��B
function isJavaFilePathForClassHighlight(path) {
  const cleanPath = String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/");
  const fileName = cleanPath.substring(cleanPath.lastIndexOf("/") + 1);
  return /\.java$/i.test(fileName);
}

function enhanceSourceHighlights(codeBlock, options = {}) {
  if (!codeBlock || !codeBlock.textContent) return;

  const language = normalizeHighlightLanguage(options.language || inferLanguageFromPath(options.path || currentCodePath, "plaintext"));
  const path = String(options.path || currentCodePath || "");
  const isJava = isJavaFilePathForClassHighlight(path);
  const javaSourceClassName = isJava ? getJavaSourceClassName(path) : "";
  const tableSet = currentTableNameSet || new Set();
  // 2026-07-31 �C��2: KYF0010Accessor �̂悤�Ȏ��ʎq�����̃e�[�u�����̓n�C���C�g���Ȃ��B
  // �e�[�u�����́A�O�オ���p�X�y�[�X�̊��S��v������Ώۂɂ���B
  const javaEmbeddedTableNames = [];
  const fullText = codeBlock.textContent || "";

  // �t���[�����[�N���ipackage �� appfw ���܂� .java�j�́A�e�[�u�����EJava�N���X���Ƃ��Ɏ��O�n�C���C�g���Ȃ��B
  const javaCommentRanges = isJava ? findJavaCommentRanges(fullText) : [];
  const javaLiteralRanges = isJava ? findJavaLiteralRanges(fullText) : [];
  const javaImportExclusions = isJava ? buildJavaImportHighlightExclusions(fullText) : new Set();
  const javaPublicClassLineRanges = isJava ? findJavaPublicClassLineRanges(fullText) : [];
  const javaExtendsClauseRanges = isJava
    ? findJavaExtendsClauseRanges(fullText, javaCommentRanges, javaLiteralRanges)
    : [];

  const textNodes = collectHighlightTargetTextNodes(codeBlock, isJava);
  textNodes.forEach(item => replaceTextNodeWithCodeHighlights(item, {
    isJava,
    tableSet,
    fullText,
    javaCommentRanges,
    javaLiteralRanges,
    javaImportExclusions,
    javaPublicClassLineRanges,
    javaExtendsClauseRanges,
    javaSourceClassName,
    javaEmbeddedTableNames
  }));
}

function collectHighlightTargetTextNodes(root, isJava) {
  const result = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let offset = 0;

  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue || "";
    const start = offset;
    offset += text.length;

    if (!text || !CODE_IDENTIFIER_PATTERN.test(text)) {
      CODE_IDENTIFIER_PATTERN.lastIndex = 0;
      continue;
    }
    CODE_IDENTIFIER_PATTERN.lastIndex = 0;

    const parent = node.parentElement;
    if (!parent) continue;
    if (parent.closest && parent.closest(".codeKeywordLink")) continue;

    // .java �ł��e�[�u�����̓R�����g�E������EAccessor���̒��ɏo�邽�߁A
    // �����ł̓R�����g�����O���Ȃ��BJava�N���X�����̏��O�� classifyCodeKeyword �ōs���B

    result.push({ node, text, start });
  }
  return result;
}

function replaceTextNodeWithCodeHighlights(item, context) {
  const node = item.node;
  const text = item.text;
  const start = item.start;
  const fragment = document.createDocumentFragment();
  let lastIndex = 0;
  CODE_IDENTIFIER_PATTERN.lastIndex = 0;
  let match;

  while ((match = CODE_IDENTIFIER_PATTERN.exec(text)) !== null) {
    const keyword = match[0];
    const index = match.index;
    const globalIndex = start + index;
    const embeddedTable = findJavaEmbeddedTableNameMatch(keyword, globalIndex, context);
    const highlight = embeddedTable ? null : classifyCodeKeyword(keyword, globalIndex, context);

    if (index > lastIndex) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex, index)));
    }

    if (embeddedTable) {
      if (embeddedTable.start > 0) {
        fragment.appendChild(document.createTextNode(keyword.slice(0, embeddedTable.start)));
      }

      const tableText = keyword.slice(embeddedTable.start, embeddedTable.end);
      fragment.appendChild(createCodeKeywordLink(tableText, {
        type: "table",
        className: "codeTableKeyword",
        title: embeddedTable.tableName + " �e�[�u����"
      }, embeddedTable.tableName));

      if (embeddedTable.end < keyword.length) {
        fragment.appendChild(document.createTextNode(keyword.slice(embeddedTable.end)));
      }
    } else if (highlight) {
      fragment.appendChild(createCodeKeywordLink(keyword, highlight, keyword));
    } else {
      fragment.appendChild(document.createTextNode(keyword));
    }

    lastIndex = index + keyword.length;
  }

  if (lastIndex < text.length) {
    fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
  }

  if (node.parentNode) node.parentNode.replaceChild(fragment, node);
}

function createCodeKeywordLink(keyword, highlight, datasetKeyword) {
  const link = document.createElement("button");
  link.type = "button";
  link.className = "codeKeywordLink " + highlight.className;
  link.dataset.keyword = datasetKeyword || keyword;
  link.dataset.keywordType = highlight.type;
  link.style.setProperty("--keyword-hit-width", "calc(" + keyword.length + "ch + 1.7em)");
  link.textContent = keyword;
  link.title = highlight.title;
  return link;
}

function buildJavaEmbeddedTableNameCandidates(tableNames) {
  return normalizeTableNames(tableNames)
    .filter(name => /^[A-Z0-9_#$]+$/i.test(name) && /[0-9_]/.test(name) && name.length >= 4)
    .sort((a, b) => b.length - a.length);
}

function findJavaEmbeddedTableNameMatch(keyword, globalIndex, context) {
  // 2026-07-31 �C��2:
  // �e�[�u�����͑啶������������ʂ��A���O�オ���p�X�y�[�X�̊��S��v�̂݃n�C���C�g����B
  // ���̂��� KYF0010Accessor / Kyf0010TableAccessor �̂悤�Ȏ��ʎq�����̕�����v�͑ΏۊO�B
  return null;
}

function isTableKeywordHighlightTarget(keyword, globalIndex, context) {
  const tableSet = context && context.tableSet;
  if (!keyword || !tableSet || !tableSet.has(keyword)) return false;

  const source = String(context && context.fullText || "");
  const start = Number(globalIndex) || 0;
  const end = start + String(keyword).length;
  const before = start > 0 ? source.charAt(start - 1) : "";
  const after = end < source.length ? source.charAt(end) : "";

  // 2026-08-03 �T�C�g�C��5:
  // �e�[�u�����̑啶���������͋�ʂ����܂܁A���莞�����O��̋�؂�L���𔼊p�X�y�[�X�����ɂ���B
  // ��: ="KYF0010" / {KYF0010} / (KYF0010) / �^�u��S�p�X�y�[�X�O��͑ΏہB
  // ��: KYF0010Accessor / KYF0010_TABLE �̂悤�ɉp�����E_�E$�E# �ƘA��������̂͑ΏۊO�B
  return isTableHighlightSeparator(before) && isTableHighlightSeparator(after);
}

function isTableHighlightSeparator(value) {
  if (value == null || value === "") return true;
  const ch = String(value).charAt(0);
  if (/\s/.test(ch) || ch === "�@") return true;

  // �e�[�u�����EJava/SQL���ʎq�̈ꕔ�Ƃ��Ĉ��������́A���p�X�y�[�X�֒u�����Ȃ��B
  // ����ȊO�̔��p�L���E�S�p�L���́A�n�C���C�g�����͔��p�X�y�[�X�����ɂ���B
  return !/[A-Za-z0-9_$#]/.test(ch);
}

function classifyCodeKeyword(keyword, globalIndex, context) {
  const isJava = context.isJava;
  const tableSet = context.tableSet;
  const fullText = context.fullText;
  const javaCommentRanges = context.javaCommentRanges || [];
  const javaLiteralRanges = context.javaLiteralRanges || [];
  const javaImportExclusions = context.javaImportExclusions || new Set();
  const javaPublicClassLineRanges = context.javaPublicClassLineRanges || [];
  const javaExtendsClauseRanges = context.javaExtendsClauseRanges || [];
  const javaSourceClassName = String(context.javaSourceClassName || "");

  // 2026-08-03 �T�C�g�C��5:
  // �e�[�u������ .java / .sql �Ȃǃt�@�C����ʂɂ�����炸�A�ȉ��̓��ꃋ�[���Ńn�C���C�g����B
  // - �啶������������ʂ���
  // - �O��̃^�u�E�S�p�X�y�[�X�E�L���𔼊p�X�y�[�X�����ɂ�����ŁA�Ɨ������e�[�u���������Ώۂɂ���
  if (isTableKeywordHighlightTarget(keyword, globalIndex, context)) {
    return {
      type: "table",
      className: "codeTableKeyword",
      title: keyword + " �e�[�u����"
    };
  }

  // �\������ .java �t�@�C�����g�̃N���X���́A���O�n�C���C�g�̑ΏۊO�ɂ���B
  // ��: KakzJohoSyutkQueryAccessor.java -> KakzJohoSyutkQueryAccessor �͋������Ȃ��B
  if (isJava && javaSourceClassName && keyword === javaSourceClassName) {
    return null;
  }

  if (isJava && (
    isJavaPackageOrImportLineAt(fullText, globalIndex) ||
    isIndexInRanges(globalIndex, javaCommentRanges) ||
    isIndexInRanges(globalIndex, javaLiteralRanges) ||
    isIndexInRanges(globalIndex, javaPublicClassLineRanges) ||
    isIndexInRanges(globalIndex, javaExtendsClauseRanges)
  )) {
    return null;
  }

  // java.sql/java.util �Ȃǂ̕W���p�b�P�[�W�Acom.cm.com.�Aappfw �R���̃N���X�̓n�C���C�g���Ȃ��B
  if (isJava && (
    javaImportExclusions.has(keyword) ||
    isJavaOrFrameworkQualifiedIdentifierAt(fullText, globalIndex)
  )) {
    return null;
  }

  if (isJava && isJavaClassNameCandidate(keyword)) {
    return {
      type: "java-class",
      className: "codeJavaClassKeyword",
      title: keyword + " Java�N���X��"
    };
  }

  return null;
}

function getJavaSourceClassName(path) {
  const cleanPath = String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/");
  const fileName = cleanPath.substring(cleanPath.lastIndexOf("/") + 1);
  return /\.java$/i.test(fileName) ? fileName.slice(0, -5) : "";
}


// 2026-08-03 �T�C�g�C��8:
// Java�N���X���n�C���C�g���N���b�N�����ꍇ�A���ݕ\�����\�[�X��import/package��
// ���݂�Krugle�t���p�X����AServlet /source �ɓn����t���p�X�։�������B
function escapeRegExp(text) {
  return String(text || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function getCleanSourcePath(path) {
  return String(path || "")
    .split(/[?#]/, 1)[0]
    .replace(/\\/g, "/")
    .replace(/\/+/g, "/");
}

function getDirectoryPath(path) {
  const cleanPath = getCleanSourcePath(path).replace(/\/+$/, "");
  const slash = cleanPath.lastIndexOf("/");
  return slash >= 0 ? cleanPath.substring(0, slash) : "";
}

function getJavaPackageRootPrefixFromPath(path) {
  const directory = getDirectoryPath(path);
  const lower = directory.toLowerCase();
  const roots = ["/jp/", "/com/", "/org/", "/net/"];
  let best = -1;

  roots.forEach(root => {
    const index = lower.lastIndexOf(root);
    if (index > best) best = index;
  });

  if (best >= 0) return directory.substring(0, best + 1);
  if (/^(?:jp|com|org|net)\//i.test(directory)) return "";
  return directory ? directory + "/" : "";
}

function getCurrentJavaPackageName() {
  const match = String(currentSourceText || "").match(/^\s*package\s+([A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*)\s*;/m);
  return match ? match[1] : "";
}

function findImportedJavaClassQualifiedName(className) {
  const name = String(className || "").trim();
  if (!name) return "";

  const pattern = new RegExp(
    "^\\s*import\\s+(?:static\\s+)?([A-Za-z_$][A-Za-z0-9_$]*(?:\\.[A-Za-z_$][A-Za-z0-9_$]*)*\\." +
      escapeRegExp(name) +
      ")\\s*;",
    "m"
  );
  const match = String(currentSourceText || "").match(pattern);
  return match ? match[1] : "";
}

function qualifiedJavaNameToFullPath(qualifiedName) {
  const qName = String(qualifiedName || "").trim();
  if (!qName) return "";
  const root = getJavaPackageRootPrefixFromPath(currentCodePath);
  return root + qName.replace(/\./g, "/") + ".java";
}

function buildSiblingJavaClassFullPath(className) {
  const directory = getDirectoryPath(currentCodePath);
  return (directory ? directory + "/" : "") + String(className || "").trim() + ".java";
}

function resolveJavaClassKeywordFullPath(className) {
  const name = String(className || "").trim();
  if (!name) return "";

  const imported = findImportedJavaClassQualifiedName(name);
  if (imported) return qualifiedJavaNameToFullPath(imported);

  const packageName = getCurrentJavaPackageName();
  if (packageName) return qualifiedJavaNameToFullPath(packageName + "." + name);

  return buildSiblingJavaClassFullPath(name);
}

function openJavaClassKeywordSource(className) {
  const name = String(className || "").trim();
  if (!name) return;

  // 2026-08-14 fix80:
  // Java�N���X�����N���b�N�������A�\�����\�[�X��import�Ɋ��S�C����������ΒP�����Ɨ�����Servlet�֓n���B
  // ��: import jp.co.xxx.Kyc0250TableAccessor; �����o�����ꍇ
  //   className=Kyc0250TableAccessor
  //   qualifiedClassName=jp.co.xxx.Kyc0250TableAccessor
  // �Ƃ��AAI_FILE1��������package�����Servlet���ֈꌳ������B
  const importedQualifiedName = findImportedJavaClassQualifiedName(name);
  const fallbackPath = buildSiblingJavaClassFullPath(name);
  const originPath = currentCodePath;
  openCode(fallbackPath, {
    row: {
      fileName: name + ".java",
      path: fallbackPath,
      fullPath: fallbackPath,
      project: extractProjectFromPath(originPath) || "",
      group: extractMigrationGroupFromPath(originPath) || "",
      directoryGroup: getRawDirectoryGroupFromPath(originPath) || "",
      language: "java",
      javaClassName: name,
      javaQualifiedClassName: importedQualifiedName,
      qualifiedClassName: importedQualifiedName,
      originPath,
      originFullPath: originPath,
      originProject: extractProjectFromPath(originPath) || "",
      originGroup: extractMigrationGroupFromPath(originPath) || "",
      originDirectoryGroup: getRawDirectoryGroupFromPath(originPath) || "",
      originPackage: getCurrentJavaPackageName()
    }
  });
}

function isJavaPackageOrImportLineAt(fullText, index) {
  const source = String(fullText || "");
  const lineStart = source.lastIndexOf("\n", Math.max(0, index - 1)) + 1;
  let lineEnd = source.indexOf("\n", index);
  if (lineEnd < 0) lineEnd = source.length;
  const line = source.slice(lineStart, lineEnd);
  return /^\s*(?:package|import\s+(?:static\s+)?)\b/.test(line);
}


function isAppfwJavaSource(sourceText, path) {
  const source = String(sourceText || "");
  const packageMatch = source.match(/^\s*package\s+([^;]+);/m);
  const packageName = packageMatch ? packageMatch[1].trim() : "";
  const pathText = String(path || "");

  return /(^|\.)appfw(\.|$)/i.test(packageName) ||
    /(?:^|[\\/._-])appfw(?:[\\/._-]|$)/i.test(pathText) ||
    /\.appfw\./i.test(pathText);
}

function buildJavaImportHighlightExclusions(sourceText) {
  const excludes = new Set();
  const source = String(sourceText || "");
  const importPattern = /^\s*import\s+(?:static\s+)?([^;]+);/gm;
  let match;

  while ((match = importPattern.exec(source)) !== null) {
    const importPath = String(match[1] || "").trim();
    if (!importPath || !isIgnoredJavaImportPackage(importPath)) continue;

    if (isComTaskWildcardImport(importPath)) {
      excludes.add("Task");
      excludes.add("TaskResult");
    }

    const className = extractImportedClassName(importPath);
    if (className) excludes.add(className);
  }

  return excludes;
}

function isComTaskImportPackage(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.startsWith("com.task.") || value.includes(".com.task.");
}

function isComTaskWildcardImport(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.endsWith(".*") && (value === "com.task.*" || value.endsWith(".com.task.*"));
}

function isIgnoredJavaImportPackage(importPath) {
  const value = String(importPath || "").trim().toLowerCase();
  return value.startsWith("java.") ||
    value.startsWith("javax.") ||
    value.startsWith("jdk.") ||
    value.startsWith("sun.") ||
    value.startsWith("com.sun.") ||
    value.startsWith("org.w3c.") ||
    value.startsWith("org.xml.sax.") ||
    value.includes("com.cm.com.") ||
    isComTaskImportPackage(value) ||
    /(^|\.)[^.]*fw[^.]*(\.|$)/i.test(value);
}

function extractImportedClassName(importPath) {
  const cleaned = String(importPath || "").trim();
  if (!cleaned || cleaned.endsWith(".*")) return "";

  const parts = cleaned.split(".").filter(Boolean);
  for (let i = parts.length - 1; i >= 0; i--) {
    if (/^[A-Z_$]/.test(parts[i])) return parts[i];
  }
  return "";
}

function isJavaOrFrameworkQualifiedIdentifierAt(sourceText, index) {
  const source = String(sourceText || "");
  const prefix = source.slice(Math.max(0, index - 220), index);
  const qualifiedPrefixMatch = prefix.match(/(?:[$A-Za-z_][_$A-Za-z0-9]*\.)+$/);
  if (!qualifiedPrefixMatch) return false;

  const qualifiedPrefix = qualifiedPrefixMatch[0].toLowerCase();
  return qualifiedPrefix.startsWith("java.") ||
    qualifiedPrefix.startsWith("javax.") ||
    qualifiedPrefix.startsWith("jdk.") ||
    qualifiedPrefix.startsWith("sun.") ||
    qualifiedPrefix.startsWith("com.sun.") ||
    qualifiedPrefix.startsWith("org.w3c.") ||
    qualifiedPrefix.startsWith("org.xml.sax.") ||
    qualifiedPrefix.includes("com.cm.com.") ||
    qualifiedPrefix.startsWith("com.task.") ||
    qualifiedPrefix.includes(".com.task.") ||
    /(^|\.)[^.]*fw[^.]*\./i.test(qualifiedPrefix);
}

function findJavaPublicClassLineRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let lineStart = 0;

  while (lineStart <= source.length) {
    let lineEnd = source.indexOf("\n", lineStart);
    if (lineEnd < 0) lineEnd = source.length;

    const line = source.slice(lineStart, lineEnd);
    const classKeywordIndex = line.search(/\bclass\b/);
    if (classKeywordIndex >= 0) {
      const beforeClass = line.slice(0, classKeywordIndex);
      const modifierOnlyPrefix = /^\s*(?:@[A-Za-z0-9_.$]+(?:\([^)]*\))?\s*)*(?:(?:public|protected|private|abstract|final|static|strictfp|sealed|non-sealed)\s+)*$/;

      if (/\bpublic\b/.test(beforeClass) && modifierOnlyPrefix.test(beforeClass)) {
        ranges.push({ start: lineStart, end: lineEnd });
      }
    }

    if (lineEnd >= source.length) break;
    lineStart = lineEnd + 1;
  }

  return ranges;
}

function findJavaExtendsClauseRanges(sourceText, commentRanges = [], literalRanges = []) {
  const source = String(sourceText || "");
  if (!source) return [];

  // �R�����g�E��������� class / extends ��錾�Ƃ��Č�F���Ȃ��悤�A��������ς����ɋ󔒉�����B
  const masked = source.split("");
  const ignoredRanges = (commentRanges || []).concat(literalRanges || [])
    .slice()
    .sort((a, b) => a.start - b.start);

  ignoredRanges.forEach(range => {
    const start = Math.max(0, Number(range.start) || 0);
    const end = Math.min(masked.length, Number(range.end) || 0);
    for (let i = start; i < end; i++) {
      if (masked[i] !== "\n" && masked[i] !== "\r") masked[i] = " ";
    }
  });

  const maskedSource = masked.join("");
  const ranges = [];
  const classPattern = /\bclass\s+[A-Za-z_$][_$A-Za-z0-9]*/g;
  let match;

  while ((match = classPattern.exec(maskedSource)) !== null) {
    const declarationBodyStart = match.index + match[0].length;
    let declarationEnd = maskedSource.length;

    for (let i = declarationBodyStart; i < maskedSource.length; i++) {
      const ch = maskedSource.charAt(i);
      if (ch === "{" || ch === ";") {
        declarationEnd = i;
        break;
      }
    }

    const declarationTail = maskedSource.slice(declarationBodyStart, declarationEnd);
    const extendsMatch = /\bextends\b/.exec(declarationTail);
    if (!extendsMatch) {
      classPattern.lastIndex = Math.max(classPattern.lastIndex, declarationEnd + 1);
      continue;
    }

    const extendsStart = declarationBodyStart + extendsMatch.index + extendsMatch[0].length;
    const afterExtends = maskedSource.slice(extendsStart, declarationEnd);
    const clauseEndMatch = /\b(?:implements|permits)\b/.exec(afterExtends);
    const extendsEnd = clauseEndMatch
      ? extendsStart + clauseEndMatch.index
      : declarationEnd;

    if (extendsEnd > extendsStart) {
      ranges.push({ start: extendsStart, end: extendsEnd });
    }

    classPattern.lastIndex = Math.max(classPattern.lastIndex, declarationEnd + 1);
  }

  return ranges;
}

function findJavaLiteralRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let i = 0;

  while (i < source.length) {
    const ch = source.charAt(i);
    const next = source.charAt(i + 1);

    // �R�����g���̈��p���𕶎���J�n�ƌ�F���Ȃ��悤�A�R�����g�͓ǂݔ�΂��B
    if (ch === "/" && next === "/") {
      const lineEnd = source.indexOf("\n", i + 2);
      i = lineEnd < 0 ? source.length : lineEnd + 1;
      continue;
    }
    if (ch === "/" && next === "*") {
      const commentEnd = source.indexOf("*/", i + 2);
      i = commentEnd < 0 ? source.length : commentEnd + 2;
      continue;
    }

    if (ch !== "\"" && ch !== "'") {
      i++;
      continue;
    }

    const quote = ch;
    const start = i;
    let escaped = false;
    i++;

    while (i < source.length) {
      const current = source.charAt(i);
      if (escaped) {
        escaped = false;
      } else if (current === "\\") {
        escaped = true;
      } else if (current === quote) {
        i++;
        break;
      }
      i++;
    }

    ranges.push({ start, end: i });
  }

  return ranges;
}

function findJavaCommentRanges(sourceText) {
  const source = String(sourceText || "");
  const ranges = [];
  let quote = "";
  let escaped = false;

  for (let i = 0; i < source.length; i++) {
    const ch = source.charAt(i);
    const next = source.charAt(i + 1);

    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === quote) {
        quote = "";
      }
      continue;
    }

    if (ch === "\"" || ch === "'") {
      quote = ch;
      continue;
    }

    if (ch === "/" && next === "/") {
      const start = i;
      let end = source.indexOf("\n", i + 2);
      if (end < 0) end = source.length;
      ranges.push({ start, end });
      i = end;
      continue;
    }

    if (ch === "/" && next === "*") {
      const start = i;
      let end = source.indexOf("*/", i + 2);
      end = end < 0 ? source.length : end + 2;
      ranges.push({ start, end });
      i = end - 1;
    }
  }
  return ranges;
}

function isIndexInRanges(index, ranges) {
  for (let i = 0; i < ranges.length; i++) {
    if (index >= ranges[i].start && index < ranges[i].end) return true;
    if (index < ranges[i].start) return false;
  }
  return false;
}

function isJavaClassNameCandidate(keyword) {
  if (!keyword) return false;
  if (JAVA_STANDARD_CLASS_EXCLUDES.has(keyword)) return false;
  if (JAVA_RESERVED_WORD_EXCLUDES.has(keyword)) return false;
  if (!/^[A-Z][A-Za-z0-9_$]*$/.test(keyword)) return false;
  if (/Exception/i.test(keyword)) return false;

  // IAppContext �̂悤�� I �n�܂�̃C���^�[�t�F�[�X���͏��O����B
  if (/^I[A-Za-z0-9_$]*$/.test(keyword)) return false;

  // Command / Task / Context �̂悤�ɑ啶�����擪1���������̒P��^�N���X���͏��O����B
  const upperCaseCount = (keyword.match(/[A-Z]/g) || []).length;
  if (upperCaseCount <= 1) return false;

  // SELECT_FOR_UPDATE �� DB_UPDJI1 �Ȃǂ̒萔�E�J�������́A�N���X���Ƃ��Ă͏��O����B
  if (/^[A-Z0-9_$]+$/.test(keyword)) return false;

  return true;
}

const CODE_IDENTIFIER_PATTERN = /[$#A-Za-z_][_$#A-Za-z0-9]*/g;


function getTableInfoTabTemplate() {
  return document.querySelector(".codeTableInfoTab:not(.codeTableInfoDynamicTab)");
}

function getTableInfoTabContainer() {
  const template = getTableInfoTabTemplate();
  return template ? template.parentElement : document.querySelector(".codeModeTabs");
}

function getTableInfoPanelId(tabId) {
  return tabId ? `table:${tabId}` : "table";
}

function isTableInfoPanel(panelId) {
  const value = String(panelId || "");
  return value === "table" || value.indexOf("table:") === 0;
}

function getTableInfoTabIdFromPanel(panelId) {
  const value = String(panelId || "");
  if (value.indexOf("table:") === 0) return value.slice(6);
  return activeTableInfoTabId || "";
}

function createDefaultTableInfoState(values = {}) {
  return Object.assign({
    id: "",
    status: "idle",
    tableName: "",
    candidates: [],
    selected: null,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey: 0
  }, values || {});
}

function createTableInfoTabId(tableName) {
  tableInfoTabSequence += 1;
  const safeName = String(tableName || "table").replace(/[^A-Za-z0-9_]+/g, "_").replace(/^_+|_+$/g, "") || "table";
  return `${safeName}_${tableInfoTabSequence}`;
}

function getTableInfoStateById(tabId) {
  const id = String(tabId || "");
  return tableInfoStates.find(state => state && state.id === id) || null;
}

function getActiveTableInfoState() {
  return getTableInfoStateById(activeTableInfoTabId) || tableInfoStates[0] || tableInfoState || createDefaultTableInfoState();
}

const TABLE_INFO_TAB_LABEL_MAX_CHARS = 12;

function shortenTableInfoTabLabel(label) {
  const text = String(label || "").trim();
  if (!text) return "�e�[�u���I��";
  const chars = Array.from(text);
  return chars.length > TABLE_INFO_TAB_LABEL_MAX_CHARS
    ? `${chars.slice(0, TABLE_INFO_TAB_LABEL_MAX_CHARS).join("")}...`
    : text;
}

function getTableInfoTabFullLabel(state) {
  const current = state || {};
  if (current.status === "candidates") return "�e�[�u���I��";
  const selected = current.selected || {};
  const detailName = current.status === "detail" && selected.name ? String(selected.name).trim() : "";
  return detailName || String(current.tableName || "�e�[�u���I��").trim() || "�e�[�u���I��";
}

function getTableInfoTabLabel(state) {
  return shortenTableInfoTabLabel(getTableInfoTabFullLabel(state));
}

function upsertTableInfoState(nextState) {
  const state = createDefaultTableInfoState(nextState || {});
  if (!state.id) state.id = createTableInfoTabId(state.tableName);
  const index = tableInfoStates.findIndex(item => item && item.id === state.id);
  if (index >= 0) {
    tableInfoStates[index] = state;
  } else {
    tableInfoStates.push(state);
  }
  if (!activeTableInfoTabId) activeTableInfoTabId = state.id;
  tableInfoState = getActiveTableInfoState();
  return state;
}

function updateTableInfoTabsFromState() {
  const container = getTableInfoTabContainer();
  const template = getTableInfoTabTemplate();
  if (!container) return;

  if (template) {
    template.hidden = true;
    template.setAttribute("aria-hidden", "true");
  }

  container.querySelectorAll(".codeTableInfoDynamicTab").forEach(tab => tab.remove());

  tableInfoStates.forEach(state => {
    const button = document.createElement("button");
    button.className = "codeModeTab codeTableInfoTab codeTableInfoDynamicTab";
    button.type = "button";
    button.dataset.codePanel = getTableInfoPanelId(state.id);
    button.dataset.tableInfoTabId = state.id;
    const fullLabel = getTableInfoTabFullLabel(state);
    const shortLabel = getTableInfoTabLabel(state);
    button.textContent = shortLabel;
    button.title = fullLabel;
    button.dataset.fullLabel = fullLabel;
    button.setAttribute("aria-hidden", "false");
    button.setAttribute("aria-label", `${fullLabel} �̃e�[�u���I��`);
    button.classList.toggle("isActive", activeCodePanel === button.dataset.codePanel);
    container.appendChild(button);
  });
}

function getTableInfoTab() {
  if (activeTableInfoTabId) {
    return document.querySelector(`.codeTableInfoDynamicTab[data-table-info-tab-id="${cssEscapeValue(activeTableInfoTabId)}"]`);
  }
  return getTableInfoTabTemplate();
}

function setTableInfoTabVisible(visible, label) {
  if (!visible) {
    tableInfoStates = [];
    activeTableInfoTabId = "";
    if (isTableInfoPanel(activeCodePanel)) activeCodePanel = "source";
  } else if (label && activeTableInfoTabId) {
    const state = getTableInfoStateById(activeTableInfoTabId);
    if (state && !state.tableName) state.tableName = String(label || "");
  }
  updateTableInfoTabsFromState();
}

function updateTableInfoTabFromState() {
  updateTableInfoTabsFromState();
}

function resetTableInfoState() {
  // ���݂̐����^�u�ɑ�����e�[�u���^�u���ʎq������ޔ����Ă���A��ʏ�̒�`�I�u�W�F�N�g��j������B
  persistTableInfoRefsForActiveRecentTab();
  tableInfoRequestSequence++;
  tableInfoStates = [];
  activeTableInfoTabId = "";
  tableInfoState = createDefaultTableInfoState();
  setTableInfoTabVisible(false, "�e�[�u���I��");
  renderTableInfoPanel();
}


// 2026-08-21 fix157: �e�[�u����`�̗���EHTML��SessionStorage�֕ۑ����Ȃ��B
// �ۑ�����̂́u�ǂ̐����^�u�ŊJ�������v+�utableName / DBTYPE / SCHEMA�v�̂݁B
// �����^�u���ēx�J���ƁA�y�ʂȃe�[�u���^�u�����������A���ۂɂ��̃^�u���N���b�N��������
// /table-info �֍Ė₢���킹���čŐV�̃e�[�u����`���擾����B
function readTableInfoTabSessionState() {
  try {
    const text = readSessionStorage(TABLE_INFO_TAB_SESSION_STORAGE_KEY);
    if (!text) return { version: TABLE_INFO_TAB_SESSION_VERSION, owners: {} };
    const parsed = JSON.parse(text);
    if (!parsed || parsed.version !== TABLE_INFO_TAB_SESSION_VERSION || !parsed.owners || typeof parsed.owners !== "object") {
      return { version: TABLE_INFO_TAB_SESSION_VERSION, owners: {} };
    }
    return { version: TABLE_INFO_TAB_SESSION_VERSION, owners: parsed.owners };
  } catch (e) {
    return { version: TABLE_INFO_TAB_SESSION_VERSION, owners: {} };
  }
}

function writeTableInfoTabSessionState(state) {
  const source = state && typeof state === "object" ? state : {};
  const owners = source.owners && typeof source.owners === "object" ? source.owners : {};
  writeSessionStorage(TABLE_INFO_TAB_SESSION_STORAGE_KEY, JSON.stringify({
    version: TABLE_INFO_TAB_SESSION_VERSION,
    owners
  }));
}

function getActiveRecentTabPersistenceContext() {
  const tabs = readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, RECENT_TAB_STORE_LIMIT);
  if (!tabs.length) return null;

  let index = findRecentTabInstanceIndex(tabs, activeRecentTabKey);
  if (index < 0 && currentCodePath) {
    index = tabs.findIndex(item => item.path === currentCodePath);
  }
  if (index < 0) return null;

  const item = tabs[index];
  return {
    ownerKey: recentTabKey(item),
    recentTabId: createRecentTabInstanceId(item, index)
  };
}

function buildPersistableTableInfoRef(state) {
  const current = state && typeof state === "object" ? state : {};
  const selected = normalizeTableCandidate(current.tableMeta || current.selected || {});
  const tableName = String(current.tableName || selected.name || "").trim();
  if (!tableName) return null;
  return {
    tableName,
    dbtype: String(selected.dbtype || current.restoreDbtype || "").trim(),
    schema: String(selected.schema || current.restoreSchema || "").trim()
  };
}

function persistTableInfoRefsForActiveRecentTab() {
  const context = getActiveRecentTabPersistenceContext();
  if (!context || !context.ownerKey) return;

  const refs = tableInfoStates
    .map(buildPersistableTableInfoRef)
    .filter(Boolean)
    .slice(0, TABLE_INFO_TAB_SESSION_PER_OWNER_LIMIT);

  const sessionState = readTableInfoTabSessionState();
  const owners = Object.assign({}, sessionState.owners || {});
  if (refs.length) {
    owners[context.ownerKey] = {
      recentTabId: context.recentTabId,
      tabs: refs
    };
  } else {
    delete owners[context.ownerKey];
  }

  // fileStorage�Ɏc���Ă��鐔���^�u������ێ����āASessionStorage���������ɔ�債�Ȃ��悤�ɂ���B
  const validOwnerKeys = new Set(readRecentTabs()
    .map(normalizeRecentTab)
    .filter(item => item && item.path && item.openedAt)
    .slice(0, TABLE_INFO_TAB_SESSION_OWNER_LIMIT)
    .map(recentTabKey));
  Object.keys(owners).forEach(ownerKey => {
    if (!validOwnerKeys.has(ownerKey)) delete owners[ownerKey];
  });

  writeTableInfoTabSessionState({ owners });
}

function restoreTableInfoTabsForActiveRecentTab() {
  const context = getActiveRecentTabPersistenceContext();
  if (!context || !context.ownerKey) return 0;

  const sessionState = readTableInfoTabSessionState();
  const owner = sessionState.owners && sessionState.owners[context.ownerKey];
  const refs = owner && Array.isArray(owner.tabs)
    ? owner.tabs.slice(0, TABLE_INFO_TAB_SESSION_PER_OWNER_LIMIT)
    : [];
  if (!refs.length) return 0;

  tableInfoRequestSequence++;
  tableInfoStates = refs
    .map(ref => {
      const tableName = String(ref && ref.tableName || "").trim();
      if (!tableName) return null;
      const dbtype = String(ref && ref.dbtype || "").trim();
      const schema = String(ref && ref.schema || "").trim();
      const tabId = createTableInfoTabId(tableName);
      return createDefaultTableInfoState({
        id: tabId,
        status: "restored",
        tableName,
        candidates: [],
        selected: normalizeTableCandidate({ name: tableName, dbtype, schema }),
        tableMeta: null,
        columns: [],
        unique: false,
        error: "",
        requestKey: 0,
        needsReload: true,
        restoreDbtype: dbtype,
        restoreSchema: schema
      });
    })
    .filter(Boolean);

  activeTableInfoTabId = "";
  tableInfoState = createDefaultTableInfoState();
  activeCodePanel = "source";
  updateTableInfoTabsFromState();
  return tableInfoStates.length;
}

async function reloadPersistedTableInformation(tabId) {
  const id = String(tabId || "");
  const state = getTableInfoStateById(id);
  if (!state || state.needsReload !== true) return false;

  const tableName = String(state.tableName || "").trim();
  if (!tableName) return false;
  const dbtype = String(state.restoreDbtype || (state.selected && state.selected.dbtype) || "").trim();
  const schema = String(state.restoreSchema || (state.selected && state.selected.schema) || "").trim();
  const requestKey = ++tableInfoRequestSequence;
  const candidate = normalizeTableCandidate({ name: tableName, dbtype, schema });

  activeTableInfoTabId = id;
  activeCodePanel = getTableInfoPanelId(id);
  setTableInfoState({
    status: "loadingDetail",
    tableName,
    candidates: [],
    selected: candidate,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey,
    needsReload: false,
    restoreDbtype: dbtype,
    restoreSchema: schema
  }, id, false);
  renderCode();

  const params = { tableName };
  if (dbtype) params.dbtype = dbtype;
  if (schema) params.schema = schema;

  try {
    const data = await fetchJson(TABLE_INFO_ENDPOINT, params, {
      method: "GET",
      timeoutMs: API_ACCESS_TIMEOUT_MS
    });
    const latest = getTableInfoStateById(id);
    if (!latest || latest.requestKey !== requestKey) return true;
    const apiError = tableApiError(data, `${tableName} �̃e�[�u����`��DB����擾�ł��܂���ł����B`);
    if (apiError) throw apiError;
    applyTableInfoResponse(data, tableName, [], id);
  } catch (error) {
    const latest = getTableInfoStateById(id);
    if (!latest || latest.requestKey !== requestKey) return true;
    setTableInfoState({
      status: "error",
      tableName,
      candidates: [],
      selected: candidate,
      tableMeta: null,
      columns: [],
      unique: false,
      error: String(error && error.message ? error.message : error),
      requestKey,
      needsReload: true,
      restoreDbtype: dbtype,
      restoreSchema: schema
    }, id);
  }
  return true;
}

function normalizeTableCandidate(value) {
  const source = value && typeof value === "object" ? value : {};
  return {
    id: source.id == null ? "" : String(source.id).trim(),
    name: String(source.name || source.tableName || "").trim(),
    name2: String(source.name2 || source.displayName || source.logicalName || "").trim(),
    dbtype: String(source.dbtype || source.dbType || "").trim(),
    schema: String(source.schema || "").trim(),
    version: String(source.version || source.ver || "").trim(),
    displayName: String(source.displayName || source.name2 || source.logicalName || "").trim()
  };
}

function getTableCandidateDbtypePriority(dbtype) {
  const value = String(dbtype || "").trim().toUpperCase();
  if (value === "KYKDB") return 0;
  if (value === "EZDB") return 1;
  return 2;
}

function getTableCandidateSchemaPriority(candidate) {
  const dbtype = String(candidate && candidate.dbtype || "").trim().toUpperCase();
  const schema = String(candidate && candidate.schema || "").trim().toUpperCase();
  if (dbtype === "KYKDB" && schema === "KYKOWNER") return 0;
  if (dbtype === "EZDB" && schema === "EZOWNER") return 0;
  return 1;
}

function compareTextAscending(a, b) {
  return String(a || "").localeCompare(String(b || ""), "ja", {
    numeric: true,
    sensitivity: "base"
  });
}

function compareTableCandidatesForDisplay(a, b) {
  const dbPriorityDiff = getTableCandidateDbtypePriority(a && a.dbtype) - getTableCandidateDbtypePriority(b && b.dbtype);
  if (dbPriorityDiff !== 0) return dbPriorityDiff;

  const aDbtype = String(a && a.dbtype || "").trim();
  const bDbtype = String(b && b.dbtype || "").trim();
  const dbtypeDiff = compareTextAscending(aDbtype, bDbtype);
  if (dbtypeDiff !== 0) return dbtypeDiff;

  const schemaPriorityDiff = getTableCandidateSchemaPriority(a) - getTableCandidateSchemaPriority(b);
  if (schemaPriorityDiff !== 0) return schemaPriorityDiff;

  return compareTextAscending(a && a.schema, b && b.schema)
    || compareTextAscending(a && a.version, b && b.version)
    || compareTextAscending(a && a.name, b && b.name)
    || compareTextAscending(a && a.name2, b && b.name2)
    || compareTextAscending(a && a.id, b && b.id);
}

function sortTableCandidatesForDisplay(candidates) {
  return (Array.isArray(candidates) ? candidates : [])
    .slice()
    .sort(compareTableCandidatesForDisplay);
}

function normalizeTableMeta(value, fallbackCandidate) {
  const source = value && typeof value === "object" ? value : {};
  const candidate = normalizeTableCandidate(fallbackCandidate || source);
  return {
    id: source.id == null ? candidate.id : String(source.id).trim(),
    name: String(source.name || source.tableName || candidate.name || "").trim(),
    name2: String(source.name2 || source.displayName || source.logicalName || candidate.name2 || "").trim(),
    dbtype: String(source.dbtype || source.dbType || candidate.dbtype || "").trim(),
    schema: String(source.schema || candidate.schema || "").trim(),
    dbAlias: String(source.dbAlias || source.dbName || source.dbIdentifier || source.dbtype || candidate.dbtype || "").trim(),
    version: String(source.version || source.ver || candidate.version || "").trim(),
    displayName: String(source.displayName || source.name2 || source.logicalName || candidate.displayName || candidate.name2 || "").trim()
  };
}

function buildTableDisplayName(tableName, logicalName) {
  const name = String(tableName || "").trim();
  const displayName = String(logicalName || "").trim();
  if (!name) return displayName || "�e�[�u�����";
  if (!displayName || displayName === name || displayName === "�e�[�u����`���") return name;
  return `${name}�i${displayName}�j`;
}

function buildTableInfoTitleText(tableName, logicalName, version, dbtype, schema) {
  const safeDbtype = String(dbtype || "-").trim() || "-";
  const safeSchema = String(schema || "-").trim() || "-";
  const safeVersion = String(version || "-").trim() || "-";
  // 2026-08-12 fix48: �e�[�u���ڍ׃^�C�g���̕\�����E�\�L���w��t�H�[�}�b�g�ɍ��킹��B
  return `${buildTableDisplayName(tableName, logicalName)}�@�@�@DBTYPE�@�F�@${safeDbtype}�@�@�@�X�L�[�}�@�F�@${safeSchema}�@�@�@Version�@�F�@${safeVersion}`;
}

function getTableInfoTitle() {
  const state = getActiveTableInfoState();
  const selected = state.selected || {};
  const meta = state.tableMeta || {};
  if (state.status === "detail" && state.unique === true) {
    const tableName = meta.name || selected.name || state.tableName || "";
    const displayName = meta.displayName || meta.name2 || selected.displayName || selected.name2 || "";
    const version = meta.version || selected.version || "-";
    const dbtype = meta.dbtype || selected.dbtype || "-";
    const schema = meta.schema || selected.schema || "-";
    return buildTableInfoTitleText(tableName, displayName, version, dbtype, schema);
  }
  return getTableInfoTabLabel(state);
}

function setTableInfoState(nextState, tabId = activeTableInfoTabId, renderAfterUpdate = true) {
  const id = String(tabId || activeTableInfoTabId || (nextState && nextState.id) || createTableInfoTabId(nextState && nextState.tableName));
  const current = getTableInfoStateById(id) || createDefaultTableInfoState({ id });
  const merged = createDefaultTableInfoState(Object.assign({}, current, nextState || {}, { id }));
  upsertTableInfoState(merged);
  if (activeTableInfoTabId === id) tableInfoState = merged;
  updateTableInfoTabFromState();
  persistTableInfoRefsForActiveRecentTab();
  if (renderAfterUpdate && isTableInfoPanel(activeCodePanel) && getTableInfoTabIdFromPanel(activeCodePanel) === id) renderCode();
  return merged;
}

function tableApiError(data, fallback) {
  if (data && data.ok === false) return new Error(String(data.error || fallback || "�e�[�u�������擾�ł��܂���ł����B"));
  return null;
}

function applyTableInfoResponse(data, fallbackName, fallbackCandidates, tabId = activeTableInfoTabId) {
  const mode = String(data && data.mode || "").trim();
  const candidates = sortTableCandidatesForDisplay((Array.isArray(data && data.candidates) ? data.candidates : (fallbackCandidates || []))
    .map(normalizeTableCandidate)
    .filter(item => item.name));

  if (mode === "detail" || data && data.unique === true && data.table) {
    const selected = normalizeTableCandidate(data.table || {});
    const tableMeta = normalizeTableMeta(data.table || {}, selected);
    setTableInfoState({
      status: "detail",
      tableName: selected.name || fallbackName,
      candidates,
      selected,
      tableMeta,
      columns: Array.isArray(data.columns) ? data.columns : [],
      unique: true,
      error: ""
    }, tabId);
    return;
  }

  if (mode === "candidates" || candidates.length > 1) {
    setTableInfoState({
      status: "candidates",
      tableName: String(data && data.tableName || fallbackName || "").trim(),
      candidates,
      selected: null,
      tableMeta: null,
      columns: [],
      unique: false,
      error: ""
    }, tabId);
    return;
  }

  setTableInfoState({
    status: "empty",
    tableName: String(data && data.tableName || fallbackName || "").trim(),
    candidates,
    selected: null,
    tableMeta: null,
    columns: [],
    unique: false,
    error: ""
  }, tabId);
}

async function openTableInformation(tableName) {
  const name = String(tableName || "").trim();
  if (!name) return;

  const tabId = createTableInfoTabId(name);
  const requestKey = ++tableInfoRequestSequence;
  activeTableInfoTabId = tabId;
  activeCodePanel = getTableInfoPanelId(tabId);
  setTableInfoState({
    id: tabId,
    status: "loadingCandidates",
    tableName: name,
    candidates: [],
    selected: null,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey
  }, tabId, false);
  updateTableInfoTabsFromState();
  renderCode();

  try {
    const data = await fetchJson(TABLE_INFO_ENDPOINT, { tableName: name }, {
      method: "GET",
      timeoutMs: API_ACCESS_TIMEOUT_MS
    });
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    const apiError = tableApiError(data, `${name} �̃e�[�u������DB����擾�ł��܂���ł����B`);
    if (apiError) throw apiError;
    applyTableInfoResponse(data, name, [], tabId);
  } catch (error) {
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    setTableInfoState({
      status: "error",
      tableName: name,
      candidates: [],
      selected: null,
      tableMeta: null,
      columns: [],
      unique: false,
      error: String(error && error.message ? error.message : error),
      requestKey
    }, tabId);
  }
}

async function loadTableInformationDetail(candidateValue) {
  const candidate = normalizeTableCandidate(candidateValue);
  if (!candidate.name) return;

  const tabId = activeTableInfoTabId;
  const currentState = getTableInfoStateById(tabId) || getActiveTableInfoState();
  const currentCandidates = Array.isArray(currentState.candidates) ? currentState.candidates.slice() : [];
  const requestKey = ++tableInfoRequestSequence;
  activeCodePanel = getTableInfoPanelId(tabId);
  setTableInfoState({
    status: "loadingDetail",
    tableName: candidate.name,
    candidates: currentCandidates,
    selected: candidate,
    tableMeta: null,
    columns: [],
    unique: false,
    error: "",
    requestKey
  }, tabId, false);
  updateTableInfoTabsFromState();
  renderCode();

  try {
    const data = await fetchJson(TABLE_INFO_ENDPOINT, {
      tableListId: candidate.id,
      tableName: candidate.name,
      dbtype: candidate.dbtype,
      schema: candidate.schema,
      version: candidate.version
    }, {
      method: "GET",
      timeoutMs: API_ACCESS_TIMEOUT_MS
    });
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    const apiError = tableApiError(data, `${candidate.name} �̃e�[�u����`��DB����擾�ł��܂���ł����B`);
    if (apiError) throw apiError;
    applyTableInfoResponse(data, candidate.name, currentCandidates, tabId);
  } catch (error) {
    const latest = getTableInfoStateById(tabId);
    if (!latest || latest.requestKey !== requestKey) return;
    setTableInfoState({
      status: "error",
      tableName: candidate.name,
      candidates: currentCandidates,
      selected: candidate,
      tableMeta: null,
      columns: [],
      unique: false,
      error: String(error && error.message ? error.message : error),
      requestKey
    }, tabId);
  }
}

function tableCell(value) {
  return escapeHtml(value == null ? "" : String(value));
}

function renderTableInfoPanel() {
  const panel = $("tableInfoPanel");
  const status = $("tableInfoStatus");
  const title = $("codeTitle");
  const content = $("tableInfoContent");
  if (!panel || !content) return;

  const setTableInfoStatusText = (text, options = {}) => {
    const value = String(text || "");
    if (status) {
      status.textContent = value;
      return;
    }
    if (title && options.useTitle !== false) {
      title.textContent = value;
    }
  };

  const state = getActiveTableInfoState();
  tableInfoState = state;
  updateCodeContextFixedLabel(currentCodePath);
  content.innerHTML = "";

  if (state.status === "loadingCandidates") {
    setTableInfoStatusText(`${state.tableName} �̃e�[�u������DB����擾���Ă��܂��c`);
    return;
  }
  if (state.status === "loadingDetail") {
    const selected = state.selected || {};
    setTableInfoStatusText(`${selected.name || state.tableName} �̍��ڒ�`��DB����擾���Ă��܂��c`);
    return;
  }
  if (state.status === "empty") {
    setTableInfoStatusText(`${state.tableName} �Ɉ�v����RPS_TABLE_LIST.NAME������܂���B`);
    return;
  }
  if (state.status === "error") {
    setTableInfoStatusText("�e�[�u�����̎擾�Ɏ��s���܂����B");
    content.innerHTML = `<div class="tableInfoError">${escapeHtml(state.error || "�s���ȃG���[")}</div>`;
    return;
  }
  if (state.status === "candidates") {
    setTableInfoStatusText(`${state.tableName} �͌��f�[�^������������܂��B�ȉ���DBTYPE����уX�L�[�}����A1�s��I�����Ă��������B`);
    content.innerHTML = `
      <div class="tableInfoTableWrap tableCandidateTableWrap">
        <table class="tableInfoTable tableCandidateTable">
          <thead><tr><th>NO</th><th>DBTYPE</th><th>�X�L�[�}</th><th>�o�[�W����</th><th>�e�[�u����</th><th>���{��</th><th class="tableCandidateActionHeader">�I��</th></tr></thead>
          <tbody>${state.candidates.map((item, index) => `
            <tr class="tableCandidateRow" data-table-candidate-index="${index}" tabindex="0" role="button" aria-label="${tableCell(item.name)} ${tableCell(item.dbtype)} ${tableCell(item.schema)} ${tableCell(item.version)} ��I��">
              <td>${index + 1}</td>
              <td>${tableCell(item.dbtype)}</td>
              <td>${tableCell(item.schema)}</td>
              <td>${tableCell(item.version)}</td>
              <td>${tableCell(item.name)}</td>
              <td>${tableCell(item.name2 || item.displayName)}</td>
              <td class="tableCandidateActionCell"><button class="tableCandidateSelectBtn" type="button" aria-label="${tableCell(item.name)} ${tableCell(item.dbtype)} ${tableCell(item.schema)} ${tableCell(item.version)} ��I��">�I��</button></td>
            </tr>`).join("")}</tbody>
        </table>
      </div>`;
    return;
  }
  if (state.status === "detail") {
    const selected = state.selected || {};
    const meta = state.tableMeta || {};
    const rows = Array.isArray(state.columns) ? state.columns : [];
    const tableName = meta.name || selected.name || state.tableName || "-";
    const dbtype = meta.dbtype || selected.dbtype || "-";
    const schema = meta.schema || selected.schema || "-";
    const version = meta.version || selected.version || "-";
    const displayName = meta.displayName || meta.name2 || selected.displayName || selected.name2 || "";
    content.innerHTML = `
      <div class="tableInfoTableWrap tableDefinitionTableWrap">
        <table class="tableInfoTable tableDefinitionTable">
          <thead>
            <tr>
              <th>No.</th><th>���ږ�</th><th>�L�[</th><th>Par</th><th>�f�[�^�^</th><th>�f�[�^��</th>
              <th>NULL����</th><th>���{�ꖼ��</th><th>���ڐ���</th><th>�O���Q��</th>
              <th>�ȗ����l</th><th>CHECK����</th>
            </tr>
          </thead>
          <tbody>${rows.map(row => `
            <tr>
              <td>${tableCell(row.no)}</td>
              <td>${tableCell(row.name)}</td>
              <td>${tableCell(row.pkkey)}</td>
              <td>${tableCell(row.part)}</td>
              <td>${tableCell(row.kata)}</td>
              <td>${tableCell(row.columnSize)}</td>
              <td>${tableCell(row.nullConst)}</td>
              <td>${tableCell(row.name2)}</td>
              <td>${tableCell(row.description)}</td>
              <td>${tableCell(row.reference)}</td>
              <td>${tableCell(row.defaultValue)}</td>
              <td>${tableCell(row.checkConst)}</td>
            </tr>`).join("") || `<tr><td colspan="12">RPS_TABLE_DATA�ɍ��ڂ�����܂���B</td></tr>`}</tbody>
        </table>
      </div>`;
    return;
  }

  setTableInfoStatusText("�\�[�X�R�[�h���ŉ����\�����ꂽ�e�[�u�������N���b�N���Ă��������B");
}

function selectTableCandidateFromElement(element) {
  const index = Number(element && element.dataset ? element.dataset.tableCandidateIndex : -1);
  const state = getActiveTableInfoState();
  const candidate = Array.isArray(state.candidates) ? state.candidates[index] : null;
  if (candidate) loadTableInformationDetail(candidate);
}

function handleTableCandidateKeydown(event) {
  const row = event && event.target && event.target.closest ? event.target.closest("[data-table-candidate-index]") : null;
  if (!row) return;
  if (event.key !== "Enter" && event.key !== " ") return;
  event.preventDefault();
  selectTableCandidateFromElement(row);
}

document.addEventListener("keydown", handleTableCandidateKeydown, true);

const JAVA_RESERVED_WORD_EXCLUDES = new Set([
  "Abstract", "Assert", "Boolean", "Break", "Byte", "Case", "Catch", "Char", "Class", "Const",
  "Continue", "Default", "Do", "Double", "Else", "Enum", "Extends", "Final", "Finally", "Float",
  "For", "Goto", "If", "Implements", "Import", "Instanceof", "Int", "Interface", "Long", "Native",
  "New", "Package", "Private", "Protected", "Public", "Return", "Short", "Static", "Strictfp", "Super",
  "Switch", "Synchronized", "This", "Throw", "Throws", "Transient", "Try", "Void", "Volatile", "While"
]);

const JAVA_STANDARD_CLASS_EXCLUDES = new Set([
  "Appendable", "AutoCloseable", "Boolean", "Byte", "Character", "CharSequence", "Class", "ClassLoader",
  "Cloneable", "Comparable", "Compiler", "Double", "Enum", "Exception", "Float", "Integer", "Iterable",
  "Long", "Math", "Number", "Object", "Package", "Process", "ProcessBuilder", "Readable", "Runtime",
  "RuntimeException", "SecurityManager", "Short", "StackTraceElement", "StrictMath", "String", "StringBuffer",
  "StringBuilder", "System", "Thread", "ThreadGroup", "ThreadLocal", "Throwable", "Void",
  "BigDecimal", "BigInteger", "Date", "Calendar", "GregorianCalendar", "Locale", "TimeZone", "Optional",
  "List", "ArrayList", "LinkedList", "Map", "HashMap", "LinkedHashMap", "TreeMap", "Set", "HashSet",
  "LinkedHashSet", "TreeSet", "Collection", "Collections", "Arrays", "Iterator", "Enumeration", "Objects",
  "Comparator", "Queue", "Deque", "ArrayDeque", "Properties", "Random", "UUID", "Timer", "TimerTask",
  "File", "InputStream", "OutputStream", "Reader", "Writer", "BufferedReader", "BufferedWriter",
  "InputStreamReader", "OutputStreamWriter", "IOException", "FileInputStream", "FileOutputStream", "PrintWriter",
  "PrintStream", "Serializable", "Externalizable",
  "Charset", "StandardCharsets", "ByteBuffer", "Path", "Paths", "Files", "URL", "URI", "URLConnection",
  "HttpURLConnection", "URLEncoder", "URLDecoder",
  "Connection", "DriverManager", "PreparedStatement", "CallableStatement", "Statement", "ResultSet", "SQLException",
  "SQLWarning", "Savepoint", "DatabaseMetaData", "ResultSetMetaData", "ParameterMetaData", "Types",
  "Timestamp", "Time", "Blob", "Clob", "NClob", "SQLXML", "Array", "Ref", "RowId", "Struct"
]);

document.addEventListener("click", event => {
  const candidateRow = event.target.closest ? event.target.closest("[data-table-candidate-index]") : null;
  if (candidateRow) {
    event.preventDefault();
    selectTableCandidateFromElement(candidateRow);
    return;
  }

  const keywordButton = event.target.closest ? event.target.closest(".codeKeywordLink") : null;
  if (!keywordButton) return;

  const keyword = keywordButton.dataset.keyword || keywordButton.textContent || "";
  if (!keyword) return;

  if (keywordButton.dataset.keywordType === "table") {
    event.preventDefault();
    openTableInformation(keyword);
    return;
  }

  if (keywordButton.dataset.keywordType === "java-class") {
    event.preventDefault();
    openJavaClassKeywordSource(keyword);
    return;
  }
});

document.addEventListener("keydown", event => {
  if (event.key !== "Enter" && event.key !== " ") return;
  const candidateRow = event.target.closest ? event.target.closest("[data-table-candidate-index]") : null;
  if (!candidateRow) return;
  event.preventDefault();
  selectTableCandidateFromElement(candidateRow);
});


function setCodeFontSize(nextSize) {
  const next = Number(nextSize);
  codeFontSize = Math.min(CODE_FONT_MAX, Math.max(CODE_FONT_MIN, Number.isFinite(next) ? next : 12));

  const codeView = $("codeView");
  if (codeView) {
    codeView.style.setProperty("--code-font-size", `${codeFontSize}px`);
  }

  const codeBlock = $("codeBlock");
  if (codeBlock) {
    codeBlock.style.setProperty("font-size", `${codeFontSize}px`, "important");
  }
}

function getActionFeedbackTextTarget(button) {
  if (!button) return null;
  return button.querySelector(".sideActionText") || button;
}

function getActionFeedbackButtons(action) {
  const ids = action === "download"
    ? ["downloadBtn"]
    : ["copyBtn"];
  return ids.map(id => $(id)).filter(Boolean);
}

function getActionFeedbackSourceButton(source) {
  if (!source) return null;
  const target = source.currentTarget || source.target || source;
  return target && target.closest ? target.closest("button") : target;
}

function isActionFeedbackSource(source, action) {
  const button = getActionFeedbackSourceButton(source);
  if (!button) return false;
  const validIds = action === "download"
    ? ["downloadBtn"]
    : ["copyBtn"];
  return validIds.includes(button.id);
}

function showSynchronizedActionButtonFeedback(action, feedbackText, fallbackText, stateClass) {
  const buttons = getActionFeedbackButtons(action);
  if (!buttons.length) return;

  if (!showSynchronizedActionButtonFeedback.buttonTimers) {
    showSynchronizedActionButtonFeedback.buttonTimers = new WeakMap();
  }

  buttons.forEach(button => {
    const textTarget = getActionFeedbackTextTarget(button);
    if (!textTarget) return;

    const originalKey = action === "download" ? "originalDownloadText" : "originalCopyText";
    const originalText = button.dataset[originalKey] || textTarget.textContent || fallbackText;
    button.dataset[originalKey] = originalText;
    textTarget.textContent = feedbackText;
    button.classList.add(stateClass);

    window.clearTimeout(showSynchronizedActionButtonFeedback.buttonTimers.get(button));
    showSynchronizedActionButtonFeedback.buttonTimers.set(button, window.setTimeout(() => {
      textTarget.textContent = button.dataset[originalKey] || fallbackText;
      button.classList.remove(stateClass);
    }, 1400));
  });
}

function showToastFeedback(message = "�R�s�[���܂���") {
  let toast = $("copyToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "copyToast";
    toast.className = "copyToast";
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.classList.add("isVisible");
  window.clearTimeout(showToastFeedback.timer);
  showToastFeedback.timer = window.setTimeout(() => {
    toast.classList.remove("isVisible");
  }, 1400);
}

function showCopyFeedback(message = "�R�s�[���܂���", source) {
  showToastFeedback(message);
  if (message === "�R�s�[���܂���" && isActionFeedbackSource(source, "copy")) {
    showSynchronizedActionButtonFeedback("copy", "�R�s�[��", "Copy", "isCopied");
  }
}

function showDownloadFeedback(message = "�_�E�����[�h�J�n", source) {
  showToastFeedback(message);
  // 2026-08-17 fix101: Copy�́u�R�s�[�ς݁v�Ɠ������ADownload�N���b�N�����
  // �u�_�E�����[�h�J�n�v���{�^�����֕\������B�G���[�ʒm���͐������\���ɂ��Ȃ��B
  if (message === "�_�E�����[�h�J�n" && isActionFeedbackSource(source, "download")) {
    showSynchronizedActionButtonFeedback("download", "�_�E�����[�h�J�n", "Download", "isDownloaded");
  }
}

function fallbackCopyText(text) {
  const area = document.createElement("textarea");
  area.value = text;
  area.setAttribute("readonly", "readonly");
  area.style.position = "fixed";
  area.style.left = "-9999px";
  area.style.top = "0";
  document.body.appendChild(area);
  area.focus();
  area.select();

  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch (e) {
    ok = false;
  }

  document.body.removeChild(area);
  return ok;
}


function getSafeDownloadFileName(pathOrName, fallbackName = "krugle.txt") {
  const fallback = String(fallbackName || "krugle.txt").trim() || "krugle.txt";
  const raw = String(pathOrName || "").trim();
  const lastSegment = raw
    .replace(/\\/g, "/")
    .split("/")
    .filter(Boolean)
    .pop() || fallback;
  const withoutQuery = lastSegment.split(/[?#]/)[0] || fallback;
  let decoded = withoutQuery;
  try {
    decoded = decodeURIComponent(withoutQuery);
  } catch (e) {
    decoded = withoutQuery;
  }
  const safe = String(decoded || fallback)
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_")
    .replace(/\s+/g, " ")
    .replace(/[. ]+$/g, "")
    .trim();
  return safe || fallback;
}

// 2026-08-12 fix50:
// Download��Servlet /download�֓������A���݉�ʂ̕�������u���E�U���ŕۑ�����B
// �Ή��u���E�U�ł� File System Access API(showSaveFilePicker) �ŕۑ����I�����A
// ��Ή��EHTTP����E�L�����Z���ȊO�̎��s���͏]���� a[download] �փt�H�[���o�b�N����B
function getDownloadFileExtension(filename) {
  const match = String(filename || "").match(/(\.[A-Za-z0-9_+-]+)$/);
  return match ? match[1].toLowerCase() : ".txt";
}

function getDownloadMimeType(filename, fallbackMimeType = "text/plain;charset=utf-8") {
  const ext = getDownloadFileExtension(filename);
  switch (ext) {
    case ".tsv": return "text/tab-separated-values;charset=utf-8";
    case ".csv": return "text/csv;charset=utf-8";
    case ".html": return "text/html;charset=utf-8";
    case ".js": return "text/javascript;charset=utf-8";
    case ".css": return "text/css;charset=utf-8";
    case ".json": return "application/json;charset=utf-8";
    case ".md": return "text/markdown;charset=utf-8";
    case ".xml": return "application/xml;charset=utf-8";
    case ".java": return "text/x-java-source;charset=utf-8";
    case ".sql": return "application/sql;charset=utf-8";
    case ".sh":
    case ".bash": return "text/x-shellscript;charset=utf-8";
    default: return fallbackMimeType;
  }
}

function getFileSystemAccessMimeType(mimeType) {
  return String(mimeType || "text/plain").split(";")[0] || "text/plain";
}

function buildTextDownloadBlob(text, mimeType, includeBom = true) {
  const body = String(text ?? "");
  const parts = includeBom ? [new Uint8Array([0xef, 0xbb, 0xbf]), body] : [body];
  return new Blob(parts, { type: mimeType || "text/plain;charset=utf-8" });
}

async function saveBlobWithBrowserFileApi(blob, filename, mimeType) {
  const safeName = getSafeDownloadFileName(filename, "krugle.txt");
  const ext = getDownloadFileExtension(safeName);
  const fsMimeType = getFileSystemAccessMimeType(mimeType);

  if (typeof window.showSaveFilePicker === "function") {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: safeName,
        types: [{
          description: "Text file",
          accept: { [fsMimeType]: [ext] }
        }]
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return { ok: true, method: "file-system-access" };
    } catch (e) {
      if (e && e.name === "AbortError") return { ok: false, aborted: true };
      console.warn("showSaveFilePicker failed; fallback to anchor download", e);
    }
  }

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.download = safeName;
  link.href = url;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  window.setTimeout(() => {
    URL.revokeObjectURL(url);
    link.remove();
  }, 1000);
  return { ok: true, method: "anchor-download" };
}

function normalizeTableInfoExportCell(value) {
  return String(value == null ? "" : value)
    .replace(/\r\n?/g, "\n")
    .replace(/\n+/g, " ")
    .replace(/\t+/g, " ")
    .trim();
}

function getTableInfoExportMatrix() {
  const table = document.querySelector("#tableInfoPanel .tableInfoTable");
  if (!table) return [];

  const title = $("codeTitle");
  const titleText = normalizeTableInfoExportCell(title ? title.textContent : getTableInfoTitle());
  const tableRows = Array.from(table.querySelectorAll("tr")).map(row =>
    Array.from(row.children).map(cell => normalizeTableInfoExportCell(cell.innerText || cell.textContent || ""))
  );

  return titleText ? [[titleText], []].concat(tableRows) : tableRows;
}

function buildTableInfoCopyText() {
  return getTableInfoExportMatrix()
    .map(row => row.join("\t"))
    .join("\n");
}

function buildCsvExportLine(values) {
  return (Array.isArray(values) ? values : [])
    .map(value => `"${String(value == null ? "" : value).replace(/"/g, '""')}"`)
    .join(",");
}

function buildTableInfoDownloadText() {
  return getTableInfoExportMatrix()
    .map(buildCsvExportLine)
    .join("\r\n");
}

function getTableInfoDownloadFileName() {
  const state = getActiveTableInfoState();
  const selected = state.selected || {};
  const meta = state.tableMeta || {};
  const tableName = meta.name || selected.name || state.tableName || "table_info";
  return `${getSafeDownloadFileName(tableName, "table_info")}.csv`;
}

function buildSearchDownloadFileName(params) {
  const keyword = getSafeDownloadFileName((params && (params.rawKeyword || params.keyword)) || "search", "search");
  return `${keyword}_search_results.tsv`;
}

function getCurrentDownloadPayload() {
  if (currentView === "search") {
    const params = lastSearchParams || buildSearchParams(lastSearchMode || "normal");
    return {
      filename: buildSearchDownloadFileName(params),
      text: buildSearchResultCopyText(getSearchResultExportRows()),
      mimeType: "text/tab-separated-values;charset=utf-8",
      includeBom: true
    };
  }

  if (currentView === "code") {
    const codeView = $("codeView");
    if (codeView && codeView.classList.contains("isTableInfoMode")) {
      return {
        filename: getTableInfoDownloadFileName(),
        text: buildTableInfoDownloadText(),
        mimeType: "text/csv;charset=utf-8",
        includeBom: true
      };
    }

    if (activeCodePanel === "summary" && currentAiSampleData.summaryAvailable) {
      const filename = getSafeDownloadFileName(
        currentAiSampleData.summaryFileName || `SUMMARY_${getPathBaseName(currentCodePath)}.md`,
        "SUMMARY_code.md"
      );
      return {
        filename,
        text: currentAiSampleData.summaryMarkdown || "",
        mimeType: "text/markdown;charset=utf-8",
        includeBom: false
      };
    }

    if (activeCodePanel === "ai" && currentAiSampleData.commentAvailable) {
      const filename = getSafeDownloadFileName(
        currentAiSampleData.commentFileName || `COMMENT_${getPathBaseName(currentCodePath)}`,
        "COMMENT_code.txt"
      );
      return {
        filename,
        text: currentAiSampleData.commentSource || "",
        mimeType: getDownloadMimeType(filename, "text/plain;charset=utf-8"),
        includeBom: false
      };
    }

    const codeBlock = $("codeBlock");
    const filename = getSafeDownloadFileName(
      currentCodeMeta && (currentCodeMeta.fileName || currentCodeMeta.name) || currentCodePath,
      "code.txt"
    );
    return {
      filename,
      text: codeBlock ? codeBlock.textContent : currentSourceText || "",
      mimeType: getDownloadMimeType(filename, "text/plain;charset=utf-8"),
      includeBom: false
    };
  }

  return {
    filename: "history.tsv",
    text: buildHomeHistoryExportText(),
    mimeType: "text/tab-separated-values;charset=utf-8",
    includeBom: true
  };
}


// 2026-08-19 fix136:
// �������ʃ^�u��Download������Servlet /download�֌���������POST���A���������܂Ń��[�_����\������B
// fix134��Download��p10��Servlet�^�C���A�E�g�͂��̂܂ܗ��p����B
// hidden iframe/form�ł̓��X�|���X�������m���ɔ���ł��Ȃ����߁A���̌o�H����AbortController�Ȃ���fetch��CSV���Ō�܂Ŏ�M����B
// ��M���͉�ʑS�̂𑀍�s�\�ɂ��A����/���s���ɕK����������B
function blockInteractionDuringSearchDownload(event) {
  if (!searchResultDownloadInProgress) return;
  if (!event) return;
  event.preventDefault();
  event.stopPropagation();
  if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
}

function showSearchDownloadModal() {
  if (searchResultDownloadInProgress) return false;
  const modal = $("searchDownloadModal");
  const dialog = $("searchDownloadDialog");
  if (!modal) return false;

  searchResultDownloadInProgress = true;
  searchDownloadPreviousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  document.body.classList.add("isSearchDownloadBusy");
  modal.hidden = false;
  modal.setAttribute("aria-hidden", "false");

  // BackSpace / Enter / �V���[�g�J�b�g���ɂ��^�u�J�ڂ�Download���͗}�~����B
  document.addEventListener("keydown", blockInteractionDuringSearchDownload, true);
  document.addEventListener("keyup", blockInteractionDuringSearchDownload, true);

  if (dialog && typeof dialog.focus === "function") {
    try {
      dialog.focus({ preventScroll: true });
    } catch (e) {
      dialog.focus();
    }
  }
  return true;
}

function hideSearchDownloadModal() {
  if (!searchResultDownloadInProgress) return;
  const modal = $("searchDownloadModal");
  searchResultDownloadInProgress = false;
  document.removeEventListener("keydown", blockInteractionDuringSearchDownload, true);
  document.removeEventListener("keyup", blockInteractionDuringSearchDownload, true);
  document.body.classList.remove("isSearchDownloadBusy");
  if (modal) {
    modal.hidden = true;
    modal.setAttribute("aria-hidden", "true");
  }

  const focusTarget = searchDownloadPreviousFocus;
  searchDownloadPreviousFocus = null;
  if (focusTarget && document.contains(focusTarget) && typeof focusTarget.focus === "function") {
    try {
      focusTarget.focus({ preventScroll: true });
    } catch (e) {
      focusTarget.focus();
    }
  }
}

function getDownloadFilenameFromContentDisposition(headerValue, fallbackName = "krugle.csv") {
  const value = String(headerValue || "");
  const utf8Match = value.match(/filename\*\s*=\s*UTF-8''([^;]+)/i);
  if (utf8Match && utf8Match[1]) {
    try {
      return getSafeDownloadFileName(decodeURIComponent(utf8Match[1].trim().replace(/^"|"$/g, "")), fallbackName);
    } catch (e) {
      // filename= fallback�֐i�ށB
    }
  }
  const normalMatch = value.match(/filename\s*=\s*(?:"([^"]+)"|([^;\s]+))/i);
  const filename = normalMatch ? (normalMatch[1] || normalMatch[2] || "") : "";
  return getSafeDownloadFileName(filename, fallbackName);
}

function saveSearchDownloadBlobDirectly(blob, filename) {
  const safeName = getSafeDownloadFileName(filename, "krugle.csv");
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = safeName;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  window.setTimeout(() => {
    URL.revokeObjectURL(url);
    link.remove();
  }, 1000);
}

async function downloadFullSearchResultsViaServlet(event) {
  const params = lastSearchParams || buildSearchParams(lastSearchMode || "normal");
  if (!params || !hasExecutableSearchKeyword(params.rawKeyword)) {
    showDownloadFeedback("�_�E�����[�h�Ώۂ�����܂���", event);
    return false;
  }

  if (!showSearchDownloadModal()) return false;
  showDownloadFeedback("�_�E�����[�h�J�n", event);

  try {
    const resolved = await resolveApiBaseOnce();
    const downloadUrl = apiPathForBase(resolved.base, "/download");
    const fields = {
      path_output_format: "PATH",
      keyword: params.keyword,
      project: params.project,
      language: params.languageForApi,
      findin: params.findin,
      clone: params.clone
    };
    const body = Object.keys(fields)
      .map(name => `${encodeURIComponent(name)}=${encodeURIComponent(String(fields[name] == null ? "" : fields[name]))}`)
      .join("&");

    // Download��pServlet�͍ő�10���҂��߁A�����ł͈Ӑ}�I��AbortController/20�b�^�C���A�E�g���g��Ȃ��B
    const response = await fetch(downloadUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "Accept": "text/csv,*/*;q=0.8"
      },
      body,
      cache: "no-store",
      credentials: "omit"
    });

    if (!response.ok) {
      let detail = "";
      try {
        detail = String(await response.text()).trim().slice(0, 500);
      } catch (e) {
        detail = "";
      }
      throw new Error(`Download HTTP ${response.status}${detail ? `: ${detail}` : ""}`);
    }

    const blob = await response.blob();
    if (!blob || blob.size <= 0) throw new Error("Download response is empty");
    const filename = getDownloadFilenameFromContentDisposition(response.headers.get("Content-Disposition"), "krugle.csv");
    saveSearchDownloadBlobDirectly(blob, filename);
    return true;
  } finally {
    hideSearchDownloadModal();
  }
}


// 2026-08-21 fix155: �\�[�X�R�[�h�p�X����� codeContentHeader �S�̂�Ώۂɂ���B
// source�\�����̓w�b�_�[�̈�S�̂� hover �� #codeTitle ���������A�w�b�_�[�� single-click �Ŋ��S�p�X���R�s�[����B
// �� #codeTitle double-click �R�s�[�͔p�~�B�R�s�[���͕\���ȗ��Ɉˑ����� currentCodePath �̊��S�p�X���g�p����B
function getCurrentSourcePathForCopy() {
  if (currentView !== "code" || activeCodePanel !== "source") return "";
  return String(currentCodePath || "").trim();
}

function syncCodePathCopyUi() {
  const title = $("codeTitle");
  const header = $("codeContentHeader");
  if (!title) return;

  const visible = Boolean(getCurrentSourcePathForCopy());
  title.classList.toggle("isPathCopyTarget", visible);
  if (header) header.classList.toggle("isPathCopyTarget", visible);

  if (visible) {
    title.setAttribute("title", "�N���b�N�Ńp�X�S�̂��R�s�[");
    if (header) header.setAttribute("title", "�N���b�N�Ńp�X�S�̂��R�s�[");
  } else {
    title.removeAttribute("title");
    if (header) header.removeAttribute("title");
    title.classList.remove("isPathCopyFlashing");
  }
}

function waitForPathCopyFlash(ms = 260) {
  return new Promise(resolve => window.setTimeout(resolve, ms));
}

async function copyCurrentSourcePath(event, options = {}) {
  if (event && typeof event.preventDefault === "function") event.preventDefault();
  if (event && typeof event.stopPropagation === "function") event.stopPropagation();

  const path = getCurrentSourcePathForCopy();
  if (!path) {
    showCopyFeedback("�R�s�[�Ώۂ̃p�X������܂���", event);
    return false;
  }

  const title = $("codeTitle");
  const flash = options.flashPath === true && title;
  if (flash) {
    // �_�u���N���b�N�̃u���E�U�W���u�P��I���v���c�����A�p�X�����F�̃R�s�[���o��������B
    try {
      const selection = window.getSelection ? window.getSelection() : null;
      if (selection) selection.removeAllRanges();
    } catch (e) {
      // Selection API �����p�ł��Ȃ����ł��R�s�[�����͌p������B
    }
    title.classList.add("isPathCopyFlashing");
  }

  let copied = false;
  try {
    const copyPromise = (async () => {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(path);
        return true;
      }
      if (!fallbackCopyText(path)) throw new Error("fallback copy failed");
      return true;
    })();

    // �N���b�N����ɗ΁{�����֕ς��A�R�s�[�����������ł����F�ł���ŒZ�\�����Ԃ��m�ۂ���B
    // �R�s�[�����ƍŒZ�\�����Ԃ̗����������������_�� finally �ɓ���A���̃X�^�C���֖߂��B
    if (flash) {
      await Promise.all([copyPromise, waitForPathCopyFlash()]);
    } else {
      await copyPromise;
    }
    copied = true;
  } catch (e) {
    try {
      copied = fallbackCopyText(path);
      if (copied && flash) await waitForPathCopyFlash();
    } catch (fallbackError) {
      copied = false;
    }
  } finally {
    if (flash) title.classList.remove("isPathCopyFlashing");
  }

  showCopyFeedback(copied ? "�p�X���R�s�[���܂���" : "�p�X���R�s�[�ł��܂���ł���", event);
  return copied;
}

async function downloadCurrent(event) {
  if (event && typeof event.preventDefault === "function") event.preventDefault();
  if (event && typeof event.stopPropagation === "function") event.stopPropagation();

  try {
    // 2026-08-19 fix134: �������ʃ^�u��Download�̂�Servlet�S���_�E�����[�h���g�p����B
    if (currentView === "search") {
      await downloadFullSearchResultsViaServlet(event);
      return;
    }

    const payload = getCurrentDownloadPayload();
    const text = String(payload && payload.text != null ? payload.text : "");
    if (!text) {
      showDownloadFeedback("�_�E�����[�h�Ώۂ�����܂���", event);
      return;
    }

    const filename = getSafeDownloadFileName(payload.filename, "krugle.txt");
    const mimeType = payload.mimeType || getDownloadMimeType(filename, "text/plain;charset=utf-8");
    const blob = buildTextDownloadBlob(text, mimeType, payload.includeBom !== false);
    // 2026-08-17 fix101: �t�@�C���ۑ��������J�n���钼�O�ɁACopy�Ɠ����`���ő����t�B�[�h�o�b�N����B
    showDownloadFeedback("�_�E�����[�h�J�n", event);
    const result = await saveBlobWithBrowserFileApi(blob, filename, mimeType);
    if (result && result.aborted) return;
  } catch (e) {
    console.error(e);
    showDownloadFeedback("�_�E�����[�h�ł��܂���ł���", event);
  }
}

async function copyCurrent(event) {
  const visibleView = document.querySelector(".viewBlock.isVisible");
  const text = currentView === "code"
    ? (isTableInfoPanel(activeCodePanel)
      ? buildTableInfoCopyText()
      : (activeCodePanel === "summary" && currentAiSampleData.summaryAvailable
        ? currentAiSampleData.summaryMarkdown
        : (activeCodePanel === "ai" && currentAiSampleData.commentAvailable
          ? currentAiSampleData.commentSource
          : ($("codeBlock") ? $("codeBlock").textContent : currentSourceText || ""))))
    : (currentView === "search"
      ? buildSearchResultCopyText(getSearchResultExportRows())
      : (currentView === "home"
        ? buildHomeHistoryExportText()
        : (visibleView ? visibleView.innerText : "")));

  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
    } else if (!fallbackCopyText(text)) {
      throw new Error("fallback copy failed");
    }
    showCopyFeedback("�R�s�[���܂���", event);
  } catch (e) {
    if (fallbackCopyText(text)) {
      showCopyFeedback("�R�s�[���܂���", event);
    } else {
      showCopyFeedback("�R�s�[�ł��܂���ł���", event);
    }
  }
}

function csv(value) {
  return `"${String(value).replaceAll('"', '""')}"`; }

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

// === 2026-08-21 fix89: AI���p�T���v���\�� ===
// [8] �u����R�[�h�v�u�v������v�͏�ɕ\������B���Ή�����disabled + �u���Ή��v�o�b�W�B
// [9] AI�T���v���̑Ώ۔���̓t���p�X�ł͂Ȃ��A
//      �u�ڍs�O���[�v + �f�B���N�g���O���[�v + �t�@�C�����v��3���ڈ�v�ōs���B
//      �r����jar/zip/package���̃p�X�͔�������ɂ��Ȃ��B
// [4] �v������́u�����\��30�^�u�v������Ώۂɂ���B
// source path�̊��S��v�ŏ����^�u�����ʂ��ASUMMARY�{�̗̂L����Servlet��WAR�����\�[�X���m�F����B
// MeigaraIchiran.java��2�̈قȂ鏉���p�X�����邽�߁A30�p�X���ׂĂ�ێ�����B
function normalizeAiSummaryInitialPath(value) {
  return String(value || "")
    .trim()
    .replace(/\\/g, "/")
    .replace(/\/+/g, "/")
    .replace(/^\/+/, "")
    .replace(/\/$/, "")
    .toLowerCase();
}

const AI_SUMMARY_INITIAL_SOURCE_PATH_SET = new Set(
  (Array.isArray(INITIAL_FILE_STORAGE_VALUES) ? INITIAL_FILE_STORAGE_VALUES : [])
    .map(value => {
      const text = String(value || "").trim();
      const commaIndex = text.lastIndexOf(",");
      const path = commaIndex > 0 ? text.substring(0, commaIndex) : text;
      return normalizeAiSummaryInitialPath(path);
    })
    .filter(Boolean)
);

function isAiSummaryInitialSourcePath(path) {
  return AI_SUMMARY_INITIAL_SOURCE_PATH_SET.has(normalizeAiSummaryInitialPath(getHistoryEntryPath(path || "") || path));
}

// [5] ����R�[�h���u�����\��30�^�u�v������Ώۂɂ���B
// COMMENT_* �̗L����Servlet��WAR�����\�[�X���m�F���A�ʏ�t�@�C���ł͔񊈐��̂܂܂ɂ���B
function isAiCommentInitialSourcePath(path) {
  return AI_SUMMARY_INITIAL_SOURCE_PATH_SET.has(normalizeAiSummaryInitialPath(getHistoryEntryPath(path || "") || path));
}

const AI_SAMPLE_SOURCE_KEYS = new Set([
  // nikkoEZ / ez.web.onlineSrc
  "nikkoez|ez.web.onlinesrc|meigaraichiran.java",
  "nikkoez|ez.web.onlinesrc|kbsnkokmeisaiapplication.java",
  "nikkoez|ez.web.onlinesrc|kbsnkokmeisaiapplicationcommand.java",
  "nikkoez|ez.web.onlinesrc|kbsnkokmeisaibbapplication.java",
  "nikkoez|ez.web.onlinesrc|kbsnkokmeisaibbapplicationcommand.java",
  "nikkoez|ez.web.onlinesrc|kbsnkokmeisaipoapplication.java",
  "nikkoez|ez.web.onlinesrc|kbsnkokmeisaibbpoapplication.java",
  // nkCCIS / kyak.online
  "nkccis|kyak.online|kyakjkykjnhjnsyutktask.java",
  "nkccis|kyak.online|kjoymdsyutktask.java",
  "nkccis|kyak.online|kjoymdupdtask.java",
  "nkccis|kyak.online|kjeddhojnjohotask.java",
  "nkccis|kyak.online|kjeddkabunusiyakuintorktask.java",
  "nkccis|kyak.online|saknryuhogkjo1k2kmaintask.java",
  "nkccis|kyak.online|kjuhkdeltask.java",
  "nkccis|kyak.online|kjuhkjohosearchtask.java",
  "nkccis|kyak.online|kysjohokjnsyutktask.java",
  "nkccis|kyak.online|saknryuhogkjoinqtask.java",
  "nkccis|kyak.online|saknryuhogkjotask.java",
  // nkCCIS / kyak.batch
  "nkccis|kyak.batch|ccis_kyk5470_upd.sql",
  "nkccis|kyak.batch|ccis_kyf9800_ikan.sql",
  "nkccis|kyak.batch|ccis_kyf6510_ins.sql",
  "nkccis|kyak.batch|ccis_kyf4410_spool.sql",
  "nkccis|kyak.batch|ccis_kyf3030upd_from_cc.sql",
  "nkccis|kyak.batch|ccisd0607_kyk5300_02_spool.sql",
  "nkccis|kyak.batch|ccis_kyf3030spool_to_cc.sql",
  "nkccis|kyak.batch|ccis_kyf4400_bzn_spool.sql",
  "nkccis|kyak.batch|ccisaltd218.sql",
  "nkccis|kyak.batch|ccis_kyf4301_pl_sel.sql",
  "nkccis|kyak.batch|ccisaltd078.sql"
]);

function normalizeAiSampleGroup(value) {
  return normalizeMigrationGroupName(value).trim().toLowerCase();
}

function normalizeAiSampleDirectoryGroup(value) {
  return cleanDirectoryGroupName(value).trim().toLowerCase();
}

function normalizeAiSampleFileName(value) {
  return getPathBaseName(value).trim().toLowerCase();
}

function getPathBaseName(path) {
  const clean = String(path || "").split(/[?#]/, 1)[0].replace(/\\/g, "/").replace(/\/+$/, "");
  const slash = clean.lastIndexOf("/");
  return slash >= 0 ? clean.substring(slash + 1) : clean;
}

function getAiSampleSourceIdentity(path, meta = currentCodeMeta) {
  const normalizedPath = getHistoryEntryPath(path || currentCodePath || "");
  const sourceMeta = meta && typeof meta === "object" ? meta : {};
  const metaPath = getHistoryEntryPath(sourceMeta.path || sourceMeta.fullPath || "");
  // currentCodeMeta�͕ʃt�@�C���̒l����p���Ȃ��B�p�X���ݒ��row���^�����͌��݃t�@�C���p�Ƃ��ė��p����B
  const canUseMeta = !metaPath || !normalizedPath || metaPath === normalizedPath;

  const fileName = String((canUseMeta && (sourceMeta.fileName || sourceMeta.file || sourceMeta.name)) || getPathBaseName(normalizedPath) || "").trim();
  const group = normalizeMigrationGroupName(
    (canUseMeta && (sourceMeta.group || sourceMeta.migrationGroup || sourceMeta.ikogroup || sourceMeta.ikoGroup)) ||
    extractMigrationGroupFromPath(normalizedPath) || ""
  );
  const directoryGroup = cleanDirectoryGroupName(
    (canUseMeta && (sourceMeta.directoryGroup || sourceMeta.dirGroup || sourceMeta.directory)) ||
    getRawDirectoryGroupFromPath(normalizedPath) || ""
  );

  const key = [
    normalizeAiSampleGroup(group),
    normalizeAiSampleDirectoryGroup(directoryGroup),
    normalizeAiSampleFileName(fileName)
  ].join("|");

  return { path: normalizedPath, fileName, group, directoryGroup, key };
}

function isAiSampleSource(path, meta = currentCodeMeta) {
  const identity = getAiSampleSourceIdentity(path, meta);
  return Boolean(identity.fileName && identity.group && identity.directoryGroup && AI_SAMPLE_SOURCE_KEYS.has(identity.key));
}

function createEmptyAiSampleData() {
  return {
    available: false,
    summaryAvailable: false,
    commentAvailable: false,
    sourceFileName: "",
    summaryFileName: "",
    commentFileName: "",
    summaryMarkdown: "",
    commentSource: "",
    commentLanguage: ""
  };
}

function setOneAiSampleTabAvailable(button, enabled) {
  if (!button) return;
  // 2026-08-25 [1]: �@�\��~���́A�Ăяo������true��n���Ă���΂Ɋ��������Ȃ��B
  const effectiveEnabled = AI_SAMPLE_TABS_ENABLED && enabled === true;
  // [8] �^�u���̂͏�ɕ\������B���Ή��������O���[��disabled��Ԃɂ���B
  button.hidden = false;
  button.disabled = !effectiveEnabled;
  button.setAttribute("aria-disabled", effectiveEnabled ? "false" : "true");
  button.setAttribute("aria-hidden", "false");
  if (effectiveEnabled) {
    button.classList.remove("codeModeTabPending");
    button.removeAttribute("data-badge");
    button.removeAttribute("title");
  } else {
    button.classList.add("codeModeTabPending");
    button.dataset.badge = "���Ή�";
    button.title = "���Ή�";
  }
}

// COMMENT��SUMMARY�͓Ɨ����肷��B
// COMMENT_* �����鎞�����u����R�[�h�v�ASUMMARY_*.md �����鎞�����u�v������v������������B
function setAiSampleTabsAvailable(commentAvailable, summaryAvailable) {
  // 2026-08-25 [1]: ���݂͑S�t�@�C���ŉ���R�[�h�^�v������𖢑Ή��ɌŒ�B
  const commentEnabled = AI_SAMPLE_TABS_ENABLED && commentAvailable === true;
  const summaryEnabled = AI_SAMPLE_TABS_ENABLED && summaryAvailable === true;
  setOneAiSampleTabAvailable($("codeAiModeTab"), commentEnabled);
  setOneAiSampleTabAvailable($("codeSummaryModeTab"), summaryEnabled);

  if (activeCodePanel === "ai" && !commentEnabled) {
    activeCodePanel = "source";
  } else if (activeCodePanel === "summary" && !summaryEnabled) {
    activeCodePanel = "source";
  }
}

function resetAiSampleData() {
  aiSampleLoadSequence += 1;
  currentAiSampleData = createEmptyAiSampleData();
  setAiSampleTabsAvailable(false, false);
  const notice = $("aiSampleNotice");
  if (notice) notice.hidden = true;
  const panel = $("markdownSummaryPanel");
  if (panel) panel.hidden = true;
  const content = $("markdownSummaryContent");
  if (content) content.innerHTML = "";
}

function applyAiSampleData(data, path, identity = getAiSampleSourceIdentity(path)) {
  // 2026-08-25 [1]: ��~���͊���COMMENT/SUMMARY�f�[�^���Ԃ��Ă��Ă��K�p���Ȃ��B
  if (!AI_SAMPLE_TABS_ENABLED) {
    currentAiSampleData = createEmptyAiSampleData();
    setAiSampleTabsAvailable(false, false);
    return false;
  }
  if (!identity || !AI_SAMPLE_SOURCE_KEYS.has(identity.key) || !data) {
    currentAiSampleData = createEmptyAiSampleData();
    setAiSampleTabsAvailable(false, false);
    return false;
  }

  const summaryMarkdown = String(data.summaryMarkdown || data.summary || "");
  const commentSource = String(data.commentSource || data.comment || "");
  // [4] �v������͏���30�^�u�̎��p�X�Ɍ���B
  // �����t�@�C�����E�����ڍs/�f�B���N�g���O���[�v�ł��A�ʃp�X����J�����ʏ�t�@�C���ł͊��������Ȃ��B
  const summaryEligible = isAiSummaryInitialSourcePath(identity.path || path);
  const commentEligible = isAiCommentInitialSourcePath(identity.path || path);
  const summaryAvailable = summaryEligible && (data.summaryAvailable === true || Boolean(summaryMarkdown));
  const commentAvailable = commentEligible && (data.commentAvailable === true || Boolean(commentSource));
  if (!summaryAvailable && !commentAvailable) {
    currentAiSampleData = createEmptyAiSampleData();
    setAiSampleTabsAvailable(false, false);
    return false;
  }

  currentAiSampleData = {
    available: summaryAvailable || commentAvailable,
    summaryAvailable,
    commentAvailable,
    sourceFileName: String(data.sourceFileName || identity.fileName || getPathBaseName(path)),
    summaryFileName: String(data.summaryFileName || `SUMMARY_${identity.fileName || getPathBaseName(path)}.md`),
    commentFileName: String(data.commentFileName || `COMMENT_${identity.fileName || getPathBaseName(path)}`),
    summaryMarkdown,
    commentSource,
    commentLanguage: String(data.commentLanguage || inferLanguageFromPath(identity.fileName || path, currentSourceLanguage || "java"))
  };
  setAiSampleTabsAvailable(commentAvailable, summaryAvailable);
  return true;
}

async function loadAiSampleAssetsInBackground(sourceRequestId, path) {
  // 2026-08-25 [1]: ��U���ׂĖ��Ή��BServlet�ւ��₢���킹���A��ɔ񊈐����ێ�����B
  if (!AI_SAMPLE_TABS_ENABLED) {
    currentAiSampleData = createEmptyAiSampleData();
    setAiSampleTabsAvailable(false, false);
    return false;
  }
  const requestedPath = String(path || "");
  const identity = getAiSampleSourceIdentity(requestedPath);
  // [5] ����^�v��͂����������30�^�u������Ώۂɂ���B
  // 3��������v���Ă�����30���ȊO�̕ʃp�X�Ȃ�Servlet���Ă΂��A���^�u��񊈐��̂܂܂ɂ���B
  if (!AI_SAMPLE_SOURCE_KEYS.has(identity.key) || !isAiSummaryInitialSourcePath(identity.path)) {
    setAiSampleTabsAvailable(false, false);
    return false;
  }

  const loadId = ++aiSampleLoadSequence;
  try {
    // [9] Servlet�ɂ��t���p�X�ˑ��ł͂Ȃ�3���ڂ𖾎����ēn���B
    const data = await fetchSourceJsonFast(AI_SAMPLE_ENDPOINT, {
      path: requestedPath,
      fileName: identity.fileName,
      group: identity.group,
      directoryGroup: identity.directoryGroup
    });
    if (sourceRequestId !== sourceOpenRequestSequence || loadId !== aiSampleLoadSequence || currentView !== "code") return false;

    const currentIdentity = getAiSampleSourceIdentity(currentCodePath);
    if (!AI_SAMPLE_SOURCE_KEYS.has(currentIdentity.key)
        || currentIdentity.key !== identity.key
        || normalizeAiSummaryInitialPath(currentIdentity.path) !== normalizeAiSummaryInitialPath(identity.path)) return false;
    if (!applyAiSampleData(data, currentCodePath, currentIdentity)) return false;
    renderCode();
    return true;
  } catch (e) {
    if (sourceRequestId === sourceOpenRequestSequence && loadId === aiSampleLoadSequence) {
      console.warn("AI�T���v���f�[�^���擾�ł��܂���ł����BAI�^�u�͖��Ή���Ԃ̂܂܌p�����܂��B", e);
      currentAiSampleData = createEmptyAiSampleData();
      setAiSampleTabsAvailable(false, false);
      renderCode();
    }
    return false;
  }
}

function renderMarkdownInline(text) {
  const parts = String(text || "").split("`");
  return parts.map((part, index) => index % 2 === 1
    ? `<code>${escapeHtml(part)}</code>`
    : escapeHtml(part)
        .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>"))
    .join("");
}

function renderMarkdownToSafeHtml(markdown) {
  const lines = String(markdown || "").replace(/\r\n?/g, "\n").split("\n");
  const out = [];
  let paragraph = [];
  let listType = "";
  let listItems = [];

  const flushParagraph = () => {
    if (!paragraph.length) return;
    out.push(`<p>${paragraph.map(renderMarkdownInline).join(" ")}</p>`);
    paragraph = [];
  };
  const flushList = () => {
    if (!listItems.length || !listType) return;
    out.push(`<${listType}>${listItems.map(item => `<li>${renderMarkdownInline(item)}</li>`).join("")}</${listType}>`);
    listType = "";
    listItems = [];
  };

  lines.forEach(rawLine => {
    const line = String(rawLine || "");
    const trimmed = line.trim();
    if (!trimmed) {
      flushParagraph();
      flushList();
      return;
    }

    const heading = trimmed.match(/^(#{1,6})\s+(.+)$/);
    if (heading) {
      flushParagraph();
      flushList();
      const level = Math.min(6, heading[1].length);
      out.push(`<h${level}>${renderMarkdownInline(heading[2])}</h${level}>`);
      return;
    }

    if (/^---+$/.test(trimmed)) {
      flushParagraph();
      flushList();
      out.push("<hr>");
      return;
    }

    const ordered = trimmed.match(/^\d+\.\s+(.+)$/);
    if (ordered) {
      flushParagraph();
      if (listType && listType !== "ol") flushList();
      listType = "ol";
      listItems.push(ordered[1]);
      return;
    }

    const unordered = trimmed.match(/^[-*]\s+(.+)$/);
    if (unordered) {
      flushParagraph();
      if (listType && listType !== "ul") flushList();
      listType = "ul";
      listItems.push(unordered[1]);
      return;
    }

    flushList();
    paragraph.push(trimmed);
  });

  flushParagraph();
  flushList();
  return out.join("\n");
}

function renderAiSummaryPanel(markdown) {
  const content = $("markdownSummaryContent");
  if (!content) return;
  content.innerHTML = renderMarkdownToSafeHtml(markdown || "");
}


const QUICK_LINK_CSV_PATH = "images/links.csv";
const QUICK_LINK_ICON_PATH = "images/quick-link.svg";
const QUICK_LINK_FALLBACK_ROWS = [
  { label: "CRUD", url: "http://10.202.6.34/BatchSupportSiteManager/crud/crudInit" },
  { label: "HULFT", url: "http://10.202.6.36/cgi-bin/si/index.cgi?controller=HulftList" },
  { label: "RPS", url: "http://10.202.168.238:19001/" },
  { label: "�{��RPS", url: "http://10.202.168.238:13010/" },
  { label: "jpmon", url: "http://jpmon.dc/app_index.html" },
  { label: "Desknets", url: "http://d9grphonv01.nss.nksol.co.jp/scripts/dneo/dneo.exe" }
];

function splitQuickLinkCsvLine(line) {
  const cells = [];
  let value = "";
  let inQuote = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line.charAt(i);
    const next = line.charAt(i + 1);
    if (ch === '"' && inQuote && next === '"') {
      value += '"';
      i += 1;
    } else if (ch === '"') {
      inQuote = !inQuote;
    } else if (ch === "," && !inQuote) {
      cells.push(value.trim());
      value = "";
    } else {
      value += ch;
    }
  }
  cells.push(value.trim());
  return cells;
}

function normalizeQuickLinkUrl(url) {
  const value = String(url || "").trim();
  if (!value) return "#";
  if (/^(https?:|mailto:|file:|\/|#)/i.test(value)) return value;
  return `http://${value}`;
}

function parseQuickLinkCsv(text) {
  const rows = [];
  String(text || "")
    .replace(/^\uFEFF/, "")
    .split(/\r?\n/)
    .forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) return;
      const cells = splitQuickLinkCsvLine(line);
      const label = (cells.shift() || "").trim();
      const url = cells.join(",").trim();
      if (!label || !url) return;
      rows.push({ label, url: normalizeQuickLinkUrl(url) });
    });
  return rows;
}

function decodeQuickLinkCsvBuffer(buffer) {
  let text = new TextDecoder("utf-8").decode(buffer);
  if (text.includes("�E��E�")) {
    try {
      const sjisText = new TextDecoder("shift_jis").decode(buffer);
      if (!sjisText.includes("�E��E�")) text = sjisText;
    } catch (ignore) {
      // Edge/Chrome �ł� shift_jis �𗘗p�ł���B���s�����ꍇ�� UTF-8 �̌��ʂ��g���B
    }
  }
  return text;
}

function orderQuickLinkRows(rows, listElement) {
  const map = new Map();
  rows.forEach(row => {
    if (row && row.label) map.set(row.label, row);
  });

  const currentOrder = Array.from(listElement.querySelectorAll(".quickLinkItem"))
    .map(item => item.dataset.linkName || item.textContent.trim())
    .filter(Boolean);

  const ordered = [];
  currentOrder.forEach(label => {
    if (map.has(label)) {
      ordered.push(map.get(label));
      map.delete(label);
    }
  });

  rows.forEach(row => {
    if (map.has(row.label)) {
      ordered.push(row);
      map.delete(row.label);
    }
  });

  return ordered;
}

function createQuickLinkItem(row) {
  const link = document.createElement("a");
  link.className = "quickLinkItem";
  link.href = normalizeQuickLinkUrl(row.url);
  link.dataset.linkName = row.label;
  if (link.href && link.getAttribute("href") !== "#") {
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  }

  const icon = document.createElement("img");
  icon.className = "quickLinkIconImg";
  icon.src = QUICK_LINK_ICON_PATH;
  icon.alt = "";
  icon.setAttribute("aria-hidden", "true");
  icon.addEventListener("error", () => {
    icon.style.display = "none";
  }, { once: true });

  const text = document.createElement("span");
  text.textContent = row.label;

  link.appendChild(icon);
  link.appendChild(text);
  return link;
}

function renderQuickLinks(rows) {
  const list = $("quickLinkList");
  if (!list) return;

  const orderedRows = orderQuickLinkRows(rows, list);
  list.innerHTML = "";

  if (!orderedRows.length) {
    const empty = document.createElement("div");
    empty.className = "quickLinkItem quickLinkItemEmpty";
    empty.textContent = "links.csv �Ƀ����N������܂���";
    list.appendChild(empty);
    return;
  }

  orderedRows.forEach(row => {
    list.appendChild(createQuickLinkItem(row));
  });
}

async function loadQuickLinksFromCsv() {
  const list = $("quickLinkList");
  if (!list) return;

  // file://�ł̓��[�J��CSV�ւ�fetch���̂��u���E�U�d�l��CORS�G���[�ɂȂ�B
  // ���̂��ߒʐM�𔭐��������A�����e�̖��ߍ��ݏ����l���g�p����B
  if (window.location.protocol === "file:") {
    renderQuickLinks(QUICK_LINK_FALLBACK_ROWS);
    return;
  }

  const csvPath = list.dataset.linksCsv || QUICK_LINK_CSV_PATH;
  try {
    const response = await fetch(csvPath, { cache: "no-store", credentials: "same-origin" });
    if (!response.ok) throw new Error(`links.csv load failed: ${response.status}`);
    const buffer = await response.arrayBuffer();
    const rows = parseQuickLinkCsv(decodeQuickLinkCsvBuffer(buffer));
    renderQuickLinks(rows.length ? rows : QUICK_LINK_FALLBACK_ROWS);
  } catch (error) {
    console.warn("links.csv��ǂݍ��߂Ȃ����߁A���ߍ��ݏ����l���g�p���܂��B", error);
    renderQuickLinks(QUICK_LINK_FALLBACK_ROWS);
  }
}

function openIndexPageAsInitialStartup() {
  // Krugle+�A�C�R���������́ASPA���̃z�[���ؑւł͂Ȃ� index.html ���J�������B
  // ����ɂ��A�T�C�g�������N���������Ɠ��������\���ɖ߂��B
  try {
    removeSessionStorage(TAB_NAVIGATION_STORAGE_KEY);
    removeSessionStorage(TAB_NAVIGATION_CURRENT_ID_KEY);
  } catch (e) {
    // ��ʑJ�ڂ�D�悷��B
  }

  const fallback = "index.html";
  try {
    const url = new URL(window.location.href);
    const path = url.pathname || "/";
    const basePath = path.endsWith("/")
      ? path
      : /\/[^/]+\.[^/]*$/.test(path)
        ? path.replace(/\/[^/]*$/, "/")
        : `${path}/`;
    url.pathname = `${basePath}index.html`.replace(/\/+/g, "/");
    url.search = "";
    url.hash = "";
    window.location.assign(url.toString());
  } catch (e) {
    window.location.assign(fallback);
  }
}

function bindEvents() {
  const on = (id, eventName, handler) => {
    const element = $(id);
    if (element) element.addEventListener(eventName, handler);
  };

  document.querySelectorAll(".tabBtn").forEach(button => {
    button.addEventListener("click", () => {
      if (button.classList.contains("tabFile")) {
        const index = Number(button.dataset.code || 0);
        openCode(sampleFiles[index] || sampleFiles[0]);
        document.querySelectorAll(".tabBtn").forEach(item => item.classList.remove("isActive"));
        button.classList.add("isActive");
      } else {
        showView(button.dataset.view);
      }
    });
  });
  bindSearchResultColumnFilters();
  bindHistoryTableFilters();

  on("searchBtn", "click", () => {
    runSearchFromCurrentInput("normal");
  });
  on("sampleBtn", "click", () => {
    runSearchFromCurrentInput("fuzzy");
  });
  on("searchConditionClearBtn", "click", () => {
    clearAllSearchConditions();
  });
  on("keywordConditionClearBtn", "click", event => {
    event.preventDefault();
    event.stopPropagation();
    clearSingleSearchCondition("keyword");
  });
  on("groupConditionClearBtn", "click", event => {
    event.preventDefault();
    event.stopPropagation();
    clearSingleSearchCondition("group");
  });
  on("languageConditionClearBtn", "click", event => {
    event.preventDefault();
    event.stopPropagation();
    clearSingleSearchCondition("language");
  });
  on("groupSelect", "change", () => {
    loadDirectoryGroupsForSelectedMigrationGroup({ preserveValue: false });
  });
  on("downloadBtn", "click", downloadCurrent);
  on("copyBtn", "click", copyCurrent);
  on("codeContentHeader", "click", event => {
    if (!getCurrentSourcePathForCopy()) return;
    // �����w�b�_�[���ɑ���{�^���������Ă��A���̃{�^������ł̓p�X�R�s�[�𔭉΂����Ȃ��B
    if (event.target && event.target.closest && event.target.closest("button, a, input, select, textarea")) return;
    copyCurrentSourcePath(event, { flashPath: true });
  });
  on("krugleBadge", "click", () => {
    openIndexPageAsInitialStartup();
  });
  on("historyClearBtn", "click", resetStoredHistories);

  // �ʏ�̃l�C�e�B�u select �ɖ߂��B�J�X�^�������R���{�͏��������Ȃ��B

  const quickLinkDock = $("quickLinkDock");
  const quickLinkTrigger = $("quickLinkTrigger");
  const quickLinkHoverTarget = $("quickLinkHoverTarget");
  const quickLinkOverlay = $("quickLinkOverlay");
  const quickLinkPanel = $("quickLinkPanel");
  const quickLinkClose = $("quickLinkClose");

  // ���������N�p�l���Ɉ�x�ł��}�E�X������������ێ�����B
  // �p�l���ɓ���O�iLinks����p�l���ֈړ����Ȃǁj�͕����A
  // ��x��������Ƀp�l���O�֏o������������B
  let quickLinkPanelHoverActivated = false;

  const setQuickLinkExpanded = expanded => {
    const wasExpanded = Boolean(quickLinkOverlay && quickLinkOverlay.classList.contains("isOpen"));
    // 2026-08-17 fix95: mouseenter��click/focus�œ���open�������A�����Ă��A
    // �S���overlay��style/class�X�V���J��Ԃ��Ȃ��B
    if (expanded === wasExpanded) return;
    if (expanded) quickLinkPanelHoverActivated = false;
    if (!expanded) quickLinkPanelHoverActivated = false;

    if (quickLinkTrigger) quickLinkTrigger.setAttribute("aria-expanded", expanded ? "true" : "false");
    if (quickLinkOverlay) {
      quickLinkOverlay.classList.toggle("isOpen", expanded);
      quickLinkOverlay.setAttribute("aria-hidden", expanded ? "false" : "true");

      // ������̓����ȑO�ʗv�f���A�w�ʂ̗����e�[�u�� hover ���ז����Ȃ��悤�ɂ���B
      if (expanded) {
        quickLinkOverlay.removeAttribute("hidden");
        quickLinkOverlay.style.display = "flex";
        quickLinkOverlay.style.pointerEvents = "auto";
        quickLinkOverlay.style.visibility = "visible";
        quickLinkOverlay.style.zIndex = "900";
      } else {
        quickLinkOverlay.setAttribute("hidden", "hidden");
        quickLinkOverlay.style.display = "none";
        quickLinkOverlay.style.pointerEvents = "none";
        quickLinkOverlay.style.visibility = "hidden";
        quickLinkOverlay.style.zIndex = "-1";
      }
    }
    document.body.classList.toggle("quickLinksOpen", expanded);
  };
  const openQuickLinks = () => setQuickLinkExpanded(true);
  const closeQuickLinks = () => {
    setQuickLinkExpanded(false);
  };
  if (quickLinkOverlay) setQuickLinkExpanded(false);

  if (quickLinkDock && quickLinkTrigger && quickLinkOverlay) {
    // 2026-08-17 fix94:
    // Links�̌����ڑS�̂ł͂Ȃ��A�A�C�R����ɏd�˂��������������̈悾����hover�N�_�ɂ���B
    // �L�[�{�[�hfocus/click�̃A�N�Z�V�r���e�B�͏]����quickLinkTrigger�ňێ�����B
    if (quickLinkHoverTarget) {
      quickLinkHoverTarget.addEventListener("mouseenter", openQuickLinks);
      quickLinkHoverTarget.addEventListener("click", event => {
        event.preventDefault();
        openQuickLinks();
        if (quickLinkPanel) quickLinkPanel.focus({ preventScroll: true });
      });
    }
    quickLinkTrigger.addEventListener("focus", openQuickLinks);
    quickLinkTrigger.addEventListener("click", event => {
      event.preventDefault();
      openQuickLinks();
      if (quickLinkPanel) quickLinkPanel.focus({ preventScroll: true });
    });
    if (quickLinkClose) {
      quickLinkClose.addEventListener("click", event => {
        event.preventDefault();
        closeQuickLinks();
      });
    }
    quickLinkOverlay.addEventListener("click", event => {
      if (event.target === quickLinkOverlay) closeQuickLinks();
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape" && quickLinkOverlay.classList.contains("isOpen")) {
        event.preventDefault();
        closeQuickLinks();
      }
    });
  }


  if (quickLinkPanel) {
    quickLinkPanel.addEventListener("mouseenter", () => {
      if (quickLinkOverlay && quickLinkOverlay.classList.contains("isOpen")) {
        quickLinkPanelHoverActivated = true;
      }
    });

    quickLinkPanel.addEventListener("mouseleave", () => {
      if (!quickLinkPanelHoverActivated) return;
      quickLinkPanelHoverActivated = false;
      closeQuickLinks();
    });

    quickLinkPanel.addEventListener("click", event => {
      const link = event.target.closest ? event.target.closest(".quickLinkItem") : null;
      if (!link || link.tagName.toLowerCase() !== "a") return;
      if (!link.getAttribute("href") || link.getAttribute("href") === "#") {
        event.preventDefault();
        const label = link.textContent.trim() || "�����N";
        showCopyFeedback(`${label} ��URL�͖��ݒ�ł�`);
      }
    });
  }
  // 2026-08-07 fix29:
  // �E/���^�u�ړ��{�^���͒ʏ�{�^���Ɠ�����click/Enter/Space�ő����ړ�����B
  bindCodeSideNavigationPreviewButtons();
  const codeModeTabs = document.querySelector(".codeModeTabs");
  if (codeModeTabs) {
    codeModeTabs.addEventListener("click", event => {
      const button = event.target.closest ? event.target.closest(".codeModeTab") : null;
      if (!button || !codeModeTabs.contains(button)) return;
      if (button.disabled || button.getAttribute("aria-disabled") === "true") return;
      activeCodePanel = button.dataset.codePanel || "source";
      if (isTableInfoPanel(activeCodePanel)) {
        activeTableInfoTabId = getTableInfoTabIdFromPanel(activeCodePanel);
        tableInfoState = getActiveTableInfoState();
        // SessionStorage���畜�������^�u�́A�N���b�N�����u�Ԃ�DBTYPE/SCHEMA/�e�[�u�����ōĎ擾����B
        if (tableInfoState && tableInfoState.needsReload === true) {
          reloadPersistedTableInformation(activeTableInfoTabId);
          return;
        }
      }
      renderCode();
    });
  }
  on("smallBtn", "click", () => setCodeFontSize(codeFontSize - CODE_FONT_STEP));
  on("largeBtn", "click", () => setCodeFontSize(codeFontSize + CODE_FONT_STEP));
  on("highlightToggleBtn", "click", toggleCodeHighlightBackground);
  on("codeWrapToggleBtn", "click", toggleCodeWrap);
  bindCodeSelectionSearch();
  bindCodeBackTabButton();

  window.addEventListener("scroll", requestCodeSearchPanelScrollStateUpdate, { passive: true });
  window.addEventListener("resize", requestCodeSearchPanelScrollStateUpdate);

  // �y�[�W���J��������͕K��OFF�B������CSS�ŏ펞�\�����A�w�i�F�����𖳌��ɂ���B
  setCodeHighlightBackgroundEnabled(false);

  on("keywordInput", "focus", () => renderKeywordHistoryDatalist());
  on("keywordInput", "input", () => renderKeywordHistoryDatalist());

  on("keywordInput", "keydown", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      runSearchFromCurrentInput("normal");
    }
  });

  // capture�t�F�[�Y�Ŏ󂯎��A�u���E�U�W���̗���߂����ɃT�C�g���^�u�����֊��蓖�Ă�B
  document.addEventListener("keydown", handleBackspaceTabNavigation, true);
  // [6] Delete��BackSpace�̋t�����B���͗��ł̕����폜����isBackspaceEditingTarget�ŏ��O����B
  document.addEventListener("keydown", handleDeleteTabNavigation, true);

  // �}�E�X�J�[�\�����E���c�{�^����ɂ���ꍇ��Enter���A���ꂼ��̑O��ړ��Ɠ��������ɂ���B
  document.addEventListener("keydown", event => {
    if (event.key !== "Enter") return;
    if (isKeyboardTypingTarget(event.target)) return;
    if (activeCodeBackTabButtonHover) {
      activatePreviousOpenedTabButton(event);
      return;
    }
    if (activeCodeForwardTabButtonHover) activateNextOpenedTabButton(event);
  }, true);

  document.addEventListener("keydown", event => {
    activateFullWidthHoverBandActionByEnter(event);
  }, true);

  // 2026-08-12 fix46: �}�E�X�J�[�\�����E/���^�u�ړ��{�^����ɂ���ꍇ���A
  // Enter��ArrowRight/ArrowLeft�L�[�Ɠ������Ώې����^�u��focus�ړ� + �S���O���[�ѕ\�������ɂ���B
  document.addEventListener("keydown", event => {
    if (event.key !== "Enter") return;
    if (!activeCodeSideNavigationHoverOffset) return;
    if (isKeyboardTypingTarget(event.target)) return;
    // 2026-08-12 fix60:
    // �����^�u��focus���c���Ă��Ă��A�}�E�X���E/���^�u�ړ��{�^����Ȃ�
    // Enter�̓^�u���J�����A�{�^���̋^��hover�v���r���[��1�i�߂�B
    activateCodeSideNavigationButton(activeCodeSideNavigationHoverOffset, event);
  }, true);


  // 2026-08-04 �T�C�g�C��3: �S���O���[�т��o�Ă����ԂŃN���b�N�J�ڂ���ꍇ���A
  // �J�ڒ���̕�hover�т̑����ĕ\����h���B
  document.addEventListener("click", () => {
    if (document.body && document.body.classList.contains("isRecentTabFullPathBandVisible")) {
      suppressFullWidthHoverBandTemporarily();
    }
  }, true);

  document.addEventListener("keydown", event => {
    if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
    handleRecentTabArrowKeyNavigation(event.key === "ArrowRight" ? 1 : -1, event);
  });

  const stalker = $("mouseStalker");
  const hoverTargetSelector = [
    "button",
    "#historyFileBody tr",
    "#historySearchBody tr",
    ".tabTime",
    ".recentNavArrow",
    ".krugleBadge",
    ".quickLinkDock",
    ".quickLinkTrigger",
    ".quickLinkOverlay",
    ".quickLinkClose",
    ".quickLinkItem",
    ".searchPanel input",
    ".searchPanel select",
    ".groupCombo",
    ".groupComboItem",
    ".groupComboSearch",
    ".searchPanel .cloneField",
    ".globalHistoryMini tr"
  ].join(",");

  document.addEventListener("mousemove", event => {
    // 2026-08-17 fix95: Links���[�_���\�����͑S���overlay���mousemove����ʔ��΂���B
    // �}�E�X�X�g�[�J�[��transform/class�X�V���~�߁A���[�_�����쎞�̍ĕ`�敉�ׂ��팸����B
    if (document.body && document.body.classList.contains("quickLinksOpen")) {
      stalker.classList.remove("isActive");
      return;
    }
    stalker.style.transform = `translate(${event.clientX}px, ${event.clientY}px)`;
    if (event.target.closest && event.target.closest(hoverTargetSelector)) {
      stalker.classList.add("isActive");
    } else {
      stalker.classList.remove("isActive");
    }
  }, { passive: true });
}

document.addEventListener("DOMContentLoaded", async () => {
  initializeTabNavigationHistory();
  bindEvents();
  setCodeWrapEnabled(true);
  await loadQuickLinksFromCsv();
  resetInitialSearchSummary();
  renderInitialResultPlaceholders();
  renderRecentTabs();
  await loadInitialData();
  await loadInitialSearchResult();
  renderHistory();
  requestCodeSearchPanelScrollStateUpdate();
});


